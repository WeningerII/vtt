
import { SRDData } from '../../types'; // Adjusted path assuming types.ts is at root
import { GENERATED_SRD_DATA } from './data_modules/generatedSrdData';

// Import parts of the SRD that are not yet fully integrated into GENERATED_SRD_DATA
// or that GENERATED_SRD_DATA will point to via placeholders.
import { STARTING_POTION_CHOICES as _STARTING_POTION_CHOICES_EXISTING } from './data_modules/items/potions';
import { BEASTFORM_OPTIONS as _BEASTFORM_OPTIONS_EXISTING } from './data_modules/beastforms/index';
import { CONDITIONS_DATA as _CONDITIONS_DATA_EXISTING } from './data_modules/conditions';
import { GAME_TERMS_DATA as _GAME_TERMS_DATA_EXISTING } from './data_modules/game_terms';

// Core constants and defaults remain essential
import { DEFAULT_CHARACTER_DATA as _DEFAULT_CHARACTER_DATA } from './data_modules/character_defaults';
import { TRAIT_NAMES as _TRAIT_NAMES, INITIAL_TRAIT_MODIFIERS as _INITIAL_TRAIT_MODIFIERS } from './data_modules/core_constants';
import type { TraitName as _TraitName } from './data_modules/core_constants';
import { STARTING_INVENTORY_ITEMS as _STARTING_INVENTORY_ITEMS } from './data_modules/items/starting_inventory';


// MOCK_SRD_DATA will now be primarily built from the generated data,
// and supplemented by any data still managed in separate TS files.
export const MOCK_SRD_DATA: SRDData = {
  classes: GENERATED_SRD_DATA.classes,
  ancestries: GENERATED_SRD_DATA.ancestries,
  communities: GENERATED_SRD_DATA.communities,
  weapons: GENERATED_SRD_DATA.weapons,
  armor: GENERATED_SRD_DATA.armor,
  domainCards: GENERATED_SRD_DATA.domainCards,
  lootItems: GENERATED_SRD_DATA.lootItems,
  consumableItems: GENERATED_SRD_DATA.consumableItems,
  
  // Use existing constants for these until they are fully integrated into the generation script
  startingPotionChoices: _STARTING_POTION_CHOICES_EXISTING,
  beastforms: _BEASTFORM_OPTIONS_EXISTING,
  conditions: _CONDITIONS_DATA_EXISTING,
  gameTerms: _GAME_TERMS_DATA_EXISTING,
};

// Re-export core constants and defaults
export const TRAIT_NAMES = _TRAIT_NAMES;
export const INITIAL_TRAIT_MODIFIERS = _INITIAL_TRAIT_MODIFIERS;
export type TraitName = _TraitName; // Keep this if used directly elsewhere
export const DEFAULT_CHARACTER_DATA = _DEFAULT_CHARACTER_DATA;

// Re-export specific data sets that might be directly imported by components
export const STARTING_INVENTORY_ITEMS = _STARTING_INVENTORY_ITEMS;
export const STARTING_POTION_CHOICES = _STARTING_POTION_CHOICES_EXISTING;
export const LOOT_ITEMS = GENERATED_SRD_DATA.lootItems; 
export const CONSUMABLE_ITEMS = GENERATED_SRD_DATA.consumableItems; 
export const BEASTFORM_OPTIONS = _BEASTFORM_OPTIONS_EXISTING;
export const CONDITIONS_DATA = _CONDITIONS_DATA_EXISTING;
export const GAME_TERMS_DATA = _GAME_TERMS_DATA_EXISTING;

// Re-export main data categories for easier access if components import them directly
// (though ideally, they'd use MOCK_SRD_DATA)
export const CLASSES = MOCK_SRD_DATA.classes;
export const ANCESTRIES = MOCK_SRD_DATA.ancestries;
export const COMMUNITIES = MOCK_SRD_DATA.communities;
export const DOMAIN_CARDS = MOCK_SRD_DATA.domainCards;
export const ALL_WEAPONS = MOCK_SRD_DATA.weapons;
export const ALL_ARMOR = MOCK_SRD_DATA.armor;

// Individual class/ancestry etc. exports are removed as they should be accessed via the main arrays.
// e.g., instead of `import { BARD_CLASS } from '...'`, use `MOCK_SRD_DATA.classes.find(c => c.id === 'bard')`

// The specific tier/type weapon/armor exports are also removed.
// Components should filter from ALL_WEAPONS or ALL_ARMOR if needed.
// This simplifies this file and centralizes data access through MOCK_SRD_DATA.

// Note: The data modules under constants/data_modules/ (like classes/, ancestries/, etc.)
// for the data types now handled by generatedSrdData.ts are no longer directly used by
// MOCK_SRD_DATA in this file. The Python script now reads their counterparts from
// the /daggerheart-srd-main/.build/json/ directory.
// The files for beastforms, conditions, game_terms, items/potions are still used here.
