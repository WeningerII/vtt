
import { PotionChoice } from '../../../types'; // Adjusted path

export const STARTING_POTION_CHOICES: PotionChoice[] = [
  { id: 'minor_health_potion', name: 'Minor Health Potion', description: 'Clear 1d4 Hit Points', srdPage: 5, srdRoll: -1 }, // srdRoll -1 to indicate it's a choice not a table roll
  { id: 'minor_stamina_potion', name: 'Minor Stamina Potion', description: 'Clear 1d4 Stress', srdPage: 5, srdRoll: -1 }
];
