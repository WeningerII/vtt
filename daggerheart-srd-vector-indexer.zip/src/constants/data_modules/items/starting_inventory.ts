
export const STARTING_INVENTORY_ITEMS: string[] = [
  "A torch",
  "50 feet of rope",
  "Basic supplies"
];
