
import { BeastformData } from '../../../types';

export const TIER2_BEASTFORMS: BeastformData[] = [];
