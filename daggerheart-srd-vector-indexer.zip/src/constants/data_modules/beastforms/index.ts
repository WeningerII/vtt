
import { BeastformData } from '../../../types'; // Adjusted path
import { TIER1_BEASTFORMS } from './tier1_beastforms';
import { TIER2_BEASTFORMS } from './tier2_beastforms';
import { TIER3_BEASTFORMS } from './tier3_beastforms';
import { TIER4_BEASTFORMS } from './tier4_beastforms';

export const BEASTFORM_OPTIONS: BeastformData[] = [
  ...TIER1_BEASTFORMS,
  ...TIER2_BEASTFORMS,
  ...TIER3_BEASTFORMS,
  ...TIER4_BEASTFORMS,
];

export type { BeastformData }; // Re-exporting the type if it was defined locally
