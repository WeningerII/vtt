
import { BeastformData } from '../../../types';

export const TIER4_BEASTFORMS: BeastformData[] = [];
