
import { BeastformData } from '../../../types';

export const TIER3_BEASTFORMS: BeastformData[] = [];
