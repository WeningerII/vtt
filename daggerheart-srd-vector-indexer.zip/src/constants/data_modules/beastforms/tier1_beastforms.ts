
import { BeastformData } from '../../../types'; // Adjusted path

export const TIER1_BEASTFORMS: BeastformData[] = [
  { id: 'wolf', name: 'Wolf (Tier 1)', tier: 1, description: 'A swift and fierce hunter.', features: ['Pack Tactics', 'Keen Senses'], evasionBonus: 1, attackTrait: 'Agility' },
  { id: 'bear', name: 'Bear (Tier 1)', tier: 1, description: 'A powerful and resilient guardian.', features: ['Claws', 'Strong Hide'], evasionBonus: 0, attackTrait: 'Strength' },
];
