
// Note: The SRD text is extremely long and has been truncated for this example.
// In a real application, this would be loaded from a file or a more suitable source.
export const SRD_TEXT_FULL: string = `
System reference Document 1.0
This document, including the Witherwild Campaign Frame, is considered Public Game Content per the Darrington Press
Community Gaming License. Please read the Darrington Press Community Gaming License before using this material.
© 2025 Critical Role LLC. All rights reserved. For more information, please visit www.darringtonpress.com/license.
SRD Writer: Rob Hebert | Technical Editor: Shawn Banerjee | Layout: Matt Paquette & Co. | Producer: Madigan Hunt
DAGGERHEART
CONTENTS
INTRODUCTION . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4
What Is This . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4
The Basics . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4
STARTING A CAMPAIGN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5
Session Zero . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5
Setting Creation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6
CHARACTER CREATION . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8
CORE MATERIALS . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 11
Domains . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 11
Classes . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 12
Ancestries . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 31
Communities . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 36
CORE MECHANICS . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
Flow of the Game . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
Core Gameplay Loop . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
The Spotlight . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
Turn Order & Action Economy . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 40
Making Moves & Taking Action . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 40
Combat . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 43
Stress . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 43
Attacking . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 43
Maps, Range & Movement . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 44
Conditions . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 45
Downtime . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 45
Death . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
Additional Rules . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
Leveling Up . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 46
Multiclassing . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 47
Equipment . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 48
Weapons . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 48
Combat Wheelchair . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 57
Armor . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 59
Loot . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 61
Consumables . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 63
RUNNING AN ADVENTURE . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 66
Introduction . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 66
GM Guidance . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 66
Core GM Mechanics . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 67
Adversaries and Environments . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 74
The Witherwild Campaign Frame . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 114
APPENDIX . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 120
Domain Card Reference . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 120
Daggerheart SRD 2
INTRODUCTION
Welcome to DAGGERHEART, a collaborative fantasy tabletop roleplaying game of incredible
magic and heroic, heartfelt adventure.
WHAT IS THIS?
This is the Daggerheart SRD (System Reference Document). It
is a repository of the mechanical elements of the Daggerheart
system, edited and organized for clarity, conciseness, and
quick reference.
You can use this SRD in several ways:
• To quickly look up Daggerheart’s rules-as-written during
gameplay sessions.
• To ensure any homebrew content you create or publish
conforms with Daggerheart’s core ruleset.
• To provide copy text made available by Darrington Press
for your own publications under their Community Gaming
License (www.darringtonpress.com/license).
• To better understand the mechanics of Daggerheart,
absent the flavor and setting information, so you can bend
or break them in the process of making your own content.
The Daggerheart SRD is not a replacement for the core
rulebook, which contains setting information, additional
examples of various gameplay elements, and tons of great
advice for playing Daggerheart—not to mention gorgeous
artwork and layout.
In short, it is Daggerheart, the system, boiled down to the
bones—a lean and clean offering without all the flavor, style,
and supporting material that makes the core rulebook such an
evocative and enjoyable read. We hope this document proves
useful to your table. Happy adventuring!
THE BASICS
WHAT IS DAGGERHEART?
Daggerheart is a tabletop roleplaying game for one Game
Master (“GM”) and 2-5 players. Each game session lasts about
2-4 hours, and Daggerheart can be played as a one-shot or a
multi-session campaign of any length.
During a session of Daggerheart the GM describes situations,
narrates events, and controls any adversaries or obstacles
that the Player Characters (“PCs”) encounter. The players, in
turn, roleplay their PCs’ reactions to the scenario presented by
the GM. If the outcome of a player’s action depends on fate or
fortune, the GM calls for an action roll.
When a player makes an action roll, they utilize Duality
Dice—two differently colored 12-sided dice (“d12s”)
representing Hope and Fear. The Duality Dice are rolled,
relevant modifiers are added to the results, and the total is
compared to a Difficulty set by the GM. If the total meets or
beats the Difficulty, the player succeeds. If it’s lower, they fail.
In addition, the situation changes based on which Duality Die
rolls higher, either giving the player helpful Hope tokens or
generating terrifying Fear tokens for the GM.
THE GOLDEN RULE
The most important rule of Daggerheart is to make the game
your own. The rules included in this SRD are designed to
help you enjoy the experience at the table, but everyone has
a different approach to interpreting rules and telling stories.
The rules should never get in the way of the story you want
to tell, the characters you want to play, or the adventures you
want to have. As long as your group agrees, everything can
be adjusted to fit your play style. If there’s a rule you’d rather
ignore or modify, feel free to implement any change with your
table’s consent.
RULINGS OVER RULES
While playing Daggerheart, the GM and players should always
prioritize rulings over rules. This SRD offers answers for many
questions your table may have about the game, but it won’t
answer all of them. When you’re in doubt about how a rule
applies, the GM should make a ruling that aligns with the
narrative.
For example, Daggerheart has a weapon called a grappler that
lets you pull a target close to you. If you try to use it to pull an
entire castle, the weapon text doesn’t forbid you from doing
that—but it doesn’t make sense within the narrative. Instead,
the GM might rule that you pull a few bricks out, or pull
yourself toward the wall instead.
Similarly, if your character does something that would logically
result in immediate death—such as diving into an active
volcano without protection—you might not get to make
one of Daggerheart’s death moves, which normally give you
control of your character’s fate in their final moments. This
kind of consequence should be made clear before the action is
completed, and it should always follow the logic of the world.
As a narrative-focused game, Daggerheart is not a place
where technical, out-of-context interpretations of the rules are
encouraged. Everything should flow back to the fiction, and
the GM has the authority and responsibility to make rulings
about how rules are applied to underscore that fiction.
Daggerheart SRD 3
CHARACTER CREATION
Unless their table chooses to use pre-generated characters,
each player creates their own PC by making a series of
guided choices. Some of these decisions are purely narrative,
meaning they only appear in or affect the game through
roleplaying, but others are mechanical choices that affect the
things their PC is able to do and which actions they’re more
(or less) likely to succeed at when making moves and taking
action.
Note: You can fill in your character’s name, pronouns, and
Character Description details at any point of the character
creation process.
STEP 1
Choose a Class and Subclass.
Classes are role-based archetypes that determine which class
features and domain cards a PC gains access to throughout
the campaign. There are nine classes in this SRD: Bard, Druid,
Guardian, Ranger, Rogue, Seraph, Sorcerer, Warrior, Wizard.
• Select a class and take its corresponding character sheet
and character guide printouts. These sheets are for
recording your PC’s details; you’ll update and reference
them throughout the campaign.
• Every class begins with one or more unique class
feature(s), described at the bottom left of each class’s
character sheet. If your class feature prompts you to make
a selection, do so now.
• Choose a Subclass
Subclasses further refine a class archetype and reinforce
its expression by granting access to unique subclass
features. Each class comprises two subclasses. Select one
of your class’s subclasses and take its Foundation card.
STEP 2
Choose Your Heritage.
Your character’s heritage combines two elements: ancestry
and community.
• A character’s ancestry represents their species or lineage;
it grants them certain physical traits and two unique
ancestry features. Take the card for one of the following
ancestries, then write its name in the Heritage field of your
character sheet: Clank, Drakona, Dwarf, Elf, Faerie, Faun,
Firbolg, Fungril, Galapa, Giant, Goblin, Halfling, Human,
Infernis, Katari, Orc, Ribbet, Simiah. To create a Mixed
Ancestry, take the top (first-listed) ancestry feature from
one ancestry and the bottom (second-listed) ancestry
feature from another.
• Your character’s community represents their culture
or environment of origin and grants them a community
feature. Take the card for one of the following
communities, then write its name in the Heritage field of
your character sheet: Highborne, Loreborne, Orderborne,
Ridgeborne, Seaborne, Slyborne, Underborne,
Wanderborne, Wildborne.
STEP 3
Assign Character Traits.
Your character has six traits that represent their physical,
mental, and social aptitude:
• Agility (Use it to Sprint, Leap, Maneuver,etc.)
A high Agility means you’re fast on your feet, nimble on
difficult terrain, and quick to react to danger. You’ll make
an Agility Roll to scurry up a rope, sprint to cover, or
bound from rooftop to rooftop.
• Strength (Use it to Lift, Smash, Grapple, etc.)
A high Strength means you’re better at feats that test your
physical prowess and stamina. You’ll make a Strength Roll
to break through a door, lift heavy objects, or hold your
ground against a charging foe.
• Finesse (Use it to Control, Hide, Tinker, etc.)
A high Finesse means you’re skilled at tasks that require
accuracy, stealth, or the utmost control. You’ll make a
Finesse Roll to use fine tools, escape notice, or strike with
precision.
• Instinct (Use it to Perceive, Sense, Navigate, etc.)
A high Instinct means you have a keen sense of your
surroundings and a natural intuition. You’ll make an
Instinct Roll to sense danger, notice details in the world
around you, or track an elusive foe.
• Presence (Use it to Charm, Perform, Deceive, etc.)
A high Presence means you have a strong force of
personality and a facility for social situations. You’ll make
a Presence Roll to plead your case, intimidate a foe, or
capture the attention of a crowd.
• Knowledge (Use it to Recall, Analyze, Comprehend, etc.)
A high Knowledge means you know information others
don’t and understand how to apply your mind through
deduction and inference. You’ll make a Knowledge Roll
to interpret facts, see the patterns clearly, or remember
important information.
When you “roll with a trait,” that trait’s modifier is added to
the roll’s total. Assign the modifiers +2, +1, +1, +0, +0, -1 to
your character’s traits in any order you wish.
STEP 4
Record Additional Character Information.
• Characters start a new campaign at Level 1. Record your
level in the designated space at the top of your character
sheet.
• Evasion represents your character’s ability to avoid
damage. Your character’s starting Evasion is determined
by their class and appears directly beneath the Evasion
field on your character sheet; copy this number into the
Evasion field.
• Hit Points (HP) are an abstract measure of your physical
health. Your starting HP is determined by your class and is
recorded on your character sheet.
Daggerheart SRD 4
• Stress reflects your ability to withstand the mental and
emotional strain of dangerous situations and physical
exertion. Every PC starts with 6 Stress slots.
• Hope is a metacurrency that fuels special moves and
certain abilities or features. All PCs start with 2 Hope;
mark these in the Hope field of your character sheet.
STEP 5
Choose Your Starting Equipment
Choose your weapon(s):
• Select from the Tier 1 Weapon Tables. Either a twohanded primary weapon or a one-handed primary
weapon and a one-handed secondary weapon.Then equip
your selection by recording it in the Active Weapon field of
your character sheet.
• At Level 1, your Proficiency is 1; write this number in the
Proficiency field on your character sheet, then calculate
and record your damage roll by combining your Proficiency
value with your equipped weapon(s) damage dice.
Example: If your Proficiency is 1 and your weapon’s damage
dice is d6+1, your damage roll is 1d6+1. Proficiency only
determines how many damage dice you roll, and does not
affect any flat damage modifiers.
Choose and equip one set of armor from the Tier 1 Armor
Table, then record its details in the Active Armor field of your
character sheet.
• Add your character’s level to your equipped armor’s Base
Thresholds and record the total for both numbers in the
corresponding fields. At character creation, your level is 1.
• Record your Armor Score in the field at the top left of
your character sheet. Your Armor Score is equal to your
equipped armor’s Base Score plus any permanent bonuses
your character has to their Armor Score from other
abilities, features, or effects.
Add the following items to the Inventory fields on your
character sheet:
• A torch, 50 feet of rope, basic supplies, and a handful
of gold (mark one box in the left-hand column of your
character sheet titled “Gold > Handfuls”)
• EITHER a Minor Health Potion (clear 1d4 Hit Points) OR a
Minor Stamina Potion (clear 1d4 Stress)
• One of the class-specific items listed on your character
guide
• If applicable, whichever class-specific item you selected to
carry your spells
• Any other GM-approved items you’d like to have at the
start of the game
STEP 6
Create Your Background.
Develop your character’s background by answering the
background questions in your character guide, modifying or
replacing them if they don’t fit the character you want to play.
Note: Your background has no explicit mechanical effect,
but it greatly affects the character you’ll play and the prep
the GM will do. Throughout character creation, you can
adjust choices you made in earlier steps to better reflect this
background as your character takes shape. If you wish, you
can leave your character’s past more ambiguous for the time
being and discover their backstory through play.
STEP 7
Create Your Experiences.
An Experience is a word or phrase used to encapsulate a
specific set of skills, personality traits, or aptitudes your
character has acquired over the course of their life. When your
PC makes a move, they can spend a Hope to add a relevant
Experience’s modifier to the action roll.
• Your PC gets two Experiences at character creation, each
with a +2 modifier.
• There’s no set list of Experiences to choose from, but an
Experience can’t be too broadly applicable and it can’t
grant your character specific mechanical benefits, such as
magic spells or special abilities. For example, “Lucky” and
“Highly Skilled” are too broad, because they could be applied
to virtually any roll. Likewise, “Supersonic Flight” and
“Invulnerable” imply game-breaking special abilities.
EXAMPLE EXPERIENCES
Backgrounds: Assassin, Blacksmith, Bodyguard, Bounty
Hunter, Chef to the Royal Family, Circus Performer,
Con Artist, Fallen Monarch, Field Medic, High Priestess,
Merchant, Noble, Pirate, Politician, Runaway, Scholar,
Sellsword, Soldier, Storyteller, Thief, World Traveler
Characteristics: Affable, Battle-Hardened, Bookworm,
Charming, Cowardly, Friend to All, Helpful, Intimidating
Presence, Leader, Lone Wolf, Loyal, Observant, Prankster,
Silver Tongue, Sticky Fingers, Stubborn to a Fault, Survivor,
Young and Naive
Specialties: Acrobat, Gambler, Healer, Inventor, Magical
Historian, Mapmaker, Master of Disguise, Navigator,
Sharpshooter, Survivalist, Swashbuckler, Tactician
Skills: Animal Whisperer, Barter, Deadly Aim, Fast
Learner, Incredible Strength, Liar, Light Feet, Negotiator,
Photographic Memory, Quick Hands, Repair, Scavenger,
Tracker
Phrases: Catch Me If You Can, Fake It Till You Make It, First
Time’s the Charm, Hold the Line, I Won’t Let You Down,
I’ll Catch You, I’ve Got Your Back, Knowledge Is Power,
Nature’s Friend, Never Again, No One Left Behind, Pick on
Someone Your Own Size, The Show Must Go On, This Is
Not a Negotiation, Wolf in Sheep’s Clothing
Daggerheart SRD 5
STEP 8
Choose Domain Cards.
Your class has access to two of the nine Domains included in
the core set. Choose two cards from your class’s domains,
which are listed in the upper left of your character sheet. You
can take one card from each domain or two from a single
domain, whichever you prefer.
STEP 9
Create Your Connections.
Connections are the relationships between the PCs. To create
connections, follow these steps:
• Go around the table and have each player describe their
characters to one another—at a minimum, their name,
pronouns, character description, experiences, and the
answers to their background questions.
• Discuss potential connections between the PCs using the
questions included in the “Connections” section of your
character guide as inspiration.
• Suggest at least one connection between your character
and each other player’s PC. Accept any suggested
connections you want to explore, reject any you don’t.
Note: A player can reject a suggested connection for any
reason, and it’s okay if there isn’t an established connection
between every pair of PCs—you can always discover and
develop those relationships through play.
Daggerheart SRD 6
CORE MATERIALS
DOMAINS
The Daggerheart core set includes 9 Domain Decks, each
comprising a collection of cards granting features or special
abilities expressing a particular theme.
The 9 Domains are:
ARCANA
Arcana is the domain of innate and instinctual magic. Those
who choose this path tap into the raw, enigmatic forces of the
realms to manipulate both their own energy and the elements.
Arcana offers wielders a volatile power, but it is incredibly
potent when correctly channeled. The Arcana domain can be
accessed by the Druid and Sorcerer classes.
BLADE
Blade is the domain of weapon mastery. Whether by steel,
bow, or perhaps a more specialized arm, those who follow this
path have the skill to cut short the lives of others. Wielders of
Blade dedicate themselves to achieving inexorable power over
death. The Blade domain can be accessed by the Guardian
and Warrior classes.
BONE
Bone is the domain of tactics and the body. Practitioners
of this domain have an uncanny control over their own
physical abilities and an eye for predicting the behaviors of
others in combat. Adherents to Bone gain an unparalleled
understanding of bodies and their movements. The Bone
domain can be accessed by the Ranger & Warrior classes.
CODEX
Codex is the domain of intensive magical study. Those who
seek magical knowledge turn to the equations of power
recorded in books, written on scrolls, etched into walls, or
tattooed on bodies. Codex offers a commanding and versatile
understanding of magic to devotees who pursue knowledge
beyond the boundaries of common wisdom. The Codex
domain can be accessed by the Bard and Wizard classes.
GRACE
Grace is the domain of charisma. Through rapturous
storytelling, charming spells, or a shroud of lies, those who
channel this power define the realities of their adversaries,
bending perception to their will. Grace offers its wielders raw
magnetism and mastery over language. The Grace domain can
be accessed by the Bard and Rogue classes
MIDNIGHT
Midnight is the domain of shadows and secrecy. Whether
by clever tricks, deft magic, or the cloak of night, those who
channel these forces practice the art of obscurity and can
uncover sequestered treasures. Midnight offers practitioners
the power to control and create enigmas. The Midnight
domain can be access by the Rogue and Sorcerer classes.
SAGE
Sage is the domain of the natural world. Those who walk
this path tap into the unfettered power of the earth and its
creatures to unleash raw magic. Sage grants its adherents
the vitality of a blooming flower and the ferocity of a ravenous
predator. The Sage domain can be accessed by the Druid and
Ranger classes.
SPLENDOR
Splendor is the domain of life. Through this magic, followers
gain the ability to heal and, to an extent, control death.
Splendor offers its disciples the magnificent ability to both
give and end life. The Splendor domain can be accessed by the
Seraph and Wizard classes.
VALOR
Valor is the domain of protection. Whether through attack or
defense, those who choose this discipline channel formidable
strength to protect their allies in battle. Valor offers great
power to those who raise their shields in defense of others.
The Valor domain can be accessed by the Guardian and
Seraph classes.
Class Domains
Each class grants access to two domains:
• Bard: Codex & Grace
• Druid: Arcana & Sage
• Guardian: Blade & Valor
• Ranger: Bone & Sage
• Rogue: Grace & Midnight
• Seraph: Splendor & Valor
• Sorcerer: Arcana & Midnight
• Warrior: Blade & Bone
• Wizard: Codex & Splendor
PCs acquire two 1st-level domain cards at character creation
and an additional domain card at or below their level each time
they level up.
Daggerheart SRD 7
DOMAIN CARDS
Each domain card provides one or more features your PC
can utilize during their adventures. Some domain cards
provide moves you can make, such as a unique attack or a
spell. Others offer passive effects, new downtime or social
encounter abilities, or one-time benefits.
DOMAIN CARD ANATOMY
Each domain card includes six elements:
Level
The number in the top left of the card indicates the card’s
level. You cannot acquire a domain card with a level higher
than your PC’s.
Domain
Beneath the card’s level there is a symbol indicating its
domain. You can only choose cards from your class’s two
domains.
Recall Cost
The number and lightning bolt in the top right of the card
shows its Recall Cost. This is the amount of Stress a player
must mark to swap this card from their vault with a card
from their loadout.
Note: A player can swap domain cards during downtime
without paying the domain card’s Recall Cost.
Title
The name of the card.
Type
The card’s type is listed in the center above the title. There
are three types of domain cards: abilities, spells, and
grimoires. Abilities are typically non-magical in nature,
while spells are magical. Grimoires are unique to the Codex
domain and grant access to a collection of less potent
spells. Some game mechanics only apply to certain types
of cards.
Feature
The text on the bottom half of the card describes its
feature(s), including any special rules you need to follow
when you use that card.
LOADOUT & VAULT
Your loadout is the set of acquired domain cards whose
effects your PC can use during play. You can have up to
5 domain cards in your loadout at one time. Once you’ve
acquired six or more domain cards, you must choose five to
keep in your loadout; the rest are considered to be in your
vault. Vault cards are inactive and do not influence play
Note: Your subclass, ancestry, and community cards don’t
count toward your loadout or vault and are always active and
available.
At the start of a rest, before using downtime moves, you can
freely move cards between your loadout and your vault, so
long as your loadout doesn’t exceed its five-card maximum.
To move a card from your vault to your loadout at any other
time, you must mark a number of Stress equal to the vaulted
card’s Recall Cost (located in the top right of the card next to
the lightning bolt symbol). If your loadout is already full, you
must also move a card from your loadout to your vault to make
space, though you can do this at no cost.
When you gain a new domain card at level-up, you can
immediately move it into your loadout for free. If your loadout
is already full, you must also move a card from your loadout to
your vault to make space.
USAGE LIMITS
If a domain card restricts how often it can be used, you can
track such limits with whatever method you prefer, such
as turning the card sideways, flipping it facedown, or using
tokens.
Note: if an effect or ability gives you a number of uses equal
to a trait with a modifier of +0 or less, it grants you 0 uses.
CLASSES
A class is a role-based archetype that determines a PC’s:
• Access to Domains: Each class grants access to two
domains; players choose cards from these domains during
character creation and when leveling up.
• Starting Evasion and Hit Points (HP)
• Starting Items
• Class Feature(s)
• Class Hope Feature, a class feature that costs 3 Hope to
activate.
There are 9 classes in the Daggerheart core materials: Bard,
Druid, Guardian, Ranger, Rogue, Seraph, Sorcerer, Warrior,
and Wizard.
SUBCLASSES
Each class is divided into two subclasses, each of which
further defines and highlights one aspect of its class
archetype. Your chosen subclass grants the following:
• Spellcast Trait: the trait used on all Spellcast rolls.
• Foundation Feature: a unique starting feature that
establishes the identity and strengths of the subclass.
• Specialization Feature: an advanced feature that can be
gained on level up. For some subclasses, the specialization
feature grants a new ability; for others, it expands or
enhances a feature you already acquired through a class or
subclass.
• Mastery Feature: The mastery feature is a subclass’s most
powerful feature, which can be gained at higher levels.
For some subclasses, the mastery feature unlocks an
extraordinary new ability; for others, it’s the impressive
culmination of their subclass’s core feature.
The Daggerheart core set includes cards detailing each
foundation, specialization, and mastery feature. When you
acquire one of these features, take its card for use as a
reference during play.
Daggerheart SRD 8
BARD
Bards are the most charismatic people in all the realms.
Members of this class are masters of captivation and
specialize in a variety of performance types, including singing,
playing musical instruments, weaving tales, or telling jokes.
Whether performing for an audience or speaking to an
individual, bards thrive in social situations. Members of this
profession bond and train at schools or guilds, but a current
of egotism runs through those of the bardic persuasion. While
they may be the most likely class to bring people together, a
bard of ill temper can just as easily tear a party apart.
DOMAINS - Grace & Codex
STARTING EVASION - 10
STARTING HIT POINTS - 5
CLASS ITEMS - A romance novel or a letter never opened
BARD’S HOPE FEATURE
Make a Scene: Spend 3 Hope to temporarily Distract a
target within Close range, giving them a -2 penalty to their
Difficulty.
CLASS FEATURE
Rally: Once per session, describe how you rally the party
and give yourself and each of your allies a Rally Die. At level
1, your Rally Die is a d6. A PC can spend their Rally Die to
roll it, adding the result to their action roll, reaction roll,
damage roll, or to clear a number of Stress equal to the
result. At the end of each session, clear all unspent Rally
Dice. At level 5, your Rally Die increases to a d8.
BARD SUBCLASSES
Choose either the Troubadour or Wordsmith subclass.
TROUBADOUR
Play the Troubadour if you want to play music to bolster your
allies.
SPELLCAST TRAIT
Presence
FOUNDATION FEATURE
Gifted Performer: You can play three different types of
songs, once each per long rest; describe how you perform
for others to gain the listed benefit:
• Relaxing Song: You and all allies within Close range clear
a Hit Point.
• Epic Song: Make a target within Close range temporarily
Vulnerable.
• Heartbreaking Song: You and all allies within Close
range gain a Hope.
SPECIALIZATION FEATURE
Maestro. Your rallying songs steel the courage of those
who listen. When you give a Rally Die to an ally, they can
gain a Hope or clear a Stress.
MASTERY FEATURE
Virtuoso. You are among the greatest of your craft and your
skill is boundless. You can perform each of your “Gifted
Performer” feature’s songs twice per long rest.
WORDSMITH
Play the Wordsmith if you want to use clever wordplay and
captivate crowds.
SPELLCAST TRAIT
Presence
FOUNDATION FEATURES
Rousing Speech: Once per long rest, you can give a
heartfelt, inspiring speech. All allies within Far range clear
2 Stress.
Heart of a Poet: After you make an action roll to impress,
persuade, or offend someone, you can spend a Hope to
add a d4 to the roll.
Daggerheart SRD 9
SPECIALIZATION FEATURE
Eloquent. Your moving words boost morale. Once per
session, when you encourage an ally, you can do one of the
following:
• Allow them to find a mundane object or tool they need.
• Help an Ally without spending Hope.
• Give them an additional downtime move during their
next rest.
MASTERY FEATURE
Epic Poetry. Your Rally Die increases to a d10. Additionally,
when you Help an Ally, you can narrate the moment as
if you were writing the tale of their heroism in a memoir.
When you do, roll a d10 as your advantage die.
BACKGROUND QUESTIONS
Answer any of the following background questions. You can
also create your own questions.
• Who from your community taught you to have such
confidence in yourself?
• You were in love once. Who did you adore, and how
did they hurt you?
• You’ve always looked up to another bard. Who are
they, and why do you idolize them?
CONNECTIONS
Ask your fellow players one of the following questions for
their character to answer, or create your own questions.
• What made you realize we were going to be such
good friends?
• What do I do that annoys you?
• Why do you grab my hand at night?
DRUID
Becoming a druid is more than an occupation; it’s a calling for
those who wish to learn from and protect the magic of the
wilderness. While one might underestimate a gentle druid who
practices the often-quiet work of cultivating flora, druids who
channel the untamed forces of nature are terrifying to behold.
Druids cultivate their abilities in small groups, often connected
by a specific ethos or locale, but some choose to work alone.
Through years of study and dedication, druids can learn to
transform into beasts and shape nature itself.
DOMAINS - Sage & Arcana
STARTING EVASION - 10
STARTING HIT POINTS - 6
CLASS ITEMS - A small bag of rocks and bones or a
strange pendant found in the dirt
DRUID’S HOPE FEATURE
Evolution: Spend 3 Hope to transform into a Beastform
without marking a Stress. When you do, choose one trait to
raise by +1 until you drop out of that Beastform.
CLASS FEATURES
Beastform: Mark a Stress to magically transform into a
creature of your tier or lower from the Beastform list. You
can drop out of this form at any time. While transformed,
you can’t use weapons or cast spells from domain cards,
but you can still use other features or abilities you have
access to. Spells you cast before you transform stay
active and last for their normal duration, and you can talk
and communicate as normal. Additionally, you gain the
Beastform’s features, add their Evasion bonus to your
Evasion, and use the trait specified in their statistics for
your attack. While you’re in a Beastform, your armor
becomes part of your body and you mark Armor Slots as
usual; when you drop out of a Beastform, those marked
Armor Slots remain marked. If you mark your last Hit Point,
you automatically drop out of this form.
Wildtouch: You can perform harmless, subtle effects that
involve nature—such as causing a flower to rapidly grow,
summoning a slight gust of wind, or starting a campfire—
at will.
Daggerheart SRD 10
DRUID SUBCLASSES
Choose either the Warden of the Elements or Warden of
Renewal subclass.
WARDEN OF THE ELEMENTS
Play the Warden of the Elements if you want to embody the
natural elements of the wild.
SPELLCAST TRAIT
Instinct
FOUNDATION FEATURE
Elemental Incarnation: Mark a Stress to Channel one of the
following elements until you take Severe damage or until
your next rest:
• Fire: When an adversary within Melee range deals
damage to you, they take 1d10 magic damage.
• Earth: Gain a bonus to your damage thresholds equal to
your Proficiency.
• Water: When you deal damage to an adversary within
Melee range, all other adversaries within Very Close
range must mark a Stress.
• Air: You can hover, gaining advantage on Agility Rolls.
SPECIALIZATION FEATURE
Elemental Aura: Once per rest while Channeling, you can
assume an aura matching your element. The aura affects
targets within Close range until your Channeling ends.
• Fire: When an adversary marks 1 or more Hit Points,
they must also mark a Stress.
• Earth: Your allies gain a +1 bonus to Strength.
• Water: When an adversary deals damage to you, you
can mark a Stress to move them anywhere within Very
Close range of where they are.
• Air: When you or an ally takes damage from an attack
beyond Melee range, reduce the damage by 1d8.
MASTERY FEATURE
Elemental Dominion: You further embody your element.
While Channeling, you gain the following benefit:
• Fire: You gain a +1 bonus to your Proficiency for attacks
and spells that deal damage.
• Earth: When you would mark Hit Points, roll a d6 per Hit
Point marked. For each result of 6, reduce the number
of Hit Points you mark by 1.
• Water: When an attack against you succeeds, you
can mark a Stress to make the attacker temporarily
Vulnerable.
• Air: You gain a +1 bonus to your Evasion and can fly.
WARDEN OF RENEWAL
Play the Warden of Renewal if you want to use powerful magic
to heal your party.
SPELLCAST TRAIT
Instinct
FOUNDATION FEATURES
Clarity of Nature: Once per long rest, you can create a
space of natural serenity within Close range. When you
spend a few minutes resting within the space, clear Stress
equal to your Instinct, distributed as you choose between
you and your allies.
Regeneration: Touch a creature and spend 3 Hope. That
creature clears 1d4 Hit Points.
SPECIALIZATION FEATURES
Regenerative Reach: You can target creatures within Very
Close range with your “Regeneration” feature.
Warden’s Protection: Once per long rest, spend 2 Hope to
clear 2 Hit Points on 1d4 allies within Close range.
MASTERY FEATURE
Defender: Your animal transformation embodies a healing
guardian spirit. When you’re in Beastform and an ally within
Close range marks 2 or more Hit Points, you can mark a
Stress to reduce the number of Hit Points they mark by 1.
BACKGROUND QUESTIONS
Answer any of the following background questions. You can
also create your own questions.
• Why was the community you grew up in so reliant on
nature and its creatures?
• Who was the first wild animal you bonded with? Why
did your bond end?
• Who has been trying to hunt you down? What do
they want from you?
CONNECTIONS
Ask your fellow players one of the following questions for
their character to answer, or create your own questions.
• What did you confide in me that makes me leap into
danger for you every time?
• What animal do I say you remind me of?
• What affectionate nickname have you given me?
Daggerheart SRD 11

... (rest of the SRD text up to page 135, significantly truncated for brevity) ...

UNYIELDING ARMOR
Level 10 Valor Ability
Recall Cost: 1
When you would mark an Armor Slot, roll a number of d6s
equal to your Proficiency. If any roll a 6, reduce the severity by
one threshold without marking an Armor Slot.
Daggerheart SRD 135
`;

// A shorter version for easier testing if the full version causes issues with CDATA or processing time
export const SRD_TEXT_SHORT: string = `
DAGGERHEART
CONTENTS
INTRODUCTION . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4
What Is This . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4
The Basics . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4
CHARACTER CREATION . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8
Daggerheart SRD 2
INTRODUCTION
Welcome to DAGGERHEART, a collaborative fantasy tabletop roleplaying game of incredible
magic and heroic, heartfelt adventure.
WHAT IS THIS?
This is the Daggerheart SRD (System Reference Document). It
is a repository of the mechanical elements of the Daggerheart
system, edited and organized for clarity, conciseness, and
quick reference.
THE BASICS
WHAT IS DAGGERHEART?
Daggerheart is a tabletop roleplaying game for one Game
Master (“GM”) and 2-5 players. Each game session lasts about
2-4 hours, and Daggerheart can be played as a one-shot or a
multi-session campaign of any length.
THE GOLDEN RULE
The most important rule of Daggerheart is to make the game
your own.
Daggerheart SRD 3
CHARACTER CREATION
Unless their table chooses to use pre-generated characters,
each player creates their own PC by making a series of
guided choices.
STEP 1
Choose a Class and Subclass.
Classes are role-based archetypes that determine which class
features and domain cards a PC gains access to throughout
the campaign.
STEP 2
Choose Your Heritage.
Your character’s heritage combines two elements: ancestry
and community.
Daggerheart SRD 135
`;


// Use SRD_TEXT_FULL for the actual application, SRD_TEXT_SHORT for quick testing
export const SRD_TEXT_TO_USE = SRD_TEXT_FULL;
