
export const MAJOR_SECTIONS: string[] = [
  "INTRODUCTION",
  "STARTING A CAMPAIGN",
  "CHARACTER CREATION",
  "CORE MATERIALS",
  "CORE MECHANICS",
  "EQUIPMENT", 
  "RUNNING AN ADVENTURE",
  "APPENDIX"
];

export const INTRODUCTION_SUB_TITLES: string[] = [
  "WHAT IS THIS?",
  "THE BASICS"
];

// STARTING A CAMPAIGN sub-sections (from ToC)
export const STARTING_A_CAMPAIGN_SUB_TITLES: string[] = [
  "Session Zero",
  "Setting Creation"
];

// CHARACTER CREATION does not have explicit sub-headings in the ToC for high-level chunking, 
// but the steps (STEP 1, STEP 2 etc.) are within its content. We'll treat it as one chunk for now,
// or break by STEP if deemed necessary later. For now, keeping it simple.

export const SUB_SECTIONS_CORE_MATERIALS: string[] = [
  "DOMAINS", 
  "CLASSES", 
  "ANCESTRIES", 
  "COMMUNITIES" 
];

export const CLASS_TITLES: string[] = ["BARD", "DRUID", "GUARDIAN", "RANGER", "ROGUE", "SERAPH", "SORCERER", "WARRIOR", "WIZARD"];
export const ANCESTRY_TITLES: string[] = ["CLANK", "DRAKONA", "DWARF", "ELF", "FAERIE", "FAUN", "FIRBOLG", "FUNGRIL", "GALAPA", "GIANT", "GOBLIN", "HALFLING", "HUMAN", "INFERNIS", "KATARI", "ORC", "RIBBET", "SIMIAH"]; // Removed "MIXED ANCESTRY"
export const COMMUNITY_TITLES: string[] = ["HIGHBORNE", "LOREBORNE", "ORDERBORNE", "RIDGEBORNE", "SEABORNE", "SLYBORNE", "UNDERBORNE", "WANDERBORNE", "WILDBORNE"];
export const DOMAIN_DESCRIPTION_TITLES: string[] = ["ARCANA", "BLADE", "BONE", "CODEX", "GRACE", "MIDNIGHT", "SAGE", "SPLENDOR", "VALOR"]; // These describe each domain under the "DOMAINS" section of "CORE MATERIALS"

export const CORE_MECHANICS_SUB_TITLES: string[] = [
  "Flow of the Game",
  "Core Gameplay Loop",
  "The Spotlight",
  "Turn Order & Action Economy",
  "Making Moves & Taking Action",
  "Combat",
  "Stress",
  "Attacking",
  "Maps, Range, AND Movement", // Changed from "Maps, Range & Movement"
  "Conditions",
  "Downtime",
  "Death",
  "Additional Rules", // This section in the SRD text contains "Leveling Up" and "Multiclassing"
];

export const SUB_SECTIONS_EQUIPMENT: string[] = [
    "WEAPONS",
    "COMBAT WHEELCHAIR",
    "ARMOR",
    "LOOT",
    "CONSUMABLES"
];

export const RUNNING_AN_ADVENTURE_SUB_TITLES: string[] = [
  "Introduction", // This refers to the introduction within the "RUNNING AN ADVENTURE" section
  "GM Guidance",
  "Core GM Mechanics",
  "Adversaries and Environments",
  "The Witherwild Campaign Frame"
];

export const SUB_SECTIONS_APPENDIX: string[] = [
  "Domain Card Reference"
];

export const DOMAIN_CARD_REFERENCE_TITLES: string[] = [ // Titles for sections under "Domain Card Reference" in APPENDIX
    "ARCANA DOMAIN", "BLADE DOMAIN", "BONE DOMAIN", "CODEX DOMAIN", 
    "GRACE DOMAIN", "MIDNIGHT DOMAIN", "SAGE DOMAIN", "SPLENDOR DOMAIN", "VALOR DOMAIN"
];