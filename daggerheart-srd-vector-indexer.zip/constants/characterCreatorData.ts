
import { SRDData } from '../types';

// Import Core Game Constants
import { TRAIT_NAMES as _TRAIT_NAMES, INITIAL_TRAIT_MODIFIERS as _INITIAL_TRAIT_MODIFIERS } from './data_modules/core_constants';
import type { TraitName as _TraitName } from './data_modules/core_constants';

// Import Domain Data
import { DOMAIN_DESCRIPTIONS as _DOMAIN_DESCRIPTIONS, DOMAINS_LIST as _DOMAINS_LIST } from './data_modules/domain_data';

// Import Class Data
import { ALL_CLASSES as _ALL_CLASSES } from './data_modules/classes/index';

// Import Ancestries Data
import { ANCESTRIES as _ANCESTRIES } from './data_modules/ancestries/index';

// Import Communities Data
import { COMMUNITIES as _COMMUNITIES } from './data_modules/communities/index';

// Import Domain Cards Data
import { DOMAIN_CARDS as _DOMAIN_CARDS } from './data_modules/domain_cards/index';

// Import Equipment Data from the new main equipment index
import {
  ALL_WEAPONS as _ALL_WEAPONS_FROM_EQUIPMENT_INDEX,
  ALL_PRIMARY_WEAPONS as _ALL_PRIMARY_WEAPONS_FROM_EQUIPMENT_INDEX,
  ALL_SECONDARY_WEAPONS as _ALL_SECONDARY_WEAPONS_FROM_EQUIPMENT_INDEX,
  ALL_ARMOR as _ALL_ARMOR_FROM_EQUIPMENT_INDEX,
  ALL_COMBAT_WHEELCHAIRS as _ALL_COMBAT_WHEELCHAIRS_FROM_EQUIPMENT_INDEX,
  // Specific Tier Exports for UI convenience
  WEAPONS_TIER_1_PHYSICAL_PRIMARY as _WEAPONS_TIER_1_PHYSICAL_PRIMARY,
  WEAPONS_TIER_1_MAGIC_PRIMARY as _WEAPONS_TIER_1_MAGIC_PRIMARY,
  WEAPONS_TIER_1_PHYSICAL_SECONDARY as _WEAPONS_TIER_1_PHYSICAL_SECONDARY,
  WEAPONS_TIER_2_PHYSICAL_SECONDARY as _WEAPONS_TIER_2_PHYSICAL_SECONDARY,
  WEAPONS_TIER_3_PHYSICAL_SECONDARY as _WEAPONS_TIER_3_PHYSICAL_SECONDARY,
  WEAPONS_TIER_4_PHYSICAL_SECONDARY as _WEAPONS_TIER_4_PHYSICAL_SECONDARY,
  ARMOR_TIER_1 as _ARMOR_TIER_1
} from './data_modules/equipment';


// Import Items Data
import {
  STARTING_INVENTORY_ITEMS as _STARTING_INVENTORY_ITEMS,
  STARTING_POTION_CHOICES as _STARTING_POTION_CHOICES,
  LOOT_ITEMS as _LOOT_ITEMS,
  CONSUMABLE_ITEMS as _CONSUMABLE_ITEMS
} from './data_modules/items/index';

// Import Beastforms Data
import { BEASTFORM_OPTIONS as _BEASTFORM_OPTIONS } from './data_modules/beastforms/index';

// Import Conditions Data
import { CONDITIONS_DATA as _CONDITIONS_DATA } from './data_modules/conditions';

// Import Game Terms Data
import { GAME_TERMS_DATA as _GAME_TERMS_DATA } from './data_modules/game_terms';

// Import Character Defaults
import { DEFAULT_CHARACTER_DATA as _DEFAULT_CHARACTER_DATA } from './data_modules/character_defaults';

export const MOCK_SRD_DATA: SRDData = {
  classes: _ALL_CLASSES,
  ancestries: _ANCESTRIES,
  communities: _COMMUNITIES,
  weapons: _ALL_WEAPONS_FROM_EQUIPMENT_INDEX, 
  armor: _ALL_ARMOR_FROM_EQUIPMENT_INDEX,
  domainCards: _DOMAIN_CARDS,
  lootItems: _LOOT_ITEMS,
  consumableItems: _CONSUMABLE_ITEMS,
  startingPotionChoices: _STARTING_POTION_CHOICES,
  beastforms: _BEASTFORM_OPTIONS,
  conditions: _CONDITIONS_DATA,
  gameTerms: _GAME_TERMS_DATA, // Added game terms
};

// Now, re-export everything for use by the application
export const TRAIT_NAMES = _TRAIT_NAMES;
export const INITIAL_TRAIT_MODIFIERS = _INITIAL_TRAIT_MODIFIERS;
export type TraitName = _TraitName;

export const DOMAIN_DESCRIPTIONS = _DOMAIN_DESCRIPTIONS;
export const DOMAINS_LIST = _DOMAINS_LIST;

export const CLASSES = _ALL_CLASSES; 
export { BARD_CLASS, DRUID_CLASS, GUARDIAN_CLASS, RANGER_CLASS, ROGUE_CLASS, SERAPH_CLASS, SORCERER_CLASS, WARRIOR_CLASS, WIZARD_CLASS } from './data_modules/classes/index';


export const ANCESTRIES = _ANCESTRIES;
export const COMMUNITIES = _COMMUNITIES;
export const DOMAIN_CARDS = _DOMAIN_CARDS;
export const CONDITIONS_DATA = _CONDITIONS_DATA;
export const GAME_TERMS_DATA = _GAME_TERMS_DATA; // Re-export game terms

export const ALL_WEAPONS = _ALL_WEAPONS_FROM_EQUIPMENT_INDEX;
export const ALL_PRIMARY_WEAPONS = _ALL_PRIMARY_WEAPONS_FROM_EQUIPMENT_INDEX;
export const ALL_SECONDARY_WEAPONS = _ALL_SECONDARY_WEAPONS_FROM_EQUIPMENT_INDEX;
export const ALL_ARMOR = _ALL_ARMOR_FROM_EQUIPMENT_INDEX; 
export const ALL_COMBAT_WHEELCHAIRS = _ALL_COMBAT_WHEELCHAIRS_FROM_EQUIPMENT_INDEX; 

// For direct access to specific tiers if needed by UI logic beyond just MOCK_SRD_DATA
export const WEAPONS_TIER_1_PHYSICAL_PRIMARY = _WEAPONS_TIER_1_PHYSICAL_PRIMARY;
export const WEAPONS_TIER_1_MAGIC_PRIMARY = _WEAPONS_TIER_1_MAGIC_PRIMARY;

export const WEAPONS_TIER_1_PHYSICAL_SECONDARY = _WEAPONS_TIER_1_PHYSICAL_SECONDARY;
export const WEAPONS_TIER_2_PHYSICAL_SECONDARY = _WEAPONS_TIER_2_PHYSICAL_SECONDARY;
export const WEAPONS_TIER_3_PHYSICAL_SECONDARY = _WEAPONS_TIER_3_PHYSICAL_SECONDARY;
export const WEAPONS_TIER_4_PHYSICAL_SECONDARY = _WEAPONS_TIER_4_PHYSICAL_SECONDARY;

export const ARMOR_TIER_1 = _ARMOR_TIER_1;


export const STARTING_INVENTORY_ITEMS = _STARTING_INVENTORY_ITEMS;
export const STARTING_POTION_CHOICES = _STARTING_POTION_CHOICES;
export const LOOT_ITEMS = _LOOT_ITEMS;
export const CONSUMABLE_ITEMS = _CONSUMABLE_ITEMS;

export const BEASTFORM_OPTIONS = _BEASTFORM_OPTIONS;
export type { BeastformData } from '../types'; 

export const DEFAULT_CHARACTER_DATA = _DEFAULT_CHARACTER_DATA;
