
export const DOMAINS_LIST: string[] = [
  "Arcana", "Blade", "Bone", "Codex", "Grace", "Midnight", "Sage", "Splendor", "Valor"
];

export const DOMAIN_DESCRIPTIONS: Record<string, string> = {
  Arcana: "Innate and instinctual magic, manipulating raw energy and elements.",
  Blade: "Mastery of weapons, focused on combat and dealing damage.",
  Bone: "Tactics and control over physical abilities, understanding movement.",
  Codex: "Intensive magical study, knowledge from books, scrolls, and writings.",
  Grace: "Charisma, storytelling, charming spells, and manipulating perception.",
  Midnight: "Shadows, secrecy, trickery, and uncovering hidden things.",
  Sage: "The natural world, earth's power, and animal/plant magic.",
  Splendor: "Life magic, healing, and control over life and death.",
  Valor: "Protection, defense, and formidable strength to shield allies."
};
