
import { ConditionData } from '../../types';

export const CONDITIONS_DATA: ConditionData[] = [
  {
    id: 'vulnerable',
    name: 'Vulnerable',
    description: 'A creature that is Vulnerable has a harder time avoiding harm or mitigating its effects. Specific effects vary by source.',
    effectsSummary: 'Examples: Target difficulty reduced, takes extra damage, or other penalties (e.g., Bard\'s "Make a Scene" gives -2 to target Difficulty; Seraph\'s "Bolt Beacon" makes target temporarily Vulnerable).',
    srdPageReference: 'SRD p. 45 (general concept), various abilities/spells'
  },
  {
    id: 'restrained',
    name: 'Restrained',
    description: 'A Restrained creature has its movement severely limited, and often suffers other penalties.',
    effectsSummary: 'Typically prevents movement and may impose disadvantages on actions or make the creature easier to hit (e.g., "Mystic Tether," "Shadowbind," "Vicious Entangle" can apply this).',
    srdPageReference: 'SRD p. 45 (general concept), various spells'
  },
  {
    id: 'stunned',
    name: 'Stunned',
    description: 'A Stunned creature is dazed and unable to act effectively.',
    effectsSummary: 'Usually prevents actions and reactions, and may make the creature easier to hit (e.g., "Hypnotic Shimmer," "Stunning Sunlight" can apply this).',
    srdPageReference: 'SRD p. 45 (general concept), various spells'
  },
  {
    id: 'cloaked',
    name: 'Cloaked',
    description: 'A Cloaked creature is obscured from sight, often by magical means or stealth.',
    effectsSummary: 'Grants benefits of Hidden. Remains unseen if stationary when an adversary moves to where they would normally see you. Ends after making an attack or ending a move in line of sight. (Rogue class feature; Nightwalker subclass features).',
    srdPageReference: 'SRD p. 21 (Rogue), various Rogue abilities'
  },
  {
    id: 'hidden',
    name: 'Hidden',
    description: 'A Hidden creature is unseen and unheard.',
    effectsSummary: 'Attacks against a Hidden creature usually have disadvantage, and attacks made by a Hidden creature may have advantage. The specific Daggerheart benefits are linked to being Cloaked.',
    srdPageReference: 'SRD p. 45 (general concept), implied by Cloaked'
  },
  {
    id: 'distracted',
    name: 'Distracted',
    description: 'A Distracted creature has its attention diverted, making it less effective.',
    effectsSummary: 'Example: Target gets -2 penalty to their Difficulty (Bard\'s "Make a Scene" Hope Feature).',
    srdPageReference: 'SRD p. 14 (Bard)'
  },
   {
    id: 'asleep',
    name: 'Asleep',
    description: 'An Asleep creature is unconscious and unaware of its surroundings.',
    effectsSummary: 'Typically incapacitated and Vulnerable. Clears on taking damage or via specific actions (e.g., Codex "Book of Illiat - Slumber" spell).',
    srdPageReference: 'SRD p. 74 (Book of Illiat)'
  },
  {
    id: 'silenced',
    name: 'Silenced',
    description: 'A Silenced creature or area prevents sound, including spellcasting with verbal components.',
    effectsSummary: 'Cannot make noise or cast spells (e.g., Midnight "Hush" spell).',
    srdPageReference: 'SRD p. 90 (Hush)'
  },
   {
    id: 'on_fire',
    name: 'On Fire',
    description: 'A creature that is On Fire is taking continuous fire damage.',
    effectsSummary: 'Takes extra damage at the end of their action if still On Fire (e.g., Arcana "Cinder Grasp" spell).',
    srdPageReference: 'SRD p. 65 (Cinder Grasp)'
  },
  {
    id: 'corroded',
    name: 'Corroded',
    description: 'A Corroded target has its defenses weakened.',
    effectsSummary: 'Target gains a penalty to their Difficulty (e.g., Sage "Corrosive Projectile" spell).',
    srdPageReference: 'SRD p. 97 (Corrosive Projectile)'
  },
  // Add other conditions mentioned in SRD text if desired, e.g., Horrified, Spectral.
];
