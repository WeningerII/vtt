
import { Weapon } from '../../../types';

// SRD Page 54
export const COMBAT_WHEELCHAIR_HEAVY_FRAME_TIER_1: Weapon =
  { id: 'cw_heavy_t1', name: 'Heavy-Frame Wheelchair', tier: 1, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+3 phy', burden: 'Two-Handed', feature: 'Heavy: −1 to Evasion' };

export const COMBAT_WHEELCHAIR_HEAVY_FRAME_TIER_2: Weapon =
  { id: 'cw_heavy_t2', name: 'Improved Heavy-Frame Wheelchair', tier: 2, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+6 phy', burden: 'Two-Handed', feature: 'Heavy: −1 to Evasion' };

export const COMBAT_WHEELCHAIR_HEAVY_FRAME_TIER_3: Weapon =
  { id: 'cw_heavy_t3', name: 'Advanced Heavy-Frame Wheelchair', tier: 3, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+9 phy', burden: 'Two-Handed', feature: 'Heavy: −1 to Evasion' };

export const COMBAT_WHEELCHAIR_HEAVY_FRAME_TIER_4: Weapon =
  { id: 'cw_heavy_t4', name: 'Legendary Heavy-Frame Wheelchair', tier: 4, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+12 phy', burden: 'Two-Handed', feature: 'Heavy: −1 to Evasion' };
  
export const ALL_HEAVY_FRAME_WHEELCHAIRS: Weapon[] = [
    COMBAT_WHEELCHAIR_HEAVY_FRAME_TIER_1,
    COMBAT_WHEELCHAIR_HEAVY_FRAME_TIER_2,
    COMBAT_WHEELCHAIR_HEAVY_FRAME_TIER_3,
    COMBAT_WHEELCHAIR_HEAVY_FRAME_TIER_4,
];
