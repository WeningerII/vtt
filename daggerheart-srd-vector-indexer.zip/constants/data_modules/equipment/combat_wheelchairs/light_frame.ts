
import { Weapon } from '../../../types';

// SRD Page 53
export const COMBAT_WHEELCHAIR_LIGHT_FRAME_TIER_1: Weapon =
  { id: 'cw_light_t1', name: 'Light-Frame Wheelchair', tier: 1, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8 phy', burden: 'One-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' };

export const COMBAT_WHEELCHAIR_LIGHT_FRAME_TIER_2: Weapon =
  { id: 'cw_light_t2', name: 'Improved Light-Frame Wheelchair', tier: 2, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+3 phy', burden: 'One-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' };

export const COMBAT_WHEELCHAIR_LIGHT_FRAME_TIER_3: Weapon =
  { id: 'cw_light_t3', name: 'Advanced Light-Frame Wheelchair', tier: 3, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+6 phy', burden: 'One-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' };

export const COMBAT_WHEELCHAIR_LIGHT_FRAME_TIER_4: Weapon =
  { id: 'cw_light_t4', name: 'Legendary Light-Frame Wheelchair', tier: 4, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+9 phy', burden: 'One-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' };

export const ALL_LIGHT_FRAME_WHEELCHAIRS: Weapon[] = [
    COMBAT_WHEELCHAIR_LIGHT_FRAME_TIER_1,
    COMBAT_WHEELCHAIR_LIGHT_FRAME_TIER_2,
    COMBAT_WHEELCHAIR_LIGHT_FRAME_TIER_3,
    COMBAT_WHEELCHAIR_LIGHT_FRAME_TIER_4,
];
