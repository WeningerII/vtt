
import { Weapon } from '../../../types';

// SRD Page 54
// Note: 'trait' is 'Spellcast' which implies Spellcast Trait of the character's subclass.
export const COMBAT_WHEELCHAIR_ARCANE_FRAME_TIER_1: Weapon =
  { id: 'cw_arcane_t1', name: 'Arcane-Frame Wheelchair', tier: 1, category: 'Primary', trait: 'Spellcast', range: 'Far', damage: 'd6 mag', burden: 'One-Handed', feature: 'Reliable: +1 to attack rolls. Requires Spellcast trait.' };

export const COMBAT_WHEELCHAIR_ARCANE_FRAME_TIER_2: Weapon =
  { id: 'cw_arcane_t2', name: 'Improved Arcane-Frame Wheelchair', tier: 2, category: 'Primary', trait: 'Spellcast', range: 'Far', damage: 'd6+3 mag', burden: 'One-Handed', feature: 'Reliable: +1 to attack rolls. Requires Spellcast trait.' };

export const COMBAT_WHEELCHAIR_ARCANE_FRAME_TIER_3: Weapon =
  { id: 'cw_arcane_t3', name: 'Advanced Arcane-Frame Wheelchair', tier: 3, category: 'Primary', trait: 'Spellcast', range: 'Far', damage: 'd6+6 mag', burden: 'One-Handed', feature: 'Reliable: +1 to attack rolls. Requires Spellcast trait.' };

export const COMBAT_WHEELCHAIR_ARCANE_FRAME_TIER_4: Weapon =
  { id: 'cw_arcane_t4', name: 'Legendary Arcane-Frame Wheelchair', tier: 4, category: 'Primary', trait: 'Spellcast', range: 'Far', damage: 'd6+9 mag', burden: 'One-Handed', feature: 'Reliable: +1 to attack rolls. Requires Spellcast trait.' };

export const ALL_ARCANE_FRAME_WHEELCHAIRS: Weapon[] = [
    COMBAT_WHEELCHAIR_ARCANE_FRAME_TIER_1,
    COMBAT_WHEELCHAIR_ARCANE_FRAME_TIER_2,
    COMBAT_WHEELCHAIR_ARCANE_FRAME_TIER_3,
    COMBAT_WHEELCHAIR_ARCANE_FRAME_TIER_4,
];
