
import { Weapon } from '../../../types';

// SRD Page 48 - Note: Tier 3 Primary Weapons table on p48 lists only physical weapons.
// The provided SRD text (pages 45-50) does not include a "TIER 3 (LEVELS 5–7) Magic Weapons" table.
// Thus, this array remains empty.
export const WEAPONS_TIER_3_MAGIC_PRIMARY: Weapon[] = [];
