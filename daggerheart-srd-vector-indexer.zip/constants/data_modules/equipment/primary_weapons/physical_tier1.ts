
import { Weapon } from '../../../types';

// SRD Page 45
export const WEAPONS_TIER_1_PHYSICAL_PRIMARY: Weapon[] = [
  { id: 'wp_t1_phys_broadsword', name: 'Broadsword', tier: 1, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8 phy', burden: 'One-Handed', feature: 'Reliable: +1 to attack rolls' },
  { id: 'wp_t1_phys_longsword', name: 'Longsword', tier: 1, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+3 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t1_phys_battleaxe', name: 'Battleaxe', tier: 1, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+3 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t1_phys_greatsword', name: 'Greatsword', tier: 1, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+3 phy', burden: 'Two-Handed', feature: 'Massive: −1 to Evasion; on a successful attack, roll an additional damage die and discard the lowest result.' },
  { id: 'wp_t1_phys_mace', name: 'Mace', tier: 1, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd8+1 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t1_phys_warhammer', name: 'Warhammer', tier: 1, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+3 phy', burden: 'Two-Handed', feature: 'Heavy: −1 to Evasion' },
  { id: 'wp_t1_phys_dagger', name: 'Dagger', tier: 1, category: 'Primary', trait: 'Finesse', range: 'Melee', damage: 'd8+1 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t1_phys_quarterstaff', name: 'Quarterstaff', tier: 1, category: 'Primary', trait: 'Instinct', range: 'Melee', damage: 'd10+3 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t1_phys_cutlass', name: 'Cutlass', tier: 1, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd8+1 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t1_phys_rapier', name: 'Rapier', tier: 1, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd8 phy', burden: 'One-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' },
  { id: 'wp_t1_phys_halberd', name: 'Halberd', tier: 1, category: 'Primary', trait: 'Strength', range: 'Very Close', damage: 'd10+2 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t1_phys_spear', name: 'Spear', tier: 1, category: 'Primary', trait: 'Finesse', range: 'Very Close', damage: 'd10+2 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t1_phys_shortbow', name: 'Shortbow', tier: 1, category: 'Primary', trait: 'Agility', range: 'Far', damage: 'd6+3 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t1_phys_crossbow', name: 'Crossbow', tier: 1, category: 'Primary', trait: 'Finesse', range: 'Far', damage: 'd6+1 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t1_phys_longbow', name: 'Longbow', tier: 1, category: 'Primary', trait: 'Agility', range: 'Very Far', damage: 'd8+3 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
];
