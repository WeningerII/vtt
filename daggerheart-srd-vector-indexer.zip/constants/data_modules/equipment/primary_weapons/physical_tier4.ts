
import { Weapon } from '../../../types';

// SRD Page 49
export const WEAPONS_TIER_4_PHYSICAL_PRIMARY: Weapon[] = [
  { id: 'wp_t4_phys_leg_broadsword', name: 'Legendary Broadsword', tier: 4, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+9 phy', burden: 'One-Handed', feature: 'Reliable: +1 to attack rolls' },
  { id: 'wp_t4_phys_leg_longsword', name: 'Legendary Longsword', tier: 4, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+12 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t4_phys_leg_battleaxe', name: 'Legendary Battleaxe', tier: 4, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+12 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t4_phys_leg_greatsword', name: 'Legendary Greatsword', tier: 4, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+12 phy', burden: 'Two-Handed', feature: 'Massive: −1 to Evasion; on a successful attack, roll an additional damage die and discard the lowest result.' },
  { id: 'wp_t4_phys_leg_mace', name: 'Legendary Mace', tier: 4, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd8+10 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t4_phys_leg_warhammer', name: 'Legendary Warhammer', tier: 4, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+12 phy', burden: 'Two-Handed', feature: 'Heavy: −1 to Evasion' },
  { id: 'wp_t4_phys_leg_dagger', name: 'Legendary Dagger', tier: 4, category: 'Primary', trait: 'Finesse', range: 'Melee', damage: 'd8+10 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t4_phys_leg_quarterstaff', name: 'Legendary Quarterstaff', tier: 4, category: 'Primary', trait: 'Instinct', range: 'Melee', damage: 'd10+12 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t4_phys_leg_cutlass', name: 'Legendary Cutlass', tier: 4, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd8+10 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t4_phys_leg_rapier', name: 'Legendary Rapier', tier: 4, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd8+9 phy', burden: 'One-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' },
  { id: 'wp_t4_phys_leg_halberd', name: 'Legendary Halberd', tier: 4, category: 'Primary', trait: 'Strength', range: 'Very Close', damage: 'd10+11 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t4_phys_leg_spear', name: 'Legendary Spear', tier: 4, category: 'Primary', trait: 'Finesse', range: 'Very Close', damage: 'd10+11 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t4_phys_leg_shortbow', name: 'Legendary Shortbow', tier: 4, category: 'Primary', trait: 'Agility', range: 'Far', damage: 'd6+12 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t4_phys_leg_crossbow', name: 'Legendary Crossbow', tier: 4, category: 'Primary', trait: 'Finesse', range: 'Far', damage: 'd6+10 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t4_phys_leg_longbow', name: 'Legendary Longbow', tier: 4, category: 'Primary', trait: 'Agility', range: 'Very Far', damage: 'd8+12 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t4_phys_dual_ended_sword', name: 'Dual-Ended Sword', tier: 4, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd10+9 phy', burden: 'Two-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' },
  { id: 'wp_t4_phys_impact_gauntlet', name: 'Impact Gauntlet', tier: 4, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+11 phy', burden: 'One-Handed', feature: 'Concussive: On a successful attack, you can spend a Hope to knock the target back to Far range.' },
  { id: 'wp_t4_phys_sledge_axe', name: 'Sledge Axe', tier: 4, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+13 phy', burden: 'Two-Handed', feature: 'Destructive: −1 to Agility; on a successful attack, all adversaries within Very Close range must mark a Stress.' },
  { id: 'wp_t4_phys_curved_dagger', name: 'Curved Dagger', tier: 4, category: 'Primary', trait: 'Finesse', range: 'Melee', damage: 'd8+9 phy', burden: 'One-Handed', feature: 'Serrated: When you roll a 1 on a damage die, it deals 8 damage instead.' },
  { id: 'wp_t4_phys_extended_polearm', name: 'Extended Polearm', tier: 4, category: 'Primary', trait: 'Finesse', range: 'Very Close', damage: 'd8+10 phy', burden: 'Two-Handed', feature: 'Long: This weapon’s attack targets all adversaries in a line within range.' },
  { id: 'wp_t4_phys_swinging_ropeblade', name: 'Swinging Ropeblade', tier: 4, category: 'Primary', trait: 'Presence', range: 'Close', damage: 'd8+9 phy', burden: 'Two-Handed', feature: 'Grappling: On a successful attack, you can spend a Hope to Restrain the target or pull them into Melee range with you.' },
  { id: 'wp_t4_phys_ricochet_axes', name: 'Ricochet Axes', tier: 4, category: 'Primary', trait: 'Agility', range: 'Far', damage: 'd6+11 phy', burden: 'Two-Handed', feature: 'Bouncing: Mark 1 or more Stress to hit that many targets in range of the attack.' },
  { id: 'wp_t4_phys_aantari_bow', name: 'Aantari Bow', tier: 4, category: 'Primary', trait: 'Finesse', range: 'Far', damage: 'd6+11 phy', burden: 'Two-Handed', feature: 'Reliable: +1 to attack rolls' },
  { id: 'wp_t4_phys_hand_cannon', name: 'Hand Cannon', tier: 4, category: 'Primary', trait: 'Finesse', range: 'Very Far', damage: 'd6+12 phy', burden: 'One-Handed', feature: 'Reloading: After you make an attack, roll a d6. On a 1, you must mark a Stress to reload this weapon before you can fire it again.' },
];
