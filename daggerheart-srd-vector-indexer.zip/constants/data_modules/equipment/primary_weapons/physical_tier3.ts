
import { Weapon } from '../../../types';

// SRD Page 48
export const WEAPONS_TIER_3_PHYSICAL_PRIMARY: Weapon[] = [
  { id: 'wp_t3_phys_adv_broadsword', name: 'Advanced Broadsword', tier: 3, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+6 phy', burden: 'One-Handed', feature: 'Reliable: +1 to attack rolls' },
  { id: 'wp_t3_phys_adv_longsword', name: 'Advanced Longsword', tier: 3, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+9 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t3_phys_adv_battleaxe', name: 'Advanced Battleaxe', tier: 3, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+9 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t3_phys_adv_greatsword', name: 'Advanced Greatsword', tier: 3, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+9 phy', burden: 'Two-Handed', feature: 'Massive: −1 to Evasion; on a successful attack, roll an additional damage die and discard the lowest result.' },
  { id: 'wp_t3_phys_adv_mace', name: 'Advanced Mace', tier: 3, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd8+7 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t3_phys_adv_warhammer', name: 'Advanced Warhammer', tier: 3, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+9 phy', burden: 'Two-Handed', feature: 'Heavy: −1 to Evasion' },
  { id: 'wp_t3_phys_adv_dagger', name: 'Advanced Dagger', tier: 3, category: 'Primary', trait: 'Finesse', range: 'Melee', damage: 'd8+7 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t3_phys_adv_quarterstaff', name: 'Advanced Quarterstaff', tier: 3, category: 'Primary', trait: 'Instinct', range: 'Melee', damage: 'd10+9 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t3_phys_adv_cutlass', name: 'Advanced Cutlass', tier: 3, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd8+7 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t3_phys_adv_rapier', name: 'Advanced Rapier', tier: 3, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd8+6 phy', burden: 'One-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' },
  { id: 'wp_t3_phys_adv_halberd', name: 'Advanced Halberd', tier: 3, category: 'Primary', trait: 'Strength', range: 'Very Close', damage: 'd10+8 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t3_phys_adv_spear', name: 'Advanced Spear', tier: 3, category: 'Primary', trait: 'Finesse', range: 'Very Close', damage: 'd10+8 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t3_phys_adv_shortbow', name: 'Advanced Shortbow', tier: 3, category: 'Primary', trait: 'Agility', range: 'Far', damage: 'd6+9 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t3_phys_adv_crossbow', name: 'Advanced Crossbow', tier: 3, category: 'Primary', trait: 'Finesse', range: 'Far', damage: 'd6+7 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t3_phys_adv_longbow', name: 'Advanced Longbow', tier: 3, category: 'Primary', trait: 'Agility', range: 'Very Far', damage: 'd8+9 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t3_phys_flickerfly_blade', name: 'Flickerfly Blade', tier: 3, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+5 phy', burden: 'One-Handed', feature: 'Sharpwing: Gain a bonus to your damage rolls equal to your Agility.' },
  { id: 'wp_t3_phys_bravesword', name: 'Bravesword', tier: 3, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+7 phy', burden: 'Two-Handed', feature: 'Brave: −1 to Evasion; +3 to Severe damage threshold' },
  { id: 'wp_t3_phys_hammer_of_wrath', name: 'Hammer of Wrath', tier: 3, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+7 phy', burden: 'Two-Handed', feature: 'Devastating: Before you make an attack roll, you can mark a Stress to use a d20 as your damage die.' },
  { id: 'wp_t3_phys_labrys_axe', name: 'Labrys Axe', tier: 3, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+7 phy', burden: 'Two-Handed', feature: 'Protective: +1 to Armor Score' },
  { id: 'wp_t3_phys_meridian_cutlass', name: 'Meridian Cutlass', tier: 3, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd10+5 phy', burden: 'One-Handed', feature: 'Dueling: When there are no other creatures within Close range of the target, gain advantage on your attack roll against them.' },
  { id: 'wp_t3_phys_retractable_saber', name: 'Retractable Saber', tier: 3, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd10+7 phy', burden: 'One-Handed', feature: 'Retractable: The blade can be hidden in the hilt to avoid detection.' },
  { id: 'wp_t3_phys_double_flail', name: 'Double Flail', tier: 3, category: 'Primary', trait: 'Agility', range: 'Very Close', damage: 'd10+8 phy', burden: 'Two-Handed', feature: 'Powerful: On a successful attack, roll an additional damage die and discard the lowest result.' },
  { id: 'wp_t3_phys_talon_blades', name: 'Talon Blades', tier: 3, category: 'Primary', trait: 'Finesse', range: 'Close', damage: 'd10+7 phy', burden: 'Two-Handed', feature: 'Brutal: When you roll the maximum value on a damage die, roll an additional damage die.' },
  { id: 'wp_t3_phys_black_powder_revolver', name: 'Black Powder Revolver', tier: 3, category: 'Primary', trait: 'Finesse', range: 'Far', damage: 'd6+8 phy', burden: 'One-Handed', feature: 'Reloading: After you make an attack, roll a d6. On a result of 1, you must mark a Stress to reload this weapon before you can fire it again.' },
  { id: 'wp_t3_phys_spiked_bow', name: 'Spiked Bow', tier: 3, category: 'Primary', trait: 'Agility', range: 'Very Far', damage: 'd6+7 phy', burden: 'Two-Handed', feature: 'Versatile: This weapon can also be used with these statistics—Agility, Melee, d10+5.' },
];
