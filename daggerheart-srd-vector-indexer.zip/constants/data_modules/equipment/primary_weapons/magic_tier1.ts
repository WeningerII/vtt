
import { Weapon } from '../../../types';

// SRD Page 45
export const WEAPONS_TIER_1_MAGIC_PRIMARY: Weapon[] = [
  { id: 'wp_t1_mag_arcane_gauntlets', name: 'Arcane Gauntlets', tier: 1, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+3 mag', burden: 'Two-Handed', feature: 'Requires Spellcast trait.' },
  { id: 'wp_t1_mag_hallowed_axe', name: 'Hallowed Axe', tier: 1, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd8+1 mag', burden: 'One-Handed', feature: 'Requires Spellcast trait.' },
  { id: 'wp_t1_mag_glowing_rings', name: 'Glowing Rings', tier: 1, category: 'Primary', trait: 'Agility', range: 'Very Close', damage: 'd10+1 mag', burden: 'Two-Handed', feature: 'Requires Spellcast trait.' },
  { id: 'wp_t1_mag_hand_runes', name: 'Hand Runes', tier: 1, category: 'Primary', trait: 'Instinct', range: 'Very Close', damage: 'd10 mag', burden: 'One-Handed', feature: 'Requires Spellcast trait.' },
  { id: 'wp_t1_mag_returning_blade', name: 'Returning Blade', tier: 1, category: 'Primary', trait: 'Finesse', range: 'Close', damage: 'd8 mag', burden: 'One-Handed', feature: 'Returning: When this weapon is thrown within its range, it appears in your hand immediately after the attack. Requires Spellcast trait.' },
  { id: 'wp_t1_mag_shortstaff', name: 'Shortstaff', tier: 1, category: 'Primary', trait: 'Instinct', range: 'Close', damage: 'd8+1 mag', burden: 'One-Handed', feature: 'Requires Spellcast trait.' },
  { id: 'wp_t1_mag_dualstaff', name: 'Dualstaff', tier: 1, category: 'Primary', trait: 'Instinct', range: 'Far', damage: 'd6+3 mag', burden: 'Two-Handed', feature: 'Requires Spellcast trait.' },
  { id: 'wp_t1_mag_scepter', name: 'Scepter', tier: 1, category: 'Primary', trait: 'Presence', range: 'Far', damage: 'd6 mag', burden: 'Two-Handed', feature: 'Versatile: This weapon can also be used with these statistics—Presence, Melee, d8. Requires Spellcast trait.' },
  { id: 'wp_t1_mag_wand', name: 'Wand', tier: 1, category: 'Primary', trait: 'Knowledge', range: 'Far', damage: 'd6+1 mag', burden: 'One-Handed', feature: 'Requires Spellcast trait.' },
  { id: 'wp_t1_mag_greatstaff', name: 'Greatstaff', tier: 1, category: 'Primary', trait: 'Knowledge', range: 'Very Far', damage: 'd6 mag', burden: 'Two-Handed', feature: 'Powerful: On a successful attack, roll an additional damage die and discard the lowest result. Requires Spellcast trait.' },
];
