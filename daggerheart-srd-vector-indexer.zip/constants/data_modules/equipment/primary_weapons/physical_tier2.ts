
import { Weapon } from '../../../types';

// SRD Page 46
export const WEAPONS_TIER_2_PHYSICAL_PRIMARY: Weapon[] = [
  { id: 'wp_t2_phys_imp_broadsword', name: 'Improved Broadsword', tier: 2, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+3 phy', burden: 'One-Handed', feature: 'Reliable: +1 to attack rolls' },
  { id: 'wp_t2_phys_imp_longsword', name: 'Improved Longsword', tier: 2, category: 'Primary', trait: 'Agility', range: 'Melee', damage: 'd8+6 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t2_phys_imp_battleaxe', name: 'Improved Battleaxe', tier: 2, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+6 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t2_phys_imp_greatsword', name: 'Improved Greatsword', tier: 2, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+6 phy', burden: 'Two-Handed', feature: 'Massive: −1 to Evasion; on a successful attack, roll an additional damage die and discard the lowest result.' },
  { id: 'wp_t2_phys_imp_mace', name: 'Improved Mace', tier: 2, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd8+4 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t2_phys_imp_warhammer', name: 'Improved Warhammer', tier: 2, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd12+6 phy', burden: 'Two-Handed', feature: 'Heavy: −1 to Evasion' },
  { id: 'wp_t2_phys_imp_dagger', name: 'Improved Dagger', tier: 2, category: 'Primary', trait: 'Finesse', range: 'Melee', damage: 'd8+4 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t2_phys_imp_quarterstaff', name: 'Improved Quarterstaff', tier: 2, category: 'Primary', trait: 'Instinct', range: 'Melee', damage: 'd10+6 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t2_phys_imp_cutlass', name: 'Improved Cutlass', tier: 2, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd8+4 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t2_phys_imp_rapier', name: 'Improved Rapier', tier: 2, category: 'Primary', trait: 'Presence', range: 'Melee', damage: 'd8+3 phy', burden: 'One-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' },
  { id: 'wp_t2_phys_imp_halberd', name: 'Improved Halberd', tier: 2, category: 'Primary', trait: 'Strength', range: 'Very Close', damage: 'd10+5 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t2_phys_imp_spear', name: 'Improved Spear', tier: 2, category: 'Primary', trait: 'Finesse', range: 'Very Close', damage: 'd10+5 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t2_phys_imp_shortbow', name: 'Improved Shortbow', tier: 2, category: 'Primary', trait: 'Agility', range: 'Far', damage: 'd6+6 phy', burden: 'Two-Handed', feature: '—' },
  { id: 'wp_t2_phys_imp_crossbow', name: 'Improved Crossbow', tier: 2, category: 'Primary', trait: 'Finesse', range: 'Far', damage: 'd6+4 phy', burden: 'One-Handed', feature: '—' },
  { id: 'wp_t2_phys_imp_longbow', name: 'Improved Longbow', tier: 2, category: 'Primary', trait: 'Agility', range: 'Very Far', damage: 'd8+6 phy', burden: 'Two-Handed', feature: 'Cumbersome: −1 to Finesse' },
  { id: 'wp_t2_phys_gilded_falchion', name: 'Gilded Falchion', tier: 2, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+4 phy', burden: 'One-Handed', feature: 'Powerful: On a successful attack, roll an additional damage die and discard the lowest result.' },
  { id: 'wp_t2_phys_knuckle_blades', name: 'Knuckle Blades', tier: 2, category: 'Primary', trait: 'Strength', range: 'Melee', damage: 'd10+6 phy', burden: 'Two-Handed', feature: 'Brutal: When you roll the maximum value on a damage die, roll an additional damage die.' },
  { id: 'wp_t2_phys_urok_broadsword', name: 'Urok Broadsword', tier: 2, category: 'Primary', trait: 'Finesse', range: 'Melee', damage: 'd8+3 phy', burden: 'One-Handed', feature: 'Deadly: When you deal Severe damage, the target must mark an additional HP.' },
  { id: 'wp_t2_phys_bladed_whip', name: 'Bladed Whip', tier: 2, category: 'Primary', trait: 'Agility', range: 'Very Close', damage: 'd8+3 phy', burden: 'One-Handed', feature: 'Quick: When you make an attack, you can mark a Stress to target another creature within range.' },
  { id: 'wp_t2_phys_steelforged_halberd', name: 'Steelforged Halberd', tier: 2, category: 'Primary', trait: 'Strength', range: 'Very Close', damage: 'd8+4 phy', burden: 'Two-Handed', feature: 'Scary: On a successful attack, the target must mark a Stress.' },
  { id: 'wp_t2_phys_war_scythe', name: 'War Scythe', tier: 2, category: 'Primary', trait: 'Finesse', range: 'Very Close', damage: 'd8+5 phy', burden: 'Two-Handed', feature: 'Reliable: +1 to attack rolls' },
  { id: 'wp_t2_phys_blunderbuss', name: 'Blunderbuss', tier: 2, category: 'Primary', trait: 'Finesse', range: 'Close', damage: 'd8+6 phy', burden: 'Two-Handed', feature: 'Reloading: After you make an attack, roll a d6. On a result of 1, you must mark a Stress to reload this weapon before you can fire it again.' },
  { id: 'wp_t2_phys_greatbow', name: 'Greatbow', tier: 2, category: 'Primary', trait: 'Strength', range: 'Far', damage: 'd6+6 phy', burden: 'Two-Handed', feature: 'Powerful: On a successful attack, roll an additional damage die and discard the lowest result.' },
  { id: 'wp_t2_phys_finehair_bow', name: 'Finehair Bow', tier: 2, category: 'Primary', trait: 'Agility', range: 'Very Far', damage: 'd6+5 phy', burden: 'Two-Handed', feature: 'Reliable: +1 to attack rolls' },
];
