
import { Weapon } from '../../../types';

// SRD Page 52
export const WEAPONS_TIER_4_PHYSICAL_SECONDARY: Weapon[] = [
    { id: 'ws_t4_phys_leg_shortsword', name: 'Legendary Shortsword', tier: 4, category: 'Secondary', trait: 'Agility', range: 'Melee', damage: 'd8+6 phy', burden: 'One-Handed', feature: 'Paired: +5 to primary weapon damage to targets within Melee range' },
    { id: 'ws_t4_phys_leg_round_shield', name: 'Legendary Round Shield', tier: 4, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd4+6 phy', burden: 'One-Handed', feature: 'Protective: +4 to Armor Score' },
    { id: 'ws_t4_phys_leg_tower_shield', name: 'Legendary Tower Shield', tier: 4, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd6+6 phy', burden: 'One-Handed', feature: 'Barrier: +5 to Armor Score; −1 to Evasion.' }, // SRD Text has a period at the end, kept for consistency.
    { id: 'ws_t4_phys_leg_small_dagger', name: 'Legendary Small Dagger', tier: 4, category: 'Secondary', trait: 'Finesse', range: 'Melee', damage: 'd8+6 phy', burden: 'One-Handed', feature: 'Paired: +5 to primary weapon damage to targets within Melee range' },
    { id: 'ws_t4_phys_leg_whip', name: 'Legendary Whip', tier: 4, category: 'Secondary', trait: 'Presence', range: 'Very Close', damage: 'd6+6 phy', burden: 'One-Handed', feature: 'Startling: Mark a Stress to crack the whip and force all adversaries within Melee range back to Close range.' },
    { id: 'ws_t4_phys_leg_grappler', name: 'Legendary Grappler', tier: 4, category: 'Secondary', trait: 'Finesse', range: 'Close', damage: 'd6+6 phy', burden: 'One-Handed', feature: 'Hooked: On a successful attack, you can pull the target into Melee range.' },
    { id: 'ws_t4_phys_leg_hand_crossbow', name: 'Legendary Hand Crossbow', tier: 4, category: 'Secondary', trait: 'Finesse', range: 'Far', damage: 'd6+7 phy', burden: 'One-Handed', feature: '—' },
    { id: 'ws_t4_phys_braveshield', name: 'Braveshield', tier: 4, category: 'Secondary', trait: 'Agility', range: 'Melee', damage: 'd4+6 phy', burden: 'One-Handed', feature: 'Sheltering: When you mark an Armor Slot, it reduces damage for you and all allies within Melee range of you who took the same damage.' },
    { id: 'ws_t4_phys_knuckle_claws', name: 'Knuckle Claws', tier: 4, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd6+8 phy', burden: 'One-Handed', feature: 'Doubled Up: When you make an attack with your primary weapon, you can deal damage to another target within Melee range.' },
    { id: 'ws_t4_phys_primer_shard', name: 'Primer Shard', tier: 4, category: 'Secondary', trait: 'Instinct', range: 'Very Close', damage: 'd4 phy', burden: 'One-Handed', feature: 'Locked On: On a successful attack, your next attack against the same target with your primary weapon automatically succeeds.' },
];
