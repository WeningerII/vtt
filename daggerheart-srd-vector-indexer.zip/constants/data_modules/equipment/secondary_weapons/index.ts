
import { Weapon } from '../../../types';
import { WEAPONS_TIER_1_PHYSICAL_SECONDARY } from './physical_tier1';
import { WEAPONS_TIER_2_PHYSICAL_SECONDARY } from './physical_tier2';
import { WEAPONS_TIER_3_PHYSICAL_SECONDARY } from './physical_tier3';
import { WEAPONS_TIER_4_PHYSICAL_SECONDARY } from './physical_tier4';

// Note: SRD pp. 51-52 only lists physical secondary weapons.
// Magic secondary weapons are not present in this data dump.

export const ALL_SECONDARY_PHYSICAL_WEAPONS: Weapon[] = [
  ...WEAPONS_TIER_1_PHYSICAL_SECONDARY,
  ...WEAPONS_TIER_2_PHYSICAL_SECONDARY,
  ...WEAPONS_TIER_3_PHYSICAL_SECONDARY,
  ...WEAPONS_TIER_4_PHYSICAL_SECONDARY,
];

export const ALL_SECONDARY_MAGIC_WEAPONS: Weapon[] = []; // Empty as per SRD

export const ALL_SECONDARY_WEAPONS: Weapon[] = [
  ...ALL_SECONDARY_PHYSICAL_WEAPONS,
  // ...ALL_SECONDARY_MAGIC_WEAPONS, // No magic secondary weapons listed in SRD pp. 51-52
];

// Re-export individual tier arrays for potential granular access
export {
  WEAPONS_TIER_1_PHYSICAL_SECONDARY,
  WEAPONS_TIER_2_PHYSICAL_SECONDARY,
  WEAPONS_TIER_3_PHYSICAL_SECONDARY,
  WEAPONS_TIER_4_PHYSICAL_SECONDARY,
};
