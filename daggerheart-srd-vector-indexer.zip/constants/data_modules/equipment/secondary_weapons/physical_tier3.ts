
import { Weapon } from '../../../types';

// SRD Page 52
export const WEAPONS_TIER_3_PHYSICAL_SECONDARY: Weapon[] = [
    { id: 'ws_t3_phys_adv_shortsword', name: 'Advanced Shortsword', tier: 3, category: 'Secondary', trait: 'Agility', range: 'Melee', damage: 'd8+4 phy', burden: 'One-Handed', feature: 'Paired: +4 to primary weapon damage to targets within Melee range' },
    { id: 'ws_t3_phys_adv_round_shield', name: 'Advanced Round Shield', tier: 3, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd4+4 phy', burden: 'One-Handed', feature: 'Protective: +3 to Armor Score' },
    { id: 'ws_t3_phys_adv_tower_shield', name: 'Advanced Tower Shield', tier: 3, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd6+4 phy', burden: 'One-Handed', feature: 'Barrier: +4 to Armor Score; −1 to Evasion' },
    { id: 'ws_t3_phys_adv_small_dagger', name: 'Advanced Small Dagger', tier: 3, category: 'Secondary', trait: 'Finesse', range: 'Melee', damage: 'd8+4 phy', burden: 'One-Handed', feature: 'Paired: +4 to primary weapon damage to targets within Melee range' },
    { id: 'ws_t3_phys_adv_whip', name: 'Advanced Whip', tier: 3, category: 'Secondary', trait: 'Presence', range: 'Very Close', damage: 'd6+4 phy', burden: 'One-Handed', feature: 'Startling: Mark a Stress to crack the whip and force all adversaries within Melee range back to Close range.' },
    { id: 'ws_t3_phys_adv_grappler', name: 'Advanced Grappler', tier: 3, category: 'Secondary', trait: 'Finesse', range: 'Close', damage: 'd6+4 phy', burden: 'One-Handed', feature: 'Hooked: On a successful attack, you can pull the target into Melee range.' },
    { id: 'ws_t3_phys_adv_hand_crossbow', name: 'Advanced Hand Crossbow', tier: 3, category: 'Secondary', trait: 'Finesse', range: 'Far', damage: 'd6+5 phy', burden: 'One-Handed', feature: '—' },
    { id: 'ws_t3_phys_buckler', name: 'Buckler', tier: 3, category: 'Secondary', trait: 'Agility', range: 'Melee', damage: 'd4+4 phy', burden: 'One-Handed', feature: 'Deflecting: When you are attacked, you can mark an Armor Slot to gain a bonus to your Evasion equal to your Armor Score against the attack.' },
    { id: 'ws_t3_phys_powered_gauntlet', name: 'Powered Gauntlet', tier: 3, category: 'Secondary', trait: 'Knowledge', range: 'Close', damage: 'd6+4 phy', burden: 'One-Handed', feature: 'Charged: Mark a Stress to gain a +1 bonus to your Proficiency on a primary weapon attack.' },
    { id: 'ws_t3_phys_hand_sling', name: 'Hand Sling', tier: 3, category: 'Secondary', trait: 'Finesse', range: 'Very Far', damage: 'd6+4 phy', burden: 'One-Handed', feature: 'Versatile: This weapon can also be used with these statistics—Finesse, Close, d8+4.' },
];
