
import { Weapon } from '../../../types';

// SRD Page 51
export const WEAPONS_TIER_2_PHYSICAL_SECONDARY: Weapon[] = [
    { id: 'ws_t2_phys_imp_shortsword', name: 'Improved Shortsword', tier: 2, category: 'Secondary', trait: 'Agility', range: 'Melee', damage: 'd8+2 phy', burden: 'One-Handed', feature: 'Paired: +3 to primary weapon damage to targets within Melee range' },
    { id: 'ws_t2_phys_imp_round_shield', name: 'Improved Round Shield', tier: 2, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd4+2 phy', burden: 'One-Handed', feature: 'Protective: +2 to Armor Score' },
    { id: 'ws_t2_phys_imp_tower_shield', name: 'Improved Tower Shield', tier: 2, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd6+2 phy', burden: 'One-Handed', feature: 'Barrier: +3 to Armor Score; −1 to Evasion' },
    { id: 'ws_t2_phys_imp_small_dagger', name: 'Improved Small Dagger', tier: 2, category: 'Secondary', trait: 'Finesse', range: 'Melee', damage: 'd8+2 phy', burden: 'One-Handed', feature: 'Paired: +3 to primary weapon damage to targets within Melee range' },
    { id: 'ws_t2_phys_imp_whip', name: 'Improved Whip', tier: 2, category: 'Secondary', trait: 'Presence', range: 'Very Close', damage: 'd6+2 phy', burden: 'One-Handed', feature: 'Startling: Mark a Stress to crack the whip and force all adversaries within Melee range back to Close range.' },
    { id: 'ws_t2_phys_imp_grappler', name: 'Improved Grappler', tier: 2, category: 'Secondary', trait: 'Finesse', range: 'Close', damage: 'd6+2 phy', burden: 'One-Handed', feature: 'Hooked: On a successful attack, you can pull the target into Melee range.' },
    { id: 'ws_t2_phys_imp_hand_crossbow', name: 'Improved Hand Crossbow', tier: 2, category: 'Secondary', trait: 'Finesse', range: 'Far', damage: 'd6+3 phy', burden: 'One-Handed', feature: '—' },
    { id: 'ws_t2_phys_spiked_shield', name: 'Spiked Shield', tier: 2, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd6+2 phy', burden: 'One-Handed', feature: 'Double Duty: +1 to Armor Score; +1 to primary weapon damage within Melee range' },
    { id: 'ws_t2_phys_parrying_dagger', name: 'Parrying Dagger', tier: 2, category: 'Secondary', trait: 'Finesse', range: 'Melee', damage: 'd6+2 phy', burden: 'One-Handed', feature: "Parry: When you are attacked, roll this weapon's damage dice. If any of the attacker's damage dice rolled the same value as your dice, the matching results are discarded from the attacker's damage dice before the damage you take is totaled." },
    { id: 'ws_t2_phys_returning_axe', name: 'Returning Axe', tier: 2, category: 'Secondary', trait: 'Agility', range: 'Close', damage: 'd6+4 phy', burden: 'One-Handed', feature: 'Returning: When this weapon is thrown within its range, it appears in your hand immediately after the attack.' },
];
