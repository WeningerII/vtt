
import { Weapon } from '../../../types';

// SRD Page 51
export const WEAPONS_TIER_1_PHYSICAL_SECONDARY: Weapon[] = [
  { id: 'ws_t1_phys_shortsword', name: 'Shortsword', tier: 1, category: 'Secondary', trait: 'Agility', range: 'Melee', damage: 'd8 phy', burden: 'One-Handed', feature: 'Paired: +2 to primary weapon damage to targets within Melee range' },
  { id: 'ws_t1_phys_round_shield', name: 'Round Shield', tier: 1, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd4 phy', burden: 'One-Handed', feature: 'Protective: +1 to Armor Score' },
  { id: 'ws_t1_phys_tower_shield', name: 'Tower Shield', tier: 1, category: 'Secondary', trait: 'Strength', range: 'Melee', damage: 'd6 phy', burden: 'One-Handed', feature: 'Barrier: +2 to Armor Score; −1 to Evasion' },
  { id: 'ws_t1_phys_small_dagger', name: 'Small Dagger', tier: 1, category: 'Secondary', trait: 'Finesse', range: 'Melee', damage: 'd8 phy', burden: 'One-Handed', feature: 'Paired: +2 to primary weapon damage to targets within Melee range' },
  { id: 'ws_t1_phys_whip', name: 'Whip', tier: 1, category: 'Secondary', trait: 'Presence', range: 'Very Close', damage: 'd6 phy', burden: 'One-Handed', feature: 'Startling: Mark a Stress to crack the whip and force all adversaries within Melee range back to Close range.' },
  { id: 'ws_t1_phys_grappler', name: 'Grappler', tier: 1, category: 'Secondary', trait: 'Finesse', range: 'Close', damage: 'd6 phy', burden: 'One-Handed', feature: 'Hooked: On a successful attack, you can pull the target into Melee range.' },
  { id: 'ws_t1_phys_hand_crossbow', name: 'Hand Crossbow', tier: 1, category: 'Secondary', trait: 'Finesse', range: 'Far', damage: 'd6+1 phy', burden: 'One-Handed', feature: '—' },
];
