import { Armor } from '../../../types';

// SRD Page 55
export const ARMOR_TIER_1: Armor[] = [
  { id: 'ar_t1_gambeson', name: 'Gambeson Armor', tier: 1, baseScore: 3, baseThresholds: '5 / 11', feature: 'Flexible: +1 to Evasion' },
  { id: 'ar_t1_leather', name: 'Leather Armor', tier: 1, baseScore: 3, baseThresholds: '6 / 13', feature: '—' },
  { id: 'ar_t1_chainmail', name: 'Chainmail Armor', tier: 1, baseScore: 4, baseThresholds: '7 / 15', feature: 'Heavy: −1 to Evasion' },
  { id: 'ar_t1_full_plate', name: 'Full Plate Armor', tier: 1, baseScore: 4, baseThresholds: '8 / 17', feature: 'Very Heavy: −2 to Evasion; −1 to Agility' },
];
