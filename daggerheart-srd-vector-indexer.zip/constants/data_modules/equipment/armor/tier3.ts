import { Armor } from '../../../types';

// SRD Page 56
export const ARMOR_TIER_3: Armor[] = [
  { id: 'ar_t3_adv_gambeson', name: 'Advanced Gambeson Armor', tier: 3, baseScore: 5, baseThresholds: '9 / 23', feature: 'Flexible: +1 to Evasion' },
  { id: 'ar_t3_adv_leather', name: 'Advanced Leather Armor', tier: 3, baseScore: 5, baseThresholds: '11 / 27', feature: '—' },
  { id: 'ar_t3_adv_chainmail', name: 'Advanced Chainmail Armor', tier: 3, baseScore: 6, baseThresholds: '13 / 31', feature: 'Heavy: −1 to Evasion' },
  { id: 'ar_t3_adv_full_plate', name: 'Advanced Full Plate Armor', tier: 3, baseScore: 6, baseThresholds: '15 / 35', feature: 'Very Heavy: −2 to Evasion; −1 to Agility' },
  { id: 'ar_t3_bellamoi_fine', name: 'Bellamoi Fine Armor', tier: 3, baseScore: 5, baseThresholds: '11 / 27', feature: 'Gilded: +1 to Presence' },
  { id: 'ar_t3_dragonscale', name: 'Dragonscale Armor', tier: 3, baseScore: 5, baseThresholds: '11 / 27', feature: 'Impenetrable: Once per short rest, when you would mark your last Hit Point, you can instead mark a Stress.' },
  { id: 'ar_t3_spiked_plate', name: 'Spiked Plate Armor', tier: 3, baseScore: 5, baseThresholds: '10 / 25', feature: 'Sharp: On a successful attack against a target within Melee range, add a d4 to the damage roll.' },
  { id: 'ar_t3_bladefare', name: 'Bladefare Armor', tier: 3, baseScore: 6, baseThresholds: '16 / 39', feature: 'Physical: You can’t mark an Armor Slot to reduce magic damage.' },
  { id: 'ar_t3_monetts_cloak', name: 'Monett’s Cloak', tier: 3, baseScore: 6, baseThresholds: '16 / 39', feature: 'Magic: You can’t mark an Armor Slot to reduce physical damage.' },
  { id: 'ar_t3_runes_fortification', name: 'Runes of Fortification', tier: 3, baseScore: 6, baseThresholds: '17 / 43', feature: 'Painful: Each time you mark an Armor Slot, you must mark a Stress.' },
];
