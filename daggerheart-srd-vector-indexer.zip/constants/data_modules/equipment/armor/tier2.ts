import { Armor } from '../../../types';

// SRD Page 55
export const ARMOR_TIER_2: Armor[] = [
  { id: 'ar_t2_imp_gambeson', name: 'Improved Gambeson Armor', tier: 2, baseScore: 4, baseThresholds: '7 / 16', feature: 'Flexible: +1 to Evasion' },
  { id: 'ar_t2_imp_leather', name: 'Improved Leather Armor', tier: 2, baseScore: 4, baseThresholds: '9 / 20', feature: '—' },
  { id: 'ar_t2_imp_chainmail', name: 'Improved Chainmail Armor', tier: 2, baseScore: 5, baseThresholds: '11 / 24', feature: 'Heavy: −1 to Evasion' },
  { id: 'ar_t2_imp_full_plate', name: 'Improved Full Plate Armor', tier: 2, baseScore: 5, baseThresholds: '13 / 28', feature: 'Very Heavy: −2 to Evasion; −1 to Agility' },
  { id: 'ar_t2_elundrian_chain', name: 'Elundrian Chain Armor', tier: 2, baseScore: 4, baseThresholds: '9 / 21', feature: 'Warded: You reduce incoming magic damage by your Armor Score before applying it to your damage thresholds.' },
  { id: 'ar_t2_harrowbone', name: 'Harrowbone Armor', tier: 2, baseScore: 4, baseThresholds: '9 / 21', feature: 'Resilient: Before you mark your last Armor Slot, roll a d6. On a result of 6, reduce the severity by one threshold without marking an Armor Slot.' },
  { id: 'ar_t2_irontree_breastplate', name: 'Irontree Breastplate Armor', tier: 2, baseScore: 4, baseThresholds: '9 / 20', feature: 'Reinforced: When you mark your last Armor Slot, increase your damage thresholds by +2 until you clear at least 1 Armor Slot.' },
  { id: 'ar_t2_runetan_floating', name: 'Runetan Floating Armor', tier: 2, baseScore: 4, baseThresholds: '9 / 20', feature: 'Shifting: When you are targeted for an attack, you can mark an Armor Slot to give the attack roll against you disadvantage.' },
  { id: 'ar_t2_tyris_soft', name: 'Tyris Soft Armor', tier: 2, baseScore: 5, baseThresholds: '8 / 18', feature: 'Quiet: You gain a +2 bonus to rolls you make to move silently.' },
  { id: 'ar_t2_rosewild', name: 'Rosewild Armor', tier: 2, baseScore: 5, baseThresholds: '11 / 23', feature: 'Hopeful: When you would spend a Hope, you can mark an Armor Slot instead.' },
];
