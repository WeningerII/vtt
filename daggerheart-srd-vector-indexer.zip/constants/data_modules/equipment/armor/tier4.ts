import { Armor } from '../../../types';

// SRD Page 56
export const ARMOR_TIER_4: Armor[] = [
  { id: 'ar_t4_leg_gambeson', name: 'Legendary Gambeson Armor', tier: 4, baseScore: 6, baseThresholds: '11 / 32', feature: 'Flexible: +1 to Evasion' },
  { id: 'ar_t4_leg_leather', name: 'Legendary Leather Armor', tier: 4, baseScore: 6, baseThresholds: '13 / 36', feature: '—' },
  { id: 'ar_t4_leg_chainmail', name: 'Legendary Chainmail Armor', tier: 4, baseScore: 7, baseThresholds: '15 / 40', feature: 'Heavy: −1 to Evasion' },
  { id: 'ar_t4_leg_full_plate', name: 'Legendary Full Plate Armor', tier: 4, baseScore: 7, baseThresholds: '17 / 44', feature: 'Very Heavy: −2 to Evasion; −1 to Agility' },
  { id: 'ar_t4_dunamis_silkchain', name: 'Dunamis Silkchain', tier: 4, baseScore: 7, baseThresholds: '13 / 36', feature: 'Timeslowing: Mark an Armor Slot to roll a d4 and add its result as a bonus to your Evasion against an incoming attack.' },
  { id: 'ar_t4_channeling', name: 'Channeling Armor', tier: 4, baseScore: 5, baseThresholds: '13 / 36', feature: 'Channeling: +1 to Spellcast Rolls' },
  { id: 'ar_t4_emberwoven', name: 'Emberwoven Armor', tier: 4, baseScore: 6, baseThresholds: '13 / 36', feature: 'Burning: When an adversary attacks you within Melee range, they mark a Stress.' },
  { id: 'ar_t4_full_fortified', name: 'Full Fortified Armor', tier: 4, baseScore: 4, baseThresholds: '15 / 40', feature: 'Fortified: When you mark an Armor Slot, you reduce the severity of an attack by two thresholds instead of one.' },
  { id: 'ar_t4_veritas_opal', name: 'Veritas Opal Armor', tier: 4, baseScore: 6, baseThresholds: '13 / 36', feature: 'Truthseeking: This armor glows when another creature within Close range tells a lie.' },
  { id: 'ar_t4_savior_chainmail', name: 'Savior Chainmail', tier: 4, baseScore: 8, baseThresholds: '18 / 48', feature: 'Difficult: −1 to all character traits and Evasion' },
];
