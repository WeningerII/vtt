import { Armor } from '../../../types';
import { ARMOR_TIER_1 } from './tier1';
import { ARMOR_TIER_2 } from './tier2';
import { ARMOR_TIER_3 } from './tier3';
import { ARMOR_TIER_4 } from './tier4';

export const ALL_ARMOR: Armor[] = [
    ...ARMOR_TIER_1,
    ...ARMOR_TIER_2,
    ...ARMOR_TIER_3,
    ...ARMOR_TIER_4,
];

export {
    ARMOR_TIER_1,
    ARMOR_TIER_2,
    ARMOR_TIER_3,
    ARMOR_TIER_4,
};
