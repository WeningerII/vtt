
import { Weapon, Armor } from '../../types'; 

// Import Primary Weapons
import { 
    ALL_PRIMARY_WEAPONS as _ALL_PRIMARY_WEAPONS,
    WEAPONS_TIER_1_PHYSICAL_PRIMARY as _WEAPONS_TIER_1_PHYSICAL_PRIMARY, 
    WEAPONS_TIER_1_MAGIC_PRIMARY as _WEAPONS_TIER_1_MAGIC_PRIMARY,
    // Import other primary tiers if they need to be individually exported from here
    WEAPONS_TIER_2_PHYSICAL_PRIMARY as _WEAPONS_TIER_2_PHYSICAL_PRIMARY,
    WEAPONS_TIER_2_MAGIC_PRIMARY as _WEAPONS_TIER_2_MAGIC_PRIMARY,
    WEAPONS_TIER_3_PHYSICAL_PRIMARY as _WEAPONS_TIER_3_PHYSICAL_PRIMARY,
    WEAPONS_TIER_3_MAGIC_PRIMARY as _WEAPONS_TIER_3_MAGIC_PRIMARY,
    WEAPONS_TIER_4_PHYSICAL_PRIMARY as _WEAPONS_TIER_4_PHYSICAL_PRIMARY,
    WEAPONS_TIER_4_MAGIC_PRIMARY as _WEAPONS_TIER_4_MAGIC_PRIMARY
} from './primary_weapons/index';

// Import Secondary Weapons
import { 
    ALL_SECONDARY_WEAPONS as _ALL_SECONDARY_WEAPONS,
    WEAPONS_TIER_1_PHYSICAL_SECONDARY as _WEAPONS_TIER_1_PHYSICAL_SECONDARY,
    // Import other secondary tiers if they need to be individually exported
    WEAPONS_TIER_2_PHYSICAL_SECONDARY as _WEAPONS_TIER_2_PHYSICAL_SECONDARY,
    WEAPONS_TIER_3_PHYSICAL_SECONDARY as _WEAPONS_TIER_3_PHYSICAL_SECONDARY,
    WEAPONS_TIER_4_PHYSICAL_SECONDARY as _WEAPONS_TIER_4_PHYSICAL_SECONDARY
} from './secondary_weapons/index';

// Import Combat Wheelchairs (which are also Primary Weapons)
import { 
    ALL_COMBAT_WHEELCHAIRS as _ALL_COMBAT_WHEELCHAIRS 
} from './combat_wheelchairs/index';

// Import Armor
import { ALL_ARMOR as _ALL_ARMOR, ARMOR_TIER_1 as _ARMOR_TIER_1 } from './armor/index';


// --- Export Aggregates ---
export const ALL_PRIMARY_WEAPONS = _ALL_PRIMARY_WEAPONS;
export const ALL_SECONDARY_WEAPONS = _ALL_SECONDARY_WEAPONS;
export const ALL_COMBAT_WHEELCHAIRS = _ALL_COMBAT_WHEELCHAIRS;

// ALL_WEAPONS should include all primary (which already includes combat wheelchairs as they are 'Primary') and all secondary
export const ALL_WEAPONS: Weapon[] = [
    ..._ALL_PRIMARY_WEAPONS, // This now includes regular primary and combat wheelchairs
    ..._ALL_SECONDARY_WEAPONS,
];

export const ALL_ARMOR = _ALL_ARMOR;


// --- Export Specific Tiers/Types if needed elsewhere ---
export const WEAPONS_TIER_1_PHYSICAL_PRIMARY = _WEAPONS_TIER_1_PHYSICAL_PRIMARY;
export const WEAPONS_TIER_1_MAGIC_PRIMARY = _WEAPONS_TIER_1_MAGIC_PRIMARY;
export const WEAPONS_TIER_2_PHYSICAL_PRIMARY = _WEAPONS_TIER_2_PHYSICAL_PRIMARY;
export const WEAPONS_TIER_2_MAGIC_PRIMARY = _WEAPONS_TIER_2_MAGIC_PRIMARY;
export const WEAPONS_TIER_3_PHYSICAL_PRIMARY = _WEAPONS_TIER_3_PHYSICAL_PRIMARY;
export const WEAPONS_TIER_3_MAGIC_PRIMARY = _WEAPONS_TIER_3_MAGIC_PRIMARY;
export const WEAPONS_TIER_4_PHYSICAL_PRIMARY = _WEAPONS_TIER_4_PHYSICAL_PRIMARY;
export const WEAPONS_TIER_4_MAGIC_PRIMARY = _WEAPONS_TIER_4_MAGIC_PRIMARY;

export const WEAPONS_TIER_1_PHYSICAL_SECONDARY = _WEAPONS_TIER_1_PHYSICAL_SECONDARY;
export const WEAPONS_TIER_2_PHYSICAL_SECONDARY = _WEAPONS_TIER_2_PHYSICAL_SECONDARY;
export const WEAPONS_TIER_3_PHYSICAL_SECONDARY = _WEAPONS_TIER_3_PHYSICAL_SECONDARY;
export const WEAPONS_TIER_4_PHYSICAL_SECONDARY = _WEAPONS_TIER_4_PHYSICAL_SECONDARY;


export const ARMOR_TIER_1 = _ARMOR_TIER_1;
// Export other armor tiers if needed
export { ARMOR_TIER_2, ARMOR_TIER_3, ARMOR_TIER_4 } from './armor/index';

// Export Combat Wheelchair individual tiers/types if needed from their own index
export * from './combat_wheelchairs/index';
