
import { CharacterData, Trait } from '../../types';
import { TRAIT_NAMES } from './core_constants';
import { STARTING_INVENTORY_ITEMS, STARTING_POTION_CHOICES } from './items/index'; // Updated import

export const DEFAULT_CHARACTER_DATA: CharacterData = {
  name: '',
  pronouns: '',
  description: '',
  level: 1,
  class: null,
  subclass: null,
  ancestry: null,
  community: null,
  traits: TRAIT_NAMES.map(name => ({ name, value: 0 } as Trait)),
  hp: { current: 5, max: 5 },
  evasion: 10,
  armorScore: 0,
  damageThresholds: { major: 5, severe: 10 },
  stress: { current: 0, max: 6 },
  hope: { current: 2, max: 2 },
  proficiency: 1,
  experiences: [{ text: '', modifier: 2 }, { text: '', modifier: 2 }],
  inventory: [
    ...STARTING_INVENTORY_ITEMS,
    ...(STARTING_POTION_CHOICES.length > 0 ? [STARTING_POTION_CHOICES[0].name] : []), // Updated usage
    "1 Handful of Gold"
  ],
  gold: { handfuls: 1 },
  activePrimaryWeapon: null,
  activeSecondaryWeapon: null,
  activeArmor: null,
  domainCards: [],
  connections: '',
  background: '',
  features: [], 
};
