
import { GameTermData } from '../../types';

export const GAME_TERMS_DATA: GameTermData[] = [
  {
    id: 'hope',
    name: 'Hope',
    description: "A metacurrency players use to Help an Ally, Utilize an Experience, Initiate a Tag Team Roll, or Activate a Hope Feature. PCs start with 2 Hope and can have a maximum of 6. Hope carries over between sessions.",
    srdPageReference: "SRD p.42"
  },
  {
    id: 'fear',
    name: 'Fear',
    description: "A metacurrency the GM uses to make or enhance GM moves or use Fear Features. The GM gains Fear when players roll with Fear. Max 12 Fear, carries over between sessions.",
    srdPageReference: "SRD p.42"
  },
  {
    id: 'stress',
    name: 'Stress',
    description: "Represents mental, physical, and emotional strain. Marked for some abilities or as a consequence. Maxing Stress makes a PC Vulnerable. If Stress can't be marked, mark HP instead.",
    srdPageReference: "SRD p.43"
  },
  {
    id: 'action_roll',
    name: 'Action Roll',
    description: "Rolled when a move is difficult or risky. Uses Duality Dice (Hope d12 & Fear d12). Total + modifiers vs. Difficulty determines success, failure, and Hope/Fear generation.",
    srdPageReference: "SRD p.40"
  },
  {
    id: 'duality_dice',
    name: 'Duality Dice',
    description: "A pair of visually distinct twelve-sided dice, one representing Hope and the other Fear, used for all action rolls.",
    srdPageReference: "SRD p.40"
  },
  {
    id: 'advantage',
    name: 'Advantage',
    description: "Represents an opportunity. Roll a d6 advantage die and add its result to the total of an action or reaction roll.",
    srdPageReference: "SRD p.42"
  },
  {
    id: 'disadvantage',
    name: 'Disadvantage',
    description: "Represents an additional difficulty. Roll a d6 disadvantage die and subtract its result from the total of an action or reaction roll.",
    srdPageReference: "SRD p.42"
  },
  {
    id: 'proficiency',
    name: 'Proficiency',
    description: "Determines the number of damage dice rolled for weapon attacks. Starts at 1 and increases at certain levels. Does not affect flat damage modifiers.",
    srdPageReference: "SRD p.5 (Character Creation), p.43 (Damage Rolls)"
  },
  {
    id: 'evasion',
    name: 'Evasion',
    description: "Represents a character’s ability to avoid attacks. Rolls made against a PC typically use their Evasion as the Difficulty. Base Evasion is set by class, modified by armor, features, etc.",
    srdPageReference: "SRD p.43"
  },
  {
    id: 'hit_points',
    name: 'Hit Points',
    description: "Often abbreviated as HP. Represents physical health. Damage taken marks HP based on thresholds. Maxing HP leads to a death move.",
    srdPageReference: "SRD p.43"
  },
  {
    id: 'hp',
    name: 'HP',
    description: "Abbreviation for Hit Points. Represents physical health. Damage taken marks HP based on thresholds. Maxing HP leads to a death move.",
    srdPageReference: "SRD p.43"
  },
  {
    id: 'armor_score',
    name: 'Armor Score',
    description: "Determined by equipped armor plus bonuses. Contributes to damage reduction via Armor Slots.",
    srdPageReference: "SRD p.5 (Character Creation), Armor descriptions"
  },
  {
    id: 'damage_thresholds',
    name: 'Damage Thresholds',
    description: "Major and Severe thresholds determine how many HP are marked (1, 2, or 3) when damage is taken. Calculated from armor and character level.",
    srdPageReference: "SRD p.43"
  },
  {
    id: 'melee_range',
    name: 'Melee',
    description: "Close enough to touch, up to a few feet away.",
    srdPageReference: "SRD p.44"
  },
  {
    id: 'very_close_range',
    name: 'Very Close',
    description: "Close enough to see fine details, about 5–10 feet away. Can move to Melee as part of an action.",
    srdPageReference: "SRD p.44"
  },
  {
    id: 'close_range',
    name: 'Close',
    description: "Close enough to see prominent details, about 10–30 feet away. Can move to Melee as part of an action.",
    srdPageReference: "SRD p.44"
  },
  {
    id: 'far_range',
    name: 'Far',
    description: "Close enough to see very little detail, about 30–100 feet away. Requires Agility Roll to move to Melee.",
    srdPageReference: "SRD p.44"
  },
  {
    id: 'very_far_range',
    name: 'Very Far',
    description: "Too far to make out details, about 100–300 feet away. Requires Agility Roll to move to Melee.",
    srdPageReference: "SRD p.44"
  },
  {
    id: 'spellcast_roll',
    name: 'Spellcast Roll',
    description: "A trait roll using the character's Spellcast trait (defined by subclass) to cast spells or use magical abilities.",
    srdPageReference: "SRD p.41"
  },
  {
    id: 'reaction_roll',
    name: 'Reaction Roll',
    description: "Made in response to an attack or hazard to avoid/withstand effects. Does not generate Hope/Fear. Critical success ignores effects.",
    srdPageReference: "SRD p.41"
  },
  {
    id: 'trait_roll',
    name: 'Trait Roll',
    description: "An action roll specifying which character trait applies (e.g., Agility Roll (12)).",
    srdPageReference: "SRD p.41"
  },
  {
    id: 'gm_move',
    name: 'GM Move',
    description: "An action taken by the Game Master, often triggered by player rolls with Fear, failures, or narrative opportunities. Can spotlight adversaries or introduce complications.",
    srdPageReference: "SRD p.41"
  },
  {
    id: 'downtime',
    name: 'Downtime',
    description: "A period of rest where PCs can make downtime moves to recover resources (HP, Stress, Armor Slots) or Prepare. Can be a Short or Long Rest.",
    srdPageReference: "SRD p.45"
  },
  {
    id: 'death_move',
    name: 'Death Move',
    description: "Chosen by a player when their PC marks their last Hit Point. Options include Blaze of Glory, Avoid Death (with consequences), or Risk It All.",
    srdPageReference: "SRD p.46"
  },
  {
    id: 'difficulty',
    name: 'Difficulty',
    description: "The target number an action roll must meet or beat. For PCs, this is often their Evasion. For adversaries, it's their Difficulty score. Set by GM or ability text.",
    srdPageReference: "SRD p.40 (Action Rolls), p.43 (Evasion)"
  }
];
