
export const TRAIT_NAMES: string[] = ["Agility", "Strength", "Finesse", "Instinct", "Presence", "Knowledge"];
export type TraitName = typeof TRAIT_NAMES[number];

export const INITIAL_TRAIT_MODIFIERS: readonly number[] = Object.freeze([+2, +1, +1, +0, +0, -1]);
