
import { LootItemData } from '../../../types';

export const LOOT_ITEMS: LootItemData[] = [
  { id: 'loot_premium_bedroll', name: 'Premium Bedroll', description: 'During downtime, you automatically clear a Stress.', srdPage: 57, srdRoll: 1 },
  { id: 'loot_piper_whistle', name: 'Piper Whistle', description: 'This handcrafted whistle has a distinctive sound. When you blow this whistle, its piercing tone can be heard within a 1-mile radius.', srdPage: 57, srdRoll: 2 },
  { id: 'loot_charging_quiver', name: 'Charging Quiver', description: "When you succeed on an attack with an arrow stored in this quiver, gain a bonus to the damage roll equal to your current tier.", srdPage: 57, srdRoll: 3 },
  { id: 'loot_alistairs_torch', name: "Alistair's Torch", description: "You can light this magic torch at will. The flame’s light fills a much larger space than it should, enough to illuminate a cave bright as day.", srdPage: 57, srdRoll: 4 },
  { id: 'loot_speaking_orbs', name: 'Speaking Orbs', description: 'This pair of orbs allows any creatures holding them to communicate with each other across any distance.', srdPage: 57, srdRoll: 5 },
  // ... Add more items from SRD p. 57-58 (up to roll 60)
  { id: 'loot_belt_of_unity', name: 'Belt of Unity', description: 'Once per session, you can spend 5 Hope to lead a Tag Team Roll with three PCs instead of two.', srdPage: 59, srdRoll: 60 },
];