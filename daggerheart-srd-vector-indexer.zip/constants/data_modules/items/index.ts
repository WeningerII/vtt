
export { STARTING_INVENTORY_ITEMS } from './starting_inventory';
export { STARTING_POTION_CHOICES } from './potions'; // Updated name
export { LOOT_ITEMS } from './loot';
export { CONSUMABLE_ITEMS } from './consumables';