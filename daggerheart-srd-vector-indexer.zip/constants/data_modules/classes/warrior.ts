
export { WARRIOR_CLASS } from './warrior/index';
