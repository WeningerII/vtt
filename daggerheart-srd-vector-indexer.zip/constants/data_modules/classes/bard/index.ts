
import { ClassData } from '../../../../types';
import { TROUBADOUR_SUBCLASS } from './troubadour';
import { WORDSMITH_SUBCLASS } from './wordsmith';

export const BARD_CLASS: ClassData = {
  id: 'bard',
  name: 'Bard',
  startingHP: 5,
  startingEvasion: 10,
  classItems: "A romance novel or a letter never opened",
  domains: ["Grace", "Codex"],
  classFeature: { name: "Rally", description: "Once per session, describe how you rally the party and give yourself and each of your allies a Rally Die (d6 at Lvl 1). Spend Rally Die to add to roll or clear Stress. Increases to d8 at Lvl 5." },
  hopeFeature: { name: "Make a Scene", description: "Spend 3 Hope to temporarily Distract a target within Close range, giving them a -2 penalty to their Difficulty." },
  subclasses: [
    TROUBADOUR_SUBCLASS,
    WORDSMITH_SUBCLASS
  ]
};
