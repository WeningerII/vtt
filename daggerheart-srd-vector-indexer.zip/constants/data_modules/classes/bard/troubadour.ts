
import { Subclass } from '../../../../types';

export const TROUBADOUR_SUBCLASS: Subclass = {
  name: 'Troubadour',
  spellcastTrait: 'Presence',
  features: [
    { name: "Gifted Performer", description: "You can play three different types of songs, once each per long rest; describe how you perform for others to gain the listed benefit:\n• Relaxing Song: You and all allies within Close range clear a Hit Point.\n• Epic Song: Make a target within Close range temporarily Vulnerable.\n• Heartbreaking Song: You and all allies within Close range gain a Hope.", featureType: 'Foundation' },
    { name: "Maestro", description: "Your rallying songs steel the courage of those who listen. When you give a Rally Die to an ally, they can gain a Hope or clear a Stress.", featureType: 'Specialization' },
    { name: "Virtuoso", description: "You are among the greatest of your craft and your skill is boundless. You can perform each of your “Gifted Performer” feature’s songs twice per long rest.", featureType: 'Mastery' }
  ]
};
