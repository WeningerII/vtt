
import { ClassData } from '../../../../types';
import { DIVINE_WIELDER_SUBCLASS } from './divine_wielder';
import { WINGED_SENTINEL_SUBCLASS } from './winged_sentinel';

export const SERAPH_CLASS: ClassData = {
  id: 'seraph',
  name: 'Seraph',
  startingHP: 7,
  startingEvasion: 9,
  classItems: "A bundle of offerings or a sigil of your god",
  domains: ["Splendor", "Valor"],
  classFeature: { name: "Prayer Dice", description: "At the beginning of each session, roll a number of d4s equal to your subclass’s Spellcast trait and place them on your character sheet in the space provided. These are your Prayer Dice. You can spend any number of Prayer Dice to aid yourself or an ally within Far range. You can use a spent die’s value to reduce incoming damage, add to a roll’s result after the roll is made, or gain Hope equal to the result. At the end of each session, clear all unspent Prayer Dice." },
  hopeFeature: { name: "Life Support", description: "Spend 3 Hope to clear a Hit Point on an ally within Close range." },
  subclasses: [
    DIVINE_WIELDER_SUBCLASS,
    WINGED_SENTINEL_SUBCLASS
  ]
};
