
import { Subclass } from '../../../../types';

export const DIVINE_WIELDER_SUBCLASS: Subclass = {
  name: 'Divine Wielder',
  spellcastTrait: 'Strength',
  features: [
    { name: "Spirit Weapon", description: "When you have an equipped weapon with a range of Melee or Very Close, it can fly from your hand to attack an adversary within Close range and then return to you. You can mark a Stress to target an additional adversary within range with the same attack roll.", featureType: 'Foundation' },
    { name: "Sparing Touch", description: "Once per long rest, touch a creature and clear 2 Hit Points or 2 Stress from them.", featureType: 'Foundation' },
    { name: "Devout", description: "When you roll your Prayer Dice, you can roll an additional die and discard the lowest result. Additionally, you can use your “Sparing Touch” feature twice instead of once per long rest.", featureType: 'Specialization' },
    { name: "Sacred Resonance", description: "When you roll damage for your “Spirit Weapon” feature, if any of the die results match, double the value of each matching die. For example, if you roll two 5s, they count as two 10s.", featureType: 'Mastery' }
  ]
};
