
import { Subclass } from '../../../../types';

export const WINGED_SENTINEL_SUBCLASS: Subclass = {
  name: 'Winged Sentinel',
  spellcastTrait: 'Strength',
  features: [
    { name: "Wings of Light", description: "You can fly. While flying, you can do the following:\n• Mark a Stress to pick up and carry another willing creature approximately your size or smaller.\n• Spend a Hope to deal an extra 1d8 damage on a successful attack.", featureType: 'Foundation' },
    { name: "Ethereal Visage", description: "Your supernatural visage strikes awe and fear. While flying, you have advantage on Presence Rolls. When you succeed with Hope on a Presence Roll, you can remove a Fear from the GM’s Fear pool instead of gaining Hope.", featureType: 'Specialization' },
    { name: "Ascendant", description: "Gain a permanent +4 bonus to your Severe damage threshold.", featureType: 'Mastery' },
    { name: "Power of the Gods", description: "While flying, you deal an extra 1d12 damage instead of 1d8 from your “Wings of Light” feature.", featureType: 'Mastery' }
  ]
};
