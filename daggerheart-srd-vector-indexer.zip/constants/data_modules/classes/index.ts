
import { ClassData } from '../../types';
import { BARD_CLASS } from './bard'; // This will now point to ./bard/index.ts
import { DRUID_CLASS } from './druid';
import { GUARDIAN_CLASS } from './guardian';
import { RANGER_CLASS } from './ranger';
import { ROGUE_CLASS } from './rogue';
import { SERAPH_CLASS } from './seraph';
import { SORCERER_CLASS } from './sorcerer';
import { WARRIOR_CLASS } from './warrior';
import { WIZARD_CLASS } from './wizard';

export {
  BARD_CLASS,
  DRUID_CLASS,
  GUARDIAN_CLASS,
  RANGER_CLASS,
  ROGUE_CLASS,
  SERAPH_CLASS,
  SORCERER_CLASS,
  WARRIOR_CLASS,
  WIZARD_CLASS
};

export const ALL_CLASSES: ClassData[] = [
    BARD_CLASS,
    DRUID_CLASS,
    GUARDIAN_CLASS,
    RANGER_CLASS,
    ROGUE_CLASS,
    SERAPH_CLASS,
    SORCERER_CLASS,
    WARRIOR_CLASS,
    WIZARD_CLASS
];
