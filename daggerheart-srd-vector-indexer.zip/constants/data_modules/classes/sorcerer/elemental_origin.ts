
import { Subclass } from '../../../../types';

export const ELEMENTAL_ORIGIN_SUBCLASS: Subclass = {
  name: 'Elemental Origin',
  spellcastTrait: 'Instinct',
  features: [
    { name: "Elementalist", description: "Choose one of the following elements at character creation: air, earth, fire, lightning, water. You can shape this element into harmless effects. Additionally, spend a Hope and describe how your control over this element helps an action roll you’re about to make, then either gain a +2 bonus to the roll or a +3 bonus to the roll’s damage.", featureType: 'Foundation' },
    { name: "Natural Evasion", description: "You can call forth your element to protect you from harm. When an attack roll against you succeeds, you can mark a Stress and describe how you use your element to defend you. When you do, roll a d6 and add its result to your Evasion against the attack.", featureType: 'Specialization' },
    { name: "Transcendence", description: "Once per long rest, you can transform into a physical manifestation of your element. When you do, describe your transformation and choose two of the following benefits to gain until your next rest: +4 bonus to your Severe threshold, +1 bonus to a character trait of your choice, +1 bonus to your Proficiency, +2 bonus to your Evasion.", featureType: 'Mastery' }
  ]
};
