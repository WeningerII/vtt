
import { ClassData } from '../../../../types';
import { ELEMENTAL_ORIGIN_SUBCLASS } from './elemental_origin';
import { PRIMAL_ORIGIN_SUBCLASS } from './primal_origin';

export const SORCERER_CLASS: ClassData = {
  id: 'sorcerer',
  name: 'Sorcerer',
  startingHP: 6,
  startingEvasion: 10,
  classItems: "A whispering orb or a family heirloom",
  domains: ["Arcana", "Midnight"],
  classFeature: { name: "Arcane Sense, Minor Illusion, Channel Raw Power", description: "Arcane Sense: You can sense the presence of magical people and objects within Close range.\nMinor Illusion: Make a Spellcast Roll (10). On a success, you create a minor visual illusion no larger than yourself within Close range. This illusion is convincing to anyone at Close range or farther.\nChannel Raw Power: Once per long rest, you can place a domain card from your loadout into your vault and choose to either: Gain Hope equal to the level of the card OR Enhance a spell that deals damage, gaining a bonus to your damage roll equal to twice the level of the card." },
  hopeFeature: { name: "Volatile Magic", description: "Spend 3 Hope to reroll any number of your damage dice on an attack that deals magic damage." },
  subclasses: [
    ELEMENTAL_ORIGIN_SUBCLASS,
    PRIMAL_ORIGIN_SUBCLASS
  ]
};
