
export { SERAPH_CLASS } from './seraph/index';
