
import { ClassData } from '../../../../types';
import { WARDEN_OF_THE_ELEMENTS_SUBCLASS } from './warden_of_the_elements';
import { WARDEN_OF_RENEWAL_SUBCLASS } from './warden_of_renewal';

export const DRUID_CLASS: ClassData = {
  id: 'druid',
  name: 'Druid',
  startingHP: 6,
  startingEvasion: 10,
  classItems: "A small bag of rocks and bones or a strange pendant found in the dirt",
  domains: ["Sage", "Arcana"],
  classFeature: { name: "Beastform", description: "Mark a Stress to magically transform into a creature of your tier or lower from the Beastform list. You can drop out of this form at any time. While transformed, you can’t use weapons or cast spells from domain cards, but you can still use other features or abilities you have access to. Spells you cast before you transform stay active and last for their normal duration, and you can talk and communicate as normal. Additionally, you gain the Beastform’s features, add their Evasion bonus to your Evasion, and use the trait specified in their statistics for your attack. While you’re in a Beastform, your armor becomes part of your body and you mark Armor Slots as usual; when you drop out of a Beastform, those marked Armor Slots remain marked. If you mark your last Hit Point, you automatically drop out of this form." },
  hopeFeature: { name: "Evolution", description: "Spend 3 Hope to transform into a Beastform without marking a Stress. When you do, choose one trait to raise by +1 until you drop out of that Beastform." },
  subclasses: [
    WARDEN_OF_THE_ELEMENTS_SUBCLASS,
    WARDEN_OF_RENEWAL_SUBCLASS
  ]
};
