
import { Subclass } from '../../../../types';

export const WARDEN_OF_RENEWAL_SUBCLASS: Subclass = {
  name: 'Warden of Renewal',
  spellcastTrait: 'Instinct',
  features: [
    { name: "Clarity of Nature", description: "Once per long rest, you can create a space of natural serenity within Close range. When you spend a few minutes resting within the space, clear Stress equal to your Instinct, distributed as you choose between you and your allies.", featureType: 'Foundation' },
    { name: "Regeneration", description: "Touch a creature and spend 3 Hope. That creature clears 1d4 Hit Points.", featureType: 'Foundation' },
    { name: "Regenerative Reach", description: "You can target creatures within Very Close range with your “Regeneration” feature.", featureType: 'Specialization' },
    { name: "Warden’s Protection", description: "Once per long rest, spend 2 Hope to clear 2 Hit Points on 1d4 allies within Close range.", featureType: 'Specialization' },
    { name: "Defender", description: "Your animal transformation embodies a healing guardian spirit. When you’re in Beastform and an ally within Close range marks 2 or more Hit Points, you can mark a Stress to reduce the number of Hit Points they mark by 1.", featureType: 'Mastery' }
  ]
};
