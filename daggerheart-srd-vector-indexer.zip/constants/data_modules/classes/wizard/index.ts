
import { ClassData } from '../../../../types';
import { SCHOOL_OF_KNOWLEDGE_SUBCLASS } from './school_of_knowledge';
import { SCHOOL_OF_WAR_SUBCLASS } from './school_of_war';

export const WIZARD_CLASS: ClassData = {
  id: 'wizard',
  name: 'Wizard',
  startingHP: 5,
  startingEvasion: 11,
  classItems: "A book you’re trying to translate or a tiny, harmless elemental pet",
  domains: ["Codex", "Splendor"],
  classFeature: { name: "Prestidigitation & Strange Patterns", description: "Prestidigitation: You can perform harmless, subtle magical effects at will. For example, you can change an object’s color, create a smell, light a candle, cause a tiny object to float, illuminate a room, or repair a small object.\nStrange Patterns: Choose a number between 1 and 12. When you roll that number on a Duality Die, gain a Hope or clear a Stress. You can change this number when you take a long rest." },
  hopeFeature: { name: "Not This Time", description: "Spend 3 Hope to force an adversary within Far range to reroll an attack or damage roll." },
  subclasses: [
    SCHOOL_OF_KNOWLEDGE_SUBCLASS,
    SCHOOL_OF_WAR_SUBCLASS
  ]
};
