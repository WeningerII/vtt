
import { Subclass } from '../../../../types';

export const SCHOOL_OF_KNOWLEDGE_SUBCLASS: Subclass = {
  name: 'School of Knowledge',
  spellcastTrait: 'Knowledge',
  features: [
    { name: "Prepared", description: "Take an additional domain card of your level or lower from a domain you have access to.", featureType: 'Foundation' },
    { name: "Adept", description: "When you Utilize an Experience, you can mark a Stress instead of spending a Hope. If you do, double your Experience modifier for that roll.", featureType: 'Foundation' },
    { name: "Accomplished", description: "Take an additional domain card of your level or lower from a domain you have access to.", featureType: 'Specialization' },
    { name: "Perfect Recall", description: "Once per rest, when you recall a domain card in your vault, you can reduce its Recall Cost by 1.", featureType: 'Specialization' },
    { name: "Brilliant", description: "Take an additional domain card of your level or lower from a domain you have access to.", featureType: 'Mastery' },
    { name: "Honed Expertise", description: "When you use an Experience, roll a d6. On a result of 5 or higher, you can use it without spending Hope.", featureType: 'Mastery' }
  ]
};
