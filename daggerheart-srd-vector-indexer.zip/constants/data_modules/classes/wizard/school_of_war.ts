
import { Subclass } from '../../../../types';

export const SCHOOL_OF_WAR_SUBCLASS: Subclass = {
  name: 'School of War',
  spellcastTrait: 'Knowledge',
  features: [
    { name: "Battlemage", description: "You’ve focused your studies on becoming an unconquerable force on the battlefield. Gain an additional Hit Point slot.", featureType: 'Foundation' },
    { name: "Face Your Fear", description: "When you succeed with Fear on an attack roll, you deal an extra 1d10 magic damage.", featureType: 'Foundation' },
    { name: "Conjure Shield", description: "You can maintain a protective barrier of magic. While you have at least 2 Hope, you add your Proficiency to your Evasion.", featureType: 'Specialization' },
    { name: "Fueled by Fear", description: "The extra magic damage from your “Face Your Fear” feature increases to 2d10.", featureType: 'Specialization' },
    { name: "Thrive in Chaos", description: "When you succeed on an attack, you can mark a Stress after rolling damage to force the target to mark an additional Hit Point.", featureType: 'Mastery' },
    { name: "Have No Fear", description: "The extra magic damage from your “Face Your Fear” feature increases to 3d10.", featureType: 'Mastery' }
  ]
};
