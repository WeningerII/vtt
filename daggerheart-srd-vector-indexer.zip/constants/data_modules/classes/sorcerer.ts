
export { SORCERER_CLASS } from './sorcerer/index';
