
import { ClassData } from '../../../../types';
import { NIGHTWALKER_SUBCLASS } from './nightwalker';
import { SYNDICATE_SUBCLASS } from './syndicate';

export const ROGUE_CLASS: ClassData = {
  id: 'rogue',
  name: 'Rogue',
  startingHP: 6,
  startingEvasion: 12,
  classItems: "A set of forgery tools or a grappling hook",
  domains: ["Midnight", "Grace"],
  classFeature: { name: "Cloaked & Sneak Attack", description: "Cloaked: Any time you would be Hidden, you are instead Cloaked. In addition to the benefits of the Hidden condition, while Cloaked you remain unseen if you are stationary when an adversary moves to where they would normally see you. After you make an attack or end a move within line of sight of an adversary, you are no longer Cloaked.\nSneak Attack: When you succeed on an attack while Cloaked or while an ally is within Melee range of your target, add a number of d6s equal to your tier to your damage roll (Tier 1: 1d6, Tier 2: 2d6, Tier 3: 3d6, Tier 4: 4d6)." },
  hopeFeature: { name: "Rogue’s Dodge", description: "Spend 3 Hope to gain a +2 bonus to your Evasion until the next time an attack succeeds against you. Otherwise, this bonus lasts until your next rest." },
  subclasses: [
    NIGHTWALKER_SUBCLASS,
    SYNDICATE_SUBCLASS
  ]
};
