
import { Subclass } from '../../../../types';

export const NIGHTWALKER_SUBCLASS: Subclass = {
  name: 'Nightwalker',
  spellcastTrait: 'Finesse',
  features: [
    { name: "Shadow Stepper", description: "You can move from shadow to shadow. When you move into an area of darkness or a shadow cast by another creature or object, you can mark a Stress to disappear from where you are and reappear inside another shadow within Far range. When you reappear, you are Cloaked.", featureType: 'Foundation' },
    { name: "Dark Cloud", description: "Make a Spellcast Roll (15). On a success, create a temporary dark cloud that covers any area within Close range. Anyone in this cloud can’t see outside of it, and anyone outside of it can’t see in. You’re considered Cloaked from any adversary for whom the cloud blocks line of sight.", featureType: 'Specialization' },
    { name: "Adrenaline", description: "While you're Vulnerable, add your level to your damage rolls.", featureType: 'Specialization' },
    { name: "Fleeting Shadow", description: "Gain a permanent +1 bonus to your Evasion. You can use your “Shadow Stepper” feature to move within Very Far range.", featureType: 'Mastery' },
    { name: "Vanishing Act", description: "Mark a Stress to become Cloaked at any time. When Cloaked from this feature, you automatically clear the Restrained condition if you have it. You remain Cloaked in this way until you roll with Fear or until your next rest.", featureType: 'Mastery' }
  ]
};
