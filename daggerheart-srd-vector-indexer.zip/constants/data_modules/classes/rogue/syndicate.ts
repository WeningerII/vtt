
import { Subclass } from '../../../../types';

export const SYNDICATE_SUBCLASS: Subclass = {
  name: 'Syndicate',
  spellcastTrait: 'Finesse',
  features: [
    { name: "Well-Connected", description: "When you arrive in a prominent town or environment, you know somebody who calls this place home. Give them a name, note how you think they could be useful, and choose one fact from the following list:\n• They owe me a favor, but they’ll be hard to find.\n• They’re going to ask for something in exchange.\n• They’re always in a great deal of trouble.\n• We used to be together. It’s a long story.\n• We didn’t part on great terms.", featureType: 'Foundation' },
    { name: "Contacts Everywhere", description: "Once per session, you can briefly call on a shady contact. Choose one of the following benefits and describe what brought them here to help you in this moment:\n• They provide 1 handful of gold, a unique tool, or a mundane object that the situation requires.\n• On your next action roll, their help provides a +3 bonus to the result of your Hope or Fear Die.\n• The next time you deal damage, they snipe from the shadows, adding 2d8 to your damage roll.", featureType: 'Specialization' },
    { name: "Reliable Backup", description: "You can use your “Contacts Everywhere” feature three times per session. The following options are added to the list of benefits you can choose from when you use that feature:\n• When you mark 1 or more Hit Points, they can rush out to shield you, reducing the Hit Points marked by 1.\n• When you make a Presence Roll in conversation, they back you up. You can roll a d20 as your Hope Die.", featureType: 'Mastery' }
  ]
};
