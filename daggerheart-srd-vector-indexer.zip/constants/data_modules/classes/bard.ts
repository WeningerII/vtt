
import { ClassData } from '../../../types';
import { TROUBADOUR_SUBCLASS } from './bard/troubadour';
import { WORDSMITH_SUBCLASS } from './bard/wordsmith';

export const BARD_CLASS: ClassData = {
  id: 'bard',
  name: 'Bard',
  startingHP: 5,
  startingEvasion: 10,
  classItems: "A romance novel or a letter never opened",
  domains: ["Grace", "Codex"],
  classFeature: { name: "Rally", description: "Once per session, describe how you rally the party and give yourself and each of your allies a Rally Die. At level 1, your Rally Die is a d6. A PC can spend their Rally Die to roll it, adding the result to their action roll, reaction roll, damage roll, or to clear a number of Stress equal to the result. At the end of each session, clear all unspent Rally Dice. At level 5, your Rally Die increases to a d8." },
  hopeFeature: { name: "Make a Scene", description: "Spend 3 Hope to temporarily Distract a target within Close range, giving them a -2 penalty to their Difficulty." },
  subclasses: [
    TROUBADOUR_SUBCLASS,
    WORDSMITH_SUBCLASS
  ]
};
