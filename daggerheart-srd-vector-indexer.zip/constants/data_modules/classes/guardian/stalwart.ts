
import { Subclass } from '../../../../types';

export const STALWART_SUBCLASS: Subclass = {
  name: 'Stalwart',
  features: [
    { name: "Unwavering", description: "Gain a permanent +1 bonus to your damage thresholds.", featureType: 'Foundation' },
    { name: "Iron Will", description: "When you take physical damage, you can mark an additional Armor Slot to reduce the severity.", featureType: 'Foundation' },
    { name: "Unrelenting", description: "Gain a permanent +2 bonus to your damage thresholds.", featureType: 'Specialization' },
    { name: "Partners-in-Arms", description: "When an ally within Very Close range takes damage, you can mark an Armor Slot to reduce the severity by one threshold.", featureType: 'Specialization' },
    { name: "Undaunted", description: "Gain a permanent +3 bonus to your damage thresholds.", featureType: 'Mastery' },
    { name: "Loyal Protector", description: "When an ally within Close range has 2 or fewer Hit Points and would take damage, you can mark a Stress to sprint to their side and take the damage instead.", featureType: 'Mastery' }
  ]
};
