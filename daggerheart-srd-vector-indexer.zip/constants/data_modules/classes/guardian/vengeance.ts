
import { Subclass } from '../../../../types';

export const VENGEANCE_SUBCLASS: Subclass = {
  name: 'Vengeance',
  features: [
    { name: "At Ease", description: "Gain an additional Stress slot.", featureType: 'Foundation' },
    { name: "Revenge", description: "When an adversary within Melee range succeeds on an attack against you, you can mark 2 Stress to force the attacker to mark a Hit Point.", featureType: 'Foundation' },
    { name: "Act of Reprisal", description: "When an adversary damages an ally within Melee range, you gain a +1 bonus to your Proficiency for the next successful attack you make against that adversary.", featureType: 'Specialization' },
    { name: "Nemesis", description: "Spend 2 Hope to Prioritize an adversary until your next rest. When you make an attack against your Prioritized adversary, you can swap the results of your Hope and Fear Dice. You can only Prioritize one adversary at a time.", featureType: 'Mastery' }
  ]
};
