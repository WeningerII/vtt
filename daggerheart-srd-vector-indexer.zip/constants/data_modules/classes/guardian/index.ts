
import { ClassData } from '../../../../types';
import { STALWART_SUBCLASS } from './stalwart';
import { VENGEANCE_SUBCLASS } from './vengeance';

export const GUARDIAN_CLASS: ClassData = {
  id: 'guardian',
  name: 'Guardian',
  startingHP: 7,
  startingEvasion: 9,
  classItems: "A totem from your mentor or a secret key",
  domains: ["Valor", "Blade"],
  classFeature: { name: "Unstoppable", description: "Once per long rest, you can become Unstoppable. You gain an Unstoppable Die (d4 at Lvl 1, d6 at Lvl 5). Place it 1-up. After damaging a target, increment die. If value exceeds max or scene ends, remove die. Benefits: Reduce physical damage severity by one threshold, add die value to damage, can't be Restrained/Vulnerable." },
  hopeFeature: { name: "Frontline Tank", description: "Spend 3 Hope to clear 2 Armor Slots." },
  subclasses: [
    STALWART_SUBCLASS,
    VENGEANCE_SUBCLASS
  ]
};
