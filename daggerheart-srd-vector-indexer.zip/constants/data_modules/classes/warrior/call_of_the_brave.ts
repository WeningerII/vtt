
import { Subclass } from '../../../../types';

export const CALL_OF_THE_BRAVE_SUBCLASS: Subclass = {
  name: 'Call of the Brave',
  features: [
    { name: "Courage", description: "When you fail a roll with Fear, you gain a Hope.", featureType: 'Foundation' },
    { name: "Battle Ritual", description: "Once per long rest, before you attempt something incredibly dangerous or face off against a foe who clearly outmatches you, describe what ritual you perform or preparations you make. When you do, clear 2 Stress and gain 2 Hope.", featureType: 'Foundation' },
    { name: "Rise to the Challenge", description: "You are vigilant in the face of mounting danger. While you have 2 or fewer Hit Points unmarked, you can roll a d20 as your Hope Die.", featureType: 'Specialization' },
    { name: "Camaraderie", description: "Your unwavering bravery is a rallying point for your allies. You can initiate a Tag Team Roll one additional time per session. Additionally, when an ally initiates a Tag Team Roll with you, they only need to spend 2 Hope to do so.", featureType: 'Mastery' }
  ]
};
