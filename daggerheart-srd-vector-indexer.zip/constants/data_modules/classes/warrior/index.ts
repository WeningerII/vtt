
import { ClassData } from '../../../../types';
import { CALL_OF_THE_BRAVE_SUBCLASS } from './call_of_the_brave';
import { CALL_OF_THE_SLAYER_SUBCLASS } from './call_of_the_slayer';

export const WARRIOR_CLASS: ClassData = {
  id: 'warrior',
  name: 'Warrior',
  startingHP: 6, // SRD p.23
  startingEvasion: 11, // SRD p.23
  classItems: "The drawing of a lover or a sharpening stone",
  domains: ["Blade", "Bone"],
  classFeature: { name: "Attack of Opportunity & Combat Training", description: "Attack of Opportunity: If an adversary within Melee range attempts to leave that range, make a reaction roll using a trait of your choice against their Difficulty. Choose one effect on a success, or two if you critically succeed: They can’t move from where they are, You deal damage to them equal to your primary weapon’s damage, You move with them.\nCombat Training: You ignore burden when equipping weapons. When you deal physical damage, you gain a bonus to your damage roll equal to your level." },
  hopeFeature: { name: "No Mercy", description: "Spend 3 Hope to gain a +1 bonus to your attack rolls until your next rest." },
  subclasses: [
    CALL_OF_THE_BRAVE_SUBCLASS,
    CALL_OF_THE_SLAYER_SUBCLASS
  ]
};
