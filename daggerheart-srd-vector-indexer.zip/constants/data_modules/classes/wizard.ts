
export { WIZARD_CLASS } from './wizard/index';
