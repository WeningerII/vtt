
import { ClassData } from '../../../../types';
import { BEASTBOUND_SUBCLASS } from './beastbound';
import { WAYFINDER_SUBCLASS } from './wayfinder';

export const RANGER_CLASS: ClassData = {
  id: 'ranger',
  name: 'Ranger',
  startingHP: 6,
  startingEvasion: 12,
  classItems: "A trophy from your first kill or a seemingly broken compass",
  domains: ["Bone", "Sage"],
  classFeature: { name: "Ranger’s Focus", description: "Spend a Hope and make an attack against a target. On a success, deal your attack’s normal damage and temporarily make the attack’s target your Focus. Until this feature ends or you make a different creature your Focus, you gain the following benefits against your Focus:\n• You know precisely what direction they are in.\n• When you deal damage to them, they must mark a Stress.\n• When you fail an attack against them, you can end your Ranger’s Focus feature to reroll your Duality Dice." },
  hopeFeature: { name: "Hold Them Off", description: "Spend 3 Hope when you succeed on an attack with a weapon to use that same roll against two additional adversaries within range of the attack." },
  subclasses: [
    BEASTBOUND_SUBCLASS,
    WAYFINDER_SUBCLASS
  ]
};
