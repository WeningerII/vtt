
import { Subclass } from '../../../../types';

export const WAYFINDER_SUBCLASS: Subclass = {
  name: 'Wayfinder',
  spellcastTrait: 'Agility',
  features: [
    { name: "Ruthless Predator", description: "When you make a damage roll, you can mark a Stress to gain a +1 bonus to your Proficiency. Additionally, when you deal Severe damage to an adversary, they must mark a Stress.", featureType: 'Foundation' },
    { name: "Path Forward", description: "When you’re traveling to a place you’ve previously visited or you carry an object that has been at the location before, you can identify the shortest, most direct path to your destination.", featureType: 'Foundation' },
    { name: "Elusive Predator", description: "When your Focus makes an attack against you, you gain a +2 bonus to your Evasion against the attack.", featureType: 'Specialization' },
    { name: "Apex Predator", description: "Before you make an attack roll against your Focus, you can spend a Hope. On a successful attack, you remove a Fear from the GM’s Fear pool.", featureType: 'Mastery' }
  ]
};
