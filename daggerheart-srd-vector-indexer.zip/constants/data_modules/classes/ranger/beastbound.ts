
import { Subclass } from '../../../../types';

export const BEASTBOUND_SUBCLASS: Subclass = {
  name: 'Beastbound',
  spellcastTrait: 'Agility',
  features: [
    { name: "Companion", description: "You have an animal companion of your choice (at the GM’s discretion). They stay by your side unless you tell them otherwise. Take the Ranger Companion sheet. When you level up your character, choose a level-up option for your companion from this sheet as well.", featureType: 'Foundation' },
    { name: "Expert Training", description: "Choose an additional level-up option for your companion.", featureType: 'Specialization' },
    { name: "Battle-Bonded", description: "When an adversary attacks you while they’re within your companion’s Melee range, you gain a +2 bonus to your Evasion against the attack.", featureType: 'Specialization' },
    { name: "Advanced Training", description: "Choose two additional level-up options for your companion.", featureType: 'Mastery' },
    { name: "Loyal Friend", description: "Once per long rest, when the damage from an attack would mark your companion’s last Stress or your last Hit Point and you’re within Close range of each other, you or your companion can rush to the other’s side and take that damage instead.", featureType: 'Mastery' }
  ]
};
