
import { DomainCard } from '../../../types';

export const BONE_DOMAIN_CARDS: DomainCard[] = [
  {
    id: 'bone_deft_maneuvers',
    name: 'DEFT MANEUVERS',
    domain: 'Bone',
    level: 1,
    type: 'Ability',
    recallCost: 0,
    description: 'Once per rest, mark a Stress to sprint anywhere within Far range without making an Agility Roll to get there.\nIf you end this movement within Melee range of an adversary and immediately make an attack against them, gain a +1 bonus to the attack roll.'
  },
  {
    id: 'bone_i_see_it_coming',
    name: 'I SEE IT COMING',
    domain: 'Bone',
    level: 1,
    type: 'Ability',
    recallCost: 1,
    description: 'When you’re targeted by an attack made from beyond Melee range, you can mark a Stress to roll a d4 and gain a bonus to your Evasion equal to the result against the attack.'
  },
  {
    id: 'bone_untouchable',
    name: 'UNTOUCHABLE',
    domain: 'Bone',
    level: 1,
    type: 'Ability',
    recallCost: 1,
    description: 'Gain a bonus to your Evasion equal to half your Agility.'
  },
  {
    id: 'bone_ferocity',
    name: 'FEROCITY',
    domain: 'Bone',
    level: 2,
    type: 'Ability',
    recallCost: 2,
    description: 'When you cause an adversary to mark 1 or more Hit Points, you can spend 2 Hope to increase your Evasion by the number of Hit Points they marked. This bonus lasts until after the next attack made against you.'
  },
  {
    id: 'bone_strategic_approach',
    name: 'STRATEGIC APPROACH',
    domain: 'Bone',
    level: 2,
    type: 'Ability',
    recallCost: 1,
    description: 'After a long rest, place a number of tokens equal to your Knowledge on this card (minimum 1). The first time you move within Close range of an adversary and make an attack against them, you can spend one token to choose one of the following options:\n• You make the attack with advantage.\n• You clear a Stress on an ally within Melee range of the adversary.\n• You add a d8 to your damage roll.\nWhen you take a long rest, clear all unspent tokens.'
  },
  {
    id: 'bone_brace',
    name: 'BRACE',
    domain: 'Bone',
    level: 3,
    type: 'Ability',
    recallCost: 1,
    description: 'When you mark an Armor Slot to reduce incoming damage, you can mark a Stress to mark an additional Armor Slot.'
  },
  {
    id: 'bone_tactician',
    name: 'TACTICIAN',
    domain: 'Bone',
    level: 3,
    type: 'Ability',
    recallCost: 1,
    description: 'When you Help an Ally, they can spend a Hope to add one of your Experiences to their roll alongside your advantage die.\nWhen making a Tag Team Roll, you can roll a d20 as your Hope Die.'
  },
  {
    id: 'bone_boost',
    name: 'BOOST',
    domain: 'Bone',
    level: 4,
    type: 'Ability',
    recallCost: 1,
    description: 'Mark a Stress to boost off a willing ally within Close range, fling yourself into the air, and perform an aerial attack against a target within Far range. You have advantage on the attack, add a d10 to the damage roll, and end your move within Melee range of the target.'
  },
  {
    id: 'bone_redirect',
    name: 'REDIRECT',
    domain: 'Bone',
    level: 4,
    type: 'Ability',
    recallCost: 1,
    description: 'When an attack made against you from beyond Melee range fails, roll a number of d6s equal to your Proficiency. If any roll a 6, you can mark a Stress to redirect the attack to damage an adversary within Very Close range instead.'
  },
  {
    id: 'bone_know_thy_enemy',
    name: 'KNOW THY ENEMY',
    domain: 'Bone',
    level: 5,
    type: 'Ability',
    recallCost: 1,
    description: 'When observing a creature, you can make an Instinct Roll against them. On a success, spend a Hope and ask the GM for one set of information about the target from the following options:\n• Their unmarked Hit Points and Stress.\n• Their Difficulty and damage thresholds.\n• Their tactics and standard attack damage dice.\n• Their features and Experiences.\nAdditionally on a success, you can mark a Stress to remove a Fear from the GM’s Fear Pool.'
  },
  {
    id: 'bone_signature_move',
    name: 'SIGNATURE MOVE',
    domain: 'Bone',
    level: 5,
    type: 'Ability',
    recallCost: 1,
    description: 'Name and describe your signature combat move. Once per rest, when you perform this signature move as part of an action you’re taking, you can roll a d20 as your Hope Die. On a success, clear a Stress.'
  },
  {
    id: 'bone_rapid_riposte',
    name: 'RAPID RIPOSTE',
    domain: 'Bone',
    level: 6,
    type: 'Ability',
    recallCost: 0,
    description: 'When an attack made against you from within Melee range fails, you can mark a Stress and seize the opportunity to deal the weapon damage of one of your active weapons to the attacker.'
  },
  {
    id: 'bone_recovery',
    name: 'RECOVERY',
    domain: 'Bone',
    level: 6,
    type: 'Ability',
    recallCost: 1,
    description: 'During a short rest, you can choose a long rest downtime move instead. You can spend a Hope to let an ally do the same.'
  },
  {
    id: 'bone_bone_touched',
    name: 'BONE-TOUCHED',
    domain: 'Bone',
    level: 7,
    type: 'Ability',
    recallCost: 2,
    description: 'When 4 or more of the domain cards in your loadout are from the Bone domain, gain the following benefits:\n• +1 bonus to Agility\n• Once per rest, you can spend 3 Hope to cause an attack that succeeded against you to fail instead.'
  },
  {
    id: 'bone_cruel_precision',
    name: 'CRUEL PRECISION',
    domain: 'Bone',
    level: 7,
    type: 'Ability',
    recallCost: 1,
    description: 'When you make a successful attack with a weapon, gain a bonus to your damage roll equal to either your Finesse or Agility.'
  },
  {
    id: 'bone_breaking_blow',
    name: 'BREAKING BLOW',
    domain: 'Bone',
    level: 8,
    type: 'Ability',
    recallCost: 3,
    description: 'When you make a successful attack, you can mark a Stress to make the next successful attack against that same target deal an extra 2d12 damage.'
  },
  {
    id: 'bone_wrangle',
    name: 'WRANGLE',
    domain: 'Bone',
    level: 8,
    type: 'Ability',
    recallCost: 1,
    description: 'Make an Agility Roll against all targets within Close range. Spend a Hope to move targets you succeed against, and any willing allies within Close range, to another point within Close range.'
  },
  {
    id: 'bone_on_the_brink',
    name: 'ON THE BRINK',
    domain: 'Bone',
    level: 9,
    type: 'Ability',
    recallCost: 1,
    description: 'When you have 2 or fewer Hit Points unmarked, you don’t take Minor damage.'
  },
  {
    id: 'bone_splintering_strike',
    name: 'SPLINTERING STRIKE',
    domain: 'Bone',
    level: 9,
    type: 'Ability',
    recallCost: 3,
    description: 'Spend a Hope and make an attack against all adversaries within your weapon’s range. Once per long rest, on a success against any targets, add up the damage dealt, then redistribute that damage however you wish between the targets you succeeded against. When you deal damage to a target, roll an additional damage die and add its result to the damage you deal to that target.'
  },
  {
    id: 'bone_deathrun',
    name: 'DEATHRUN',
    domain: 'Bone',
    level: 10,
    type: 'Ability',
    recallCost: 1,
    description: 'Spend 3 Hope to run a straight path through the battlefield to a point within Far range, making an attack against all adversaries within your weapon’s range along that path. Choose the order in which you deal damage to the targets you succeeded against. For the first, roll your weapon damage with a +1 bonus to your Proficiency. Then remove a die from your damage roll and deal the remaining damage to the next target. Continue to remove a die for each subsequent target until you have no more damage dice or adversaries.\nYou can’t target the same adversary more than once per attack.'
  },
  {
    id: 'bone_swift_step',
    name: 'SWIFT STEP',
    domain: 'Bone',
    level: 10,
    type: 'Ability',
    recallCost: 2,
    description: 'When an attack made against you fails, clear a Stress. If you can’t clear a Stress, gain a Hope.'
  }
];
