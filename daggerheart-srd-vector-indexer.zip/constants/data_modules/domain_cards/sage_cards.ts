import { DomainCard } from '../../../types';

export const SAGE_DOMAIN_CARDS: DomainCard[] = [
  {
    id: 'sage_gifted_tracker',
    name: 'GIFTED TRACKER',
    domain: 'Sage',
    level: 1,
    type: 'Ability',
    recallCost: 0,
    description: "When you’re tracking a specific creature or group of creatures based on signs of their passage, you can spend any number of Hope and ask the GM that many questions from the following list:\n• What direction did they go?\n• How long ago did they pass through?\n• What were they doing in this location?\n• How many of them were here?\nWhen you encounter creatures you’ve tracked in this way, gain a +1 bonus to your Evasion against them."
  },
  {
    id: 'sage_natures_tongue',
    name: 'NATURE’S TONGUE',
    domain: 'Sage',
    level: 1,
    type: 'Ability',
    recallCost: 0,
    description: "You can speak the language of the natural world. When you want to speak to the plants and animals around you, make an Instinct Roll (12). On a success, they’ll give you the information they know. On a roll with Fear, their knowledge might be limited or come at a cost.\nAdditionally, before you make a Spellcast Roll while within a natural environment, you can spend a Hope to gain a +2 bonus to the roll."
  },
  {
    id: 'sage_vicious_entangle',
    name: 'VICIOUS ENTANGLE',
    domain: 'Sage',
    level: 1,
    type: 'Spell',
    recallCost: 1,
    description: 'Make a Spellcast Roll against a target within Far range. On a success, roots and vines reach out from the ground, dealing 1d8+1 physical damage and temporarily Restraining the target.\nAdditionally on a success, you can spend a Hope to temporarily Restrain another adversary within Very Close range of your target.'
  },
  {
    id: 'sage_conjure_swarm',
    name: 'CONJURE SWARM',
    domain: 'Sage',
    level: 2,
    type: 'Spell',
    recallCost: 1,
    description: "Tekaira Armored Beetles: Mark a Stress to conjure armored beetles that encircle you. When you next take damage, reduce the severity by one threshold. You can spend a Hope to keep the beetles conjured after taking damage.\nFire Flies: Make a Spellcast Roll against all adversaries within Close range. Spend a Hope to deal 2d8+3 magic damage to targets you succeeded against."
  },
  {
    id: 'sage_natural_familiar',
    name: 'NATURAL FAMILIAR',
    domain: 'Sage',
    level: 2,
    type: 'Spell',
    recallCost: 1,
    description: "Spend a Hope to summon a small nature spirit or forest critter to your side until your next rest, you cast Natural Familiar again, or the familiar is targeted by an attack. If you spend an additional Hope, you can summon a familiar that flies. You can communicate with them, make a Spellcast Roll to command them to perform simple tasks, and mark a Stress to see through their eyes.\nWhen you deal damage to an adversary within Melee range of your familiar, you add a d6 to your damage roll."
  },
  {
    id: 'sage_corrosive_projectile',
    name: 'CORROSIVE PROJECTILE',
    domain: 'Sage',
    level: 3,
    type: 'Spell',
    recallCost: 1,
    description: 'Make a Spellcast Roll against a target within Far range. On a success, deal d6+4 magic damage using your Proficiency. Additionally, mark 2 or more Stress to make them permanently Corroded. While a target is Corroded, they gain a −1 penalty to their Difficulty for every 2 Stress you spent. This condition can stack.'
  },
  {
    id: 'sage_towering_stalk',
    name: 'TOWERING STALK',
    domain: 'Sage',
    level: 3,
    type: 'Spell',
    recallCost: 1,
    description: 'Once per rest, you can conjure a thick, twisting stalk within Close range that can be easily climbed. Its height can grow up to Far range.\nMark a Stress to use this spell as an attack. Make a Spellcast Roll against an adversary or group of adversaries within Close range. The erupting stalk lifts targets you succeed against into the air and drops them, dealing d8 physical damage using your Proficiency.'
  },
  {
    id: 'sage_death_grip',
    name: 'DEATH GRIP',
    domain: 'Sage',
    level: 4,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll against a target within Close range and choose one of the following options:\n• You pull the target into Melee range or pull yourself into Melee range of them.\n• You constrict the target and force them to mark 2 Stress.\n• All adversaries between you and the target must succeed on a Reaction Roll (13) or be hit by vines, taking 3d6+2 physical damage.\nOn a success, vines reach out from your hands, causing the chosen effect and temporarily Restraining the target."
  },
  {
    id: 'sage_healing_field',
    name: 'HEALING FIELD',
    domain: 'Sage',
    level: 4,
    type: 'Spell',
    recallCost: 2,
    description: 'Once per long rest, you can conjure a field of healing plants around you. Everywhere within Close range of you bursts to life with vibrant nature, allowing you and all allies in the area to clear a Hit Point.\nSpend 2 Hope to allow you and all allies to clear 2 Hit Points instead.'
  },
  {
    id: 'sage_thorn_skin',
    name: 'THORN SKIN',
    domain: 'Sage',
    level: 5,
    type: 'Spell',
    recallCost: 1,
    description: "Once per rest, spend a Hope to sprout thorns all over your body. When you do, place a number of tokens equal to your Spellcast trait on this card. When you take damage, you can spend any number of tokens to roll that number of d6s. Add the results together and reduce the incoming damage by that amount. If you’re within Melee range of the attacker, deal that amount of damage back to them.\nWhen you take a rest, clear all unspent tokens."
  },
  {
    id: 'sage_wild_fortress',
    name: 'WILD FORTRESS',
    domain: 'Sage',
    level: 5,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll (13). On a success, spend 2 Hope to grow a natural barricade in the shape of a dome that you and one ally can take cover within. While inside the dome, a creature can’t be targeted by attacks and can’t make attacks. Attacks made against the dome automatically succeed. The dome has the following damage thresholds and lasts until it marks 3 Hit Points. Place tokens on this card to represent marking Hit Points.\nThresholds: 15/30"
  },
  {
    id: 'sage_conjured_steeds',
    name: 'CONJURED STEEDS',
    domain: 'Sage',
    level: 6,
    type: 'Spell',
    recallCost: 0,
    description: 'Spend any number of Hope to conjure that many magical steeds (such as horses, camels, or elephants) that you and your allies can ride until your next long rest or the steeds take any damage. The steeds double your land speed while traveling and, when in danger, allow you to move within Far range without having to roll. Creatures riding a steed gain a −2 penalty to attack rolls and a +2 bonus to damage rolls.'
  },
  {
    id: 'sage_forager',
    name: 'FORAGER',
    domain: 'Sage',
    level: 6,
    type: 'Ability',
    recallCost: 1,
    description: "As an additional downtime move you can choose, roll a d6 to see what you forage. Work with the GM to describe it and add it to your inventory as a consumable. Your party can carry up to five foraged consumables at a time.\n1. A unique food (Clear 2 Stress)\n2. A beautiful relic (Gain 2 Hope)\n3. An arcane rune (+2 to a Spellcast Roll)\n4. A healing vial (Clear 2 Hit Points)\n5. A luck charm (Reroll any die)\n6. Choose one of the options above."
  },
  {
    id: 'sage_sage_touched',
    name: 'SAGE-TOUCHED',
    domain: 'Sage',
    level: 7,
    type: 'Ability',
    recallCost: 2,
    description: "When 4 or more of the domain cards in your loadout are from the Sage domain, gain the following benefits:\n• While you’re in a natural environment, you gain a +2 bonus to your Spellcast Rolls.\n• Once per rest, you can double your Agility or Instinct when making a roll that uses that trait. You must choose to do this before you roll."
  },
  {
    id: 'sage_wild_surge',
    name: 'WILD SURGE',
    domain: 'Sage',
    level: 7,
    type: 'Spell',
    recallCost: 2,
    description: "Once per long rest, mark a Stress to channel the natural world around you and enhance yourself. Describe how your appearance changes, then place a d6 on this card with the 1 value facing up.\nWhile the Wild Surge Die is active, you add its value to every action roll you make. After you add its value to a roll, increase the Wild Surge Die’s value by one. When the die’s value would exceed 6 or you take a rest, this form drops and you must mark an additional Stress."
  },
  {
    id: 'sage_forest_sprites',
    name: 'FOREST SPRITES',
    domain: 'Sage',
    level: 8,
    type: 'Spell',
    recallCost: 2,
    description: "Make a Spellcast Roll (13). On a success, spend any number of Hope to create an equal number of small forest sprites who appear at points you choose within Far range, providing the following benefits:\n• Your allies gain a +3 bonus to attack rolls against adversaries within Melee range of a sprite.\n• An ally who marks an Armor Slot while within Melee range of a sprite can mark an additional Armor Slot.\nA sprite vanishes after granting a benefit or taking any damage."
  },
  {
    id: 'sage_rejuvenation_barrier',
    name: 'REJUVENATION BARRIER',
    domain: 'Sage',
    level: 8,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll (15). Once per rest on a success, create a temporary barrier of protective energy around you at Very Close range. You and all allies within the barrier when this spell is cast clear 1d4 Hit Points. While the barrier is up, you and all allies within have resistance to physical damage from outside the barrier.\nWhen you move, the barrier follows you."
  },
  {
    id: 'sage_fane_of_the_wilds',
    name: 'FANE OF THE WILDS',
    domain: 'Sage',
    level: 9,
    type: 'Ability',
    recallCost: 2,
    description: "After a long rest, place a number of tokens equal to the number of Sage domain cards in your loadout and vault on this card.\nWhen you would make a Spellcast Roll, you can spend any number of tokens after the roll to gain a +1 bonus for each token spent.\nWhen you critically succeed on a Spellcast Roll for a Sage domain spell, gain a token.\nWhen you take a long rest, clear all unspent tokens."
  },
  {
    id: 'sage_plant_dominion',
    name: 'PLANT DOMINION',
    domain: 'Sage',
    level: 9,
    type: 'Spell',
    recallCost: 1,
    description: 'Make a Spellcast Roll (18). Once per long rest on a success, you reshape the natural world, changing the surrounding plant life anywhere within Far range of you. For example, you can grow trees instantly, clear a path through dense vines, or create a wall of roots.'
  },
  {
    id: 'sage_force_of_nature',
    name: 'FORCE OF NATURE',
    domain: 'Sage',
    level: 10,
    type: 'Spell',
    recallCost: 2,
    description: "Mark a Stress to transform into a hulking nature spirit, gaining the following benefits:\n• When you succeed on an attack or Spellcast Roll, gain a +10 bonus to the damage roll.\n• When you deal enough damage to defeat a creature within Close range, you absorb them and clear an Armor Slot.\n• You can’t be Restrained.\nBefore you make an action roll, you must spend a Hope. If you can’t, you revert to your normal form."
  },
  {
    id: 'sage_tempest',
    name: 'TEMPEST',
    domain: 'Sage',
    level: 10,
    type: 'Spell',
    recallCost: 2,
    description: "Choose one of the following tempests and make a Spellcast Roll against all targets within Far range. Targets you succeed against experience its effects until the GM spends a Fear on their turn to end this spell.\n• Blizzard: Deal 2d20+8 magic damage and targets are temporarily Vulnerable.\n• Hurricane: Deal 3d10+10 magic damage and choose a direction the wind is blowing. Targets can’t move against the wind.\n• Sandstorm: Deal 5d6+9 magic damage. Attacks made from beyond Melee range have disadvantage."
  }
];
