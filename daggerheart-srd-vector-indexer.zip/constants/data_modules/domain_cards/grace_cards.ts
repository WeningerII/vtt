import { DomainCard } from '../../../types';

export const GRACE_DOMAIN_CARDS: DomainCard[] = [
  {
    id: 'grace_deft_deceiver',
    name: 'DEFT DECEIVER',
    domain: 'Grace',
    level: 1,
    type: 'Ability',
    recallCost: 0,
    description: 'Spend a Hope to gain advantage on a roll to deceive or trick someone into believing a lie you tell them.'
  },
  {
    id: 'grace_enrapture',
    name: 'ENRAPTURE',
    domain: 'Grace',
    level: 1,
    type: 'Spell',
    recallCost: 0,
    description: "Make a Spellcast Roll against a target within Close range. On a success, they become temporarily Enraptured. While Enraptured, a target’s attention is fixed on you, narrowing their field of view and drowning out any sound but your voice. Once per rest on a success, you can mark a Stress to force the Enraptured target to mark a Stress as well."
  },
  {
    id: 'grace_inspirational_words',
    name: 'INSPIRATIONAL WORDS',
    domain: 'Grace',
    level: 1,
    type: 'Ability',
    recallCost: 1,
    description: "Your speech is imbued with power. After a long rest, place a number of tokens on this card equal to your Presence. When you speak with an ally, you can spend a token from this card to give them one benefit from the following options:\n• Your ally clears a Stress.\n• Your ally clears a Hit Point.\n• Your ally gains a Hope.\nWhen you take a long rest, clear all unspent tokens."
  },
  {
    id: 'grace_tell_no_lies',
    name: 'TELL NO LIES',
    domain: 'Grace',
    level: 2,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll against a target within Very Close range. On a success, they can’t lie to you while they remain within Close range, but they are not compelled to speak. If you ask them a question and they refuse to answer, they must mark a Stress and the effect ends. The target is typically unaware this spell has been cast on them until it causes them to utter the truth."
  },
  {
    id: 'grace_troublemaker',
    name: 'TROUBLEMAKER',
    domain: 'Grace',
    level: 2,
    type: 'Ability',
    recallCost: 2,
    description: 'When you taunt or provoke a target within Far range, make a Presence Roll against them. Once per rest on a success, roll a number of d4s equal to your Proficiency. The target must mark Stress equal to the highest result rolled.'
  },
  {
    id: 'grace_hypnotic_shimmer',
    name: 'HYPNOTIC SHIMMER',
    domain: 'Grace',
    level: 3,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll against all adversaries in front of you within Close range. Once per rest on a success, create an illusion of flashing colors and lights that temporarily Stuns targets you succeed against and forces them to mark a Stress. While Stunned, they can’t use reactions and can’t take any other actions until they clear this condition."
  },
  {
    id: 'grace_invisibility',
    name: 'INVISIBILITY',
    domain: 'Grace',
    level: 3,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll (10). On a success, mark a Stress and choose yourself or an ally within Melee range to become Invisible. An Invisible creature can’t be seen except through magical means and attack rolls against them are made with disadvantage. Place a number of tokens on this card equal to your Spellcast trait. When the Invisible creature takes an action, spend a token from this card. After the action that spends the last token is resolved, the effect ends.\nYou can only hold Invisibility on one creature at a time."
  },
  {
    id: 'grace_soothing_speech',
    name: 'SOOTHING SPEECH',
    domain: 'Grace',
    level: 4,
    type: 'Ability',
    recallCost: 1,
    description: 'During a short rest, when you take the time to comfort another character while using the Tend to Wounds downtime move on them, clear an additional Hit Point on that character. When you do, you also clear 2 Hit Points.'
  },
  {
    id: 'grace_through_your_eyes',
    name: 'THROUGH YOUR EYES',
    domain: 'Grace',
    level: 4,
    type: 'Spell',
    recallCost: 1,
    description: 'Choose a target within Very Far range. You can see through their eyes and hear through their ears. You can transition between using your own senses or the target’s freely until you cast another spell or until your next rest.'
  },
  {
    id: 'grace_thought_delver',
    name: 'THOUGHT DELVER',
    domain: 'Grace',
    level: 5,
    type: 'Spell',
    recallCost: 2,
    description: "You can peek into the minds of others. Spend a Hope to read the vague surface thoughts of a target within Far range. Make a Spellcast Roll against the target to delve for deeper, more hidden thoughts.\nOn a roll with Fear, the target might, at the GM’s discretion, become aware that you’re reading their thoughts."
  },
  {
    id: 'grace_words_of_discord',
    name: 'WORDS OF DISCORD',
    domain: 'Grace',
    level: 5,
    type: 'Spell',
    recallCost: 1,
    description: "Whisper words of discord to an adversary within Melee range and make a Spellcast Roll (13). On a success, the target must mark a Stress and make an attack against another adversary instead of against you or your allies.\nOnce this attack is over, the target realizes what happened. The next time you cast Words of Discord on them, gain a −5 penalty to the Spellcast Roll."
  },
  {
    id: 'grace_never_upstaged',
    name: 'NEVER UPSTAGED',
    domain: 'Grace',
    level: 6,
    type: 'Ability',
    recallCost: 2,
    description: 'When you mark 1 or more Hit Points from an attack, you can mark a Stress to place a number of tokens equal to the number of Hit Points you marked on this card. On your next successful attack, gain a +5 bonus to your damage roll for each token on this card, then clear all tokens.'
  },
  {
    id: 'grace_share_the_burden',
    name: 'SHARE THE BURDEN',
    domain: 'Grace',
    level: 6,
    type: 'Spell',
    recallCost: 0,
    description: 'Once per rest, take on the Stress from a willing creature within Melee range. The target describes what intimate knowledge or emotions telepathically leak from their mind in this moment between you. Transfer any number of their marked Stress to you, then gain a Hope for each Stress transferred.'
  },
  {
    id: 'grace_endless_charisma',
    name: 'ENDLESS CHARISMA',
    domain: 'Grace',
    level: 7,
    type: 'Ability',
    recallCost: 1,
    description: 'After you make an action roll to persuade, lie, or garner favor, you can spend a Hope to reroll the Hope or Fear Die.'
  },
  {
    id: 'grace_grace_touched',
    name: 'GRACE-TOUCHED',
    domain: 'Grace',
    level: 7,
    type: 'Ability',
    recallCost: 2,
    description: "When 4 or more of the domain cards in your loadout are from the Grace domain, gain the following benefits:\n• You can mark an Armor Slot instead of marking a Stress.\n• When you would force a target to mark a number of Hit Points, you can choose instead to force them to mark that number of Stress."
  },
  {
    id: 'grace_astral_projection',
    name: 'ASTRAL PROJECTION',
    domain: 'Grace',
    level: 8,
    type: 'Spell',
    recallCost: 0,
    description: "Once per long rest, mark a Stress to create a projected copy of yourself that can appear anywhere you’ve been before.\nYou can see and hear through the projection as though it were you and affect the world as though you were there. A creature investigating the projection can tell it’s of magical origin. This effect lasts until your next rest or your projection takes any damage."
  },
  {
    id: 'grace_mass_enrapture',
    name: 'MASS ENRAPTURE',
    domain: 'Grace',
    level: 8,
    type: 'Spell',
    recallCost: 3,
    description: "Make a Spellcast Roll against all targets within Far range. Targets you succeed against become temporarily Enraptured. While Enraptured, a target’s attention is fixed on you, narrowing their field of view and drowning out any sound but your voice. Mark a Stress to force all Enraptured targets to mark a Stress, ending this spell."
  },
  {
    id: 'grace_copycat',
    name: 'COPYCAT',
    domain: 'Grace',
    level: 9,
    type: 'Spell',
    recallCost: 3,
    description: "Once per long rest, this card can mimic the features of another domain card of level 8 or lower in another player’s loadout. Spend Hope equal to half the card’s level to gain access to the feature. It lasts until your next rest or they place the card in their vault."
  },
  {
    id: 'grace_master_of_the_craft',
    name: 'MASTER OF THE CRAFT',
    domain: 'Grace',
    level: 9,
    type: 'Ability',
    recallCost: 0,
    description: 'Gain a permanent +2 bonus to two of your Experiences or a permanent +3 bonus to one of your Experiences. Then place this card in your vault permanently.'
  },
  {
    id: 'grace_encore',
    name: 'ENCORE',
    domain: 'Grace',
    level: 10,
    type: 'Spell',
    recallCost: 1,
    description: 'When an ally within Close range deals damage to an adversary, you can make a Spellcast Roll against that same target. On a success, you deal the same damage to the target that your ally dealt. If your Spellcast Roll succeeds with Fear, place this card in your vault.'
  },
  {
    id: 'grace_notorious',
    name: 'NOTORIOUS',
    domain: 'Grace',
    level: 10,
    type: 'Ability',
    recallCost: 0,
    description: "People know who you are and what you’ve done, and they treat you differently because of it. When you leverage your notoriety to get what you want, you can mark a Stress before you roll to gain a +10 bonus to the result. Your food and drinks are always free wherever you go, and everything else you buy is reduced in price by one bag of gold (to a minimum of one handful).\nThis card doesn’t count against your loadout’s domain card maximum of 5 and can’t be placed in your vault."
  }
];
