import { DomainCard } from '../../../types';

export const ARCANA_DOMAIN_CARDS: DomainCard[] = [
  {
    id: 'arcana_rune_ward',
    name: 'RUNE WARD',
    domain: 'Arcana',
    level: 1,
    type: 'Spell',
    recallCost: 0,
    description: "You have a deeply personal trinket that can be infused with protective magic and held as a ward by you or an ally. Describe what it is and why it’s important to you. The ward’s holder can spend a Hope to reduce incoming damage by 1d8.\nIf the Ward Die result is 8, the ward’s power ends after it reduces damage this turn. It can be recharged for free on your next rest."
  },
  {
    id: 'arcana_unleash_chaos',
    name: 'UNLEASH CHAOS',
    domain: 'Arcana',
    level: 1,
    type: 'Spell',
    recallCost: 1,
    description: "At the beginning of a session, place a number of tokens equal to your Spellcast trait on this card.\nMake a Spellcast Roll against a target within Far range and spend any number of tokens to channel raw energy from within yourself to unleash against them. On a success, roll a number of d10s equal to the tokens you spent and deal that much magic damage to the target. Mark a Stress to replenish this card with tokens (up to your Spellcast trait).\nAt the end of each session, clear all unspent tokens."
  },
  {
    id: 'arcana_wall_walk',
    name: 'WALL WALK',
    domain: 'Arcana',
    level: 1,
    type: 'Spell',
    recallCost: 1,
    description: 'Spend a Hope to allow a creature you can touch to climb on walls and ceilings as easily as walking on the ground. This lasts until the end of the scene or you cast Wall Walk again.'
  },
  {
    id: 'arcana_cinder_grasp',
    name: 'CINDER GRASP',
    domain: 'Arcana',
    level: 2,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll against a target within Melee range. On a success, the target instantly bursts into flames, takes 1d20+3 magic damage, and is temporarily lit On Fire.\nWhen a creature acts while On Fire, they must take an extra 2d6 magic damage if they are still On Fire at the end of their action."
  },
  {
    id: 'arcana_floating_eye',
    name: 'FLOATING EYE',
    domain: 'Arcana',
    level: 2,
    type: 'Spell',
    recallCost: 0,
    description: "Spend a Hope to create a single, small floating orb that you can move anywhere within Very Far range. While this spell is active, you can see through the orb as though you’re looking out from its position. You can transition between using your own senses and seeing through the orb freely. If the orb takes damage or moves out of range, the spell ends."
  },
  {
    id: 'arcana_counterspell',
    name: 'COUNTERSPELL',
    domain: 'Arcana',
    level: 3,
    type: 'Spell',
    recallCost: 2,
    description: 'You can interrupt a magical effect taking place by making a reaction roll using your Spellcast trait. On a success, the effect stops and any consequences are avoided, and this card is placed in your vault.'
  },
  {
    id: 'arcana_flight',
    name: 'FLIGHT',
    domain: 'Arcana',
    level: 3,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll (15). On a success, place a number of tokens equal to your Agility on this card (minimum 1). When you make an action roll while flying, spend a token from this card. After the action that spends the last token is resolved, you descend to the ground directly below you."
  },
  {
    id: 'arcana_blink_out',
    name: 'BLINK OUT',
    domain: 'Arcana',
    level: 4,
    type: 'Spell',
    recallCost: 1,
    description: 'Make a Spellcast Roll (12). On a success, spend a Hope to teleport to another point you can see within Far range. If any willing creatures are within Very Close range, spend an additional Hope for each creature to bring them with you.'
  },
  {
    id: 'arcana_preservation_blast',
    name: 'PRESERVATION BLAST',
    domain: 'Arcana',
    level: 4,
    type: 'Spell',
    recallCost: 2,
    description: 'Make a Spellcast Roll against all targets within Melee range. Targets you succeed against are forced back to Far range and take d8+3 magic damage using your Spellcast trait.'
  },
  {
    id: 'arcana_chain_lightning',
    name: 'CHAIN LIGHTNING',
    domain: 'Arcana',
    level: 5,
    type: 'Spell',
    recallCost: 1,
    description: "Mark 2 Stress to make a Spellcast Roll, unleashing lightning on all targets within Close range. Targets you succeed against must make a reaction roll with a Difficulty equal to the result of your Spellcast Roll. Targets who fail take 2d8+4 magic damage. Additional adversaries not already targeted by Chain Lightning and within Close range of previous targets who took damage must also make the reaction roll. Targets who fail take 2d8+4 magic damage. This chain continues until there are no more adversaries within range."
  },
  {
    id: 'arcana_premonition',
    name: 'PREMONITION',
    domain: 'Arcana',
    level: 5,
    type: 'Spell',
    recallCost: 2,
    description: 'You can channel arcane energy to have visions of the future. Once per long rest, immediately after the GM conveys the consequences of a roll you made, you can rescind the move and consequences like they never happened and make another move instead.'
  },
  {
    id: 'arcana_rift_walker',
    name: 'RIFT WALKER',
    domain: 'Arcana',
    level: 6,
    type: 'Spell',
    recallCost: 2,
    description: "Make a Spellcast Roll (15). On a success, you place an arcane marking on the ground where you currently stand. The next time you successfully cast Rift Walker, a rift in space opens up, providing safe passage back to the exact spot where the marking was placed. This rift stays open until you choose to close it or you cast another spell.\nYou can drop the spell at any time to cast Rift Walker again and place the marking somewhere new."
  },
  {
    id: 'arcana_telekinesis',
    name: 'TELEKINESIS',
    domain: 'Arcana',
    level: 6,
    type: 'Spell',
    recallCost: 0,
    description: "Make a Spellcast Roll against a target within Far range. On a success, you can use your mind to move them anywhere within Far range of their original position. You can throw the lifted target as an attack by making an additional Spellcast Roll against the second target you’re trying to attack. On a success, deal d12+4 physical damage to the second target using your Proficiency. This spell then ends."
  },
  {
    id: 'arcana_arcana_touched',
    name: 'ARCANA-TOUCHED',
    domain: 'Arcana',
    level: 7,
    type: 'Ability',
    recallCost: 2,
    description: "When 4 or more of the domain cards in your loadout are from the Arcana domain, gain the following benefits:\n• +1 bonus to your Spellcast Rolls\n• Once per rest, you can switch the results of your Hope and Fear Dice."
  },
  {
    id: 'arcana_cloaking_blast',
    name: 'CLOAKING BLAST',
    domain: 'Arcana',
    level: 7,
    type: 'Spell',
    recallCost: 2,
    description: "When you make a successful Spellcast Roll to cast a different spell, you can spend a Hope to become Cloaked. While Cloaked, you remain unseen if you are stationary when an adversary moves to where they would normally see you. When you move into or within an adversary’s line of sight or make an attack, you are no longer Cloaked."
  },
  {
    id: 'arcana_arcane_reflection',
    name: 'ARCANE REFLECTION',
    domain: 'Arcana',
    level: 8,
    type: 'Spell',
    recallCost: 1,
    description: 'When you would take magic damage, you can spend any number of Hope to roll that many d6s. If any roll a 6, the attack is reflected back to the caster, dealing the damage to them instead.'
  },
  {
    id: 'arcana_confusing_aura',
    name: 'CONFUSING AURA',
    domain: 'Arcana',
    level: 8,
    type: 'Spell',
    recallCost: 2,
    description: "Make a Spellcast Roll (14). Once per long rest on a success, you create a layer of illusion over your body that makes it hard to tell exactly where you are. Mark any number of Stress to make that many additional layers. When an adversary makes an attack against you, roll a number of d6s equal to the number of layers currently active. If any roll a 5 or higher, one layer of the aura is destroyed and the attack fails. If all the results are 4 or lower, you take the damage and this spell ends."
  },
  {
    id: 'arcana_earthquake',
    name: 'EARTHQUAKE',
    domain: 'Arcana',
    level: 9,
    type: 'Spell',
    recallCost: 2,
    description: "Make a Spellcast Roll (16). Once per rest on a success, all targets within Very Far range who aren’t flying must make a Reaction Roll (18). Targets who fail take 3d10+8 physical damage and are temporarily Vulnerable. Targets who succeed take half damage.\nAdditionally, when you succeed on the Spellcast Roll, all terrain within Very Far range becomes difficult to move through and structures within this range might sustain damage or crumble."
  },
  {
    id: 'arcana_sensory_projection',
    name: 'SENSORY PROJECTION',
    domain: 'Arcana',
    level: 9,
    type: 'Spell',
    recallCost: 0,
    description: "Once per rest, make a Spellcast Roll (15). On a success, drop into a vision that lets you clearly see and hear any place you have been before as though you are standing there in this moment. You can move freely in this vision and are not constrained by the physics or impediments of a physical body. This spell cannot be detected by mundane or magical means. You drop out of this vision upon taking damage or casting another spell."
  },
  {
    id: 'arcana_adjust_reality',
    name: 'ADJUST REALITY',
    domain: 'Arcana',
    level: 10,
    type: 'Spell',
    recallCost: 1,
    description: 'After you or a willing ally make any roll, you can spend 5 Hope to change the numerical result of that roll to a result of your choice instead. The result must be plausible within the range of the dice.'
  },
  {
    id: 'arcana_falling_sky',
    name: 'FALLING SKY',
    domain: 'Arcana',
    level: 10,
    type: 'Spell',
    recallCost: 1,
    description: 'Make a Spellcast Roll against all adversaries within Far range. Mark any number of Stress to make shards of arcana rain down from above. Targets you succeed against take 1d20+2 magic damage for each Stress marked.'
  }
];
