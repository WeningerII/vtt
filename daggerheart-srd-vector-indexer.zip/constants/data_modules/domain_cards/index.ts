import { DomainCard } from '../../../types';
import { ARCANA_DOMAIN_CARDS } from './arcana_cards';
import { BLADE_DOMAIN_CARDS } from './blade_cards';
import { BONE_DOMAIN_CARDS } from './bone_cards';
import { CODEX_DOMAIN_CARDS } from './codex_cards';
import { GRACE_DOMAIN_CARDS } from './grace_cards';
import { MIDNIGHT_DOMAIN_CARDS } from './midnight_cards';
import { SAGE_DOMAIN_CARDS } from './sage_cards';
import { SPLENDOR_DOMAIN_CARDS } from './splendor_cards';
import { VALOR_DOMAIN_CARDS } from './valor_cards';

export const DOMAIN_CARDS: DomainCard[] = [
  ...ARCANA_DOMAIN_CARDS,
  ...BLADE_DOMAIN_CARDS,
  ...BONE_DOMAIN_CARDS,
  ...CODEX_DOMAIN_CARDS,
  ...GRACE_DOMAIN_CARDS,
  ...MIDNIGHT_DOMAIN_CARDS,
  ...SAGE_DOMAIN_CARDS,
  ...SPLENDOR_DOMAIN_CARDS,
  ...VALOR_DOMAIN_CARDS,
];
