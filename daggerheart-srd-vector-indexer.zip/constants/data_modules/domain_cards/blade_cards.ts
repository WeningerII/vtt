
import { DomainCard } from '../../../types';

export const BLADE_DOMAIN_CARDS: DomainCard[] = [
  {
    id: 'blade_get_back_up',
    name: 'GET BACK UP',
    domain: 'Blade',
    level: 1,
    type: 'Ability',
    recallCost: 1,
    description: 'When you take Severe damage, you can mark a Stress to reduce the severity by one threshold.'
  },
  {
    id: 'blade_not_good_enough',
    name: 'NOT GOOD ENOUGH',
    domain: 'Blade',
    level: 1,
    type: 'Ability',
    recallCost: 1,
    description: 'When you roll your damage dice, you can reroll any 1s or 2s.'
  },
  {
    id: 'blade_whirlwind',
    name: 'WHIRLWIND',
    domain: 'Blade',
    level: 1,
    type: 'Ability',
    recallCost: 0,
    description: 'When you make a successful attack against a target within Very Close range, you can spend a Hope to use the attack against all other targets within Very Close range. All additional adversaries you succeed against with this ability take half damage.'
  },
  {
    id: 'blade_a_soldiers_bond',
    name: 'A SOLDIER’S BOND',
    domain: 'Blade',
    level: 2,
    type: 'Ability',
    recallCost: 1,
    description: 'Once per long rest, when you compliment someone or ask them about something they’re good at, you can both gain 3 Hope.'
  },
  {
    id: 'blade_reckless',
    name: 'RECKLESS',
    domain: 'Blade',
    level: 2,
    type: 'Ability',
    recallCost: 1,
    description: 'Mark a Stress to gain advantage on an attack.'
  },
  {
    id: 'blade_scramble',
    name: 'SCRAMBLE',
    domain: 'Blade',
    level: 3,
    type: 'Ability',
    recallCost: 1,
    description: 'Once per rest, when a creature within Melee range would deal damage to you, you can avoid the attack and safely move out of Melee range of the enemy.'
  },
  {
    id: 'blade_versatile_fighter',
    name: 'VERSATILE FIGHTER',
    domain: 'Blade',
    level: 3,
    type: 'Ability',
    recallCost: 1,
    description: 'You can use a different character trait for an equipped weapon, rather than the trait the weapon calls for.\nWhen you deal damage, you can mark a Stress to use the maximum result of one of your damage dice instead of rolling it.'
  },
  {
    id: 'blade_deadly_focus',
    name: 'DEADLY FOCUS',
    domain: 'Blade',
    level: 4,
    type: 'Ability',
    recallCost: 2,
    description: 'Once per rest, you can apply all your focus toward a target of your choice. Until you attack another creature, you defeat the target, or the battle ends, gain a +1 bonus to your Proficiency.'
  },
  {
    id: 'blade_fortified_armor',
    name: 'FORTIFIED ARMOR',
    domain: 'Blade',
    level: 4,
    type: 'Ability',
    recallCost: 0,
    description: 'While you are wearing armor, gain a +2 bonus to your damage thresholds.'
  },
  {
    id: 'blade_champions_edge',
    name: 'CHAMPION’S EDGE',
    domain: 'Blade',
    level: 5,
    type: 'Ability',
    recallCost: 1,
    description: 'When you critically succeed on an attack, you can spend up to 3 Hope and choose one of the following options for each Hope spent:\n• You clear a Hit Point.\n• You clear an Armor Slot.\n• The target must mark an additional Hit Point.\nYou can’t choose the same option more than once.'
  },
  {
    id: 'blade_vitality',
    name: 'VITALITY',
    domain: 'Blade',
    level: 5,
    type: 'Ability',
    recallCost: 0,
    description: 'When you choose this card, permanently gain two of the following benefits:\n• One Stress slot\n• One Hit Point slot\n• +2 bonus to your damage thresholds\nThen place this card in your vault permanently.'
  },
  {
    id: 'blade_battle_hardened',
    name: 'BATTLE-HARDENED',
    domain: 'Blade',
    level: 6,
    type: 'Ability',
    recallCost: 2,
    description: 'Once per long rest when you would make a Death Move, you can spend a Hope to clear a Hit Point instead.'
  },
  {
    id: 'blade_rage_up',
    name: 'RAGE UP',
    domain: 'Blade',
    level: 6,
    type: 'Ability',
    recallCost: 1,
    description: 'Before you make an attack, you can mark a Stress to gain a bonus to your damage roll equal to twice your Strength.\nYou can Rage Up twice per attack.'
  },
  {
    id: 'blade_blade_touched',
    name: 'BLADE-TOUCHED',
    domain: 'Blade',
    level: 7,
    type: 'Ability',
    recallCost: 1,
    description: 'When 4 or more of the domain cards in your loadout are from the Blade domain, gain the following benefits:\n• +2 bonus to your attack rolls\n• +4 bonus to your Severe damage threshold'
  },
  {
    id: 'blade_glancing_blow',
    name: 'GLANCING BLOW',
    domain: 'Blade',
    level: 7,
    type: 'Ability',
    recallCost: 1,
    description: 'When you fail an attack, you can mark a Stress to deal weapon damage using half your Proficiency.'
  },
  {
    id: 'blade_battle_cry',
    name: 'BATTLE CRY',
    domain: 'Blade',
    level: 8,
    type: 'Ability',
    recallCost: 2,
    description: 'Once per long rest, while you’re charging into danger, you can muster a rousing call that inspires your allies. All allies who can hear you each clear a Stress and gain a Hope. Additionally, your allies gain advantage on attack rolls until you or an ally rolls a failure with Fear.'
  },
  {
    id: 'blade_frenzy',
    name: 'FRENZY',
    domain: 'Blade',
    level: 8,
    type: 'Ability',
    recallCost: 3,
    description: 'Once per long rest, you can go into a Frenzy until there are no more adversaries within sight.\nWhile Frenzied, you can’t use Armor Slots, and you gain a +10 bonus to your damage rolls and a +8 bonus to your Severe damage threshold.'
  },
  {
    id: 'blade_gore_and_glory',
    name: 'GORE AND GLORY',
    domain: 'Blade',
    level: 9,
    type: 'Ability',
    recallCost: 2,
    description: 'When you critically succeed on a weapon attack, gain an additional Hope or clear an additional Stress.\nAdditionally, when you deal enough damage to defeat an enemy, gain a Hope or clear a Stress.'
  },
  {
    id: 'blade_reapers_strike',
    name: 'REAPER’S STRIKE',
    domain: 'Blade',
    level: 9,
    type: 'Ability',
    recallCost: 3,
    description: 'Once per long rest, spend a Hope to make an attack roll. The GM tells you which targets within range it would succeed against. Choose one of these targets and force them to mark 5 Hit Points.'
  },
  {
    id: 'blade_battle_monster',
    name: 'BATTLE MONSTER',
    domain: 'Blade',
    level: 10,
    type: 'Ability',
    recallCost: 0,
    description: 'When you make a successful attack against an adversary, you can mark 4 Stress to force the target to mark a number of Hit Points equal to the number of Hit Points you currently have marked instead of rolling for damage.'
  },
  {
    id: 'blade_onslaught',
    name: 'ONSLAUGHT',
    domain: 'Blade',
    level: 10,
    type: 'Ability',
    recallCost: 3,
    description: 'When you successfully make an attack with your weapon, you never deal damage beneath a target’s Major damage threshold (the target always marks a minimum of 2 Hit Points).\nAdditionally, when a creature within your weapon’s range deals damage to an ally with an attack that doesn’t include you, you can mark a Stress to force them to make a Reaction Roll (15). On a failure, the target must mark a Hit Point.'
  }
];
