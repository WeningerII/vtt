import { DomainCard } from '../../../types';

export const SPLENDOR_DOMAIN_CARDS: DomainCard[] = [
  {
    id: 'splendor_bolt_beacon',
    name: 'BOLT BEACON',
    domain: 'Splendor',
    level: 1,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll against a target within Far range. On a success, spend a Hope to send a bolt of shimmering light toward them, dealing d8+2 magic damage using your Proficiency. The target becomes temporarily Vulnerable and glows brightly until this condition is cleared."
  },
  {
    id: 'splendor_mending_touch',
    name: 'MENDING TOUCH',
    domain: 'Splendor',
    level: 1,
    type: 'Spell',
    recallCost: 1,
    description: "You lay your hands upon a creature and channel healing magic to close their wounds. When you can take a few minutes to focus on the target you’re helping, you can spend 2 Hope to clear a Hit Point or a Stress on them.\nOnce per long rest, when you spend this healing time learning something new about them or revealing something about yourself, you can clear 2 Hit Points or 2 Stress on them instead."
  },
  {
    id: 'splendor_reassurance',
    name: 'REASSURANCE',
    domain: 'Splendor',
    level: 1,
    type: 'Ability',
    recallCost: 0,
    description: 'Once per rest, after an ally attempts an action roll but before the consequences take place, you can offer assistance or words of support. When you do, your ally can reroll their dice.'
  },
  {
    id: 'splendor_final_words',
    name: 'FINAL WORDS',
    domain: 'Splendor',
    level: 2,
    type: 'Spell',
    recallCost: 1,
    description: "You can infuse a corpse with a moment of life to speak with it. Make a Spellcast Roll (13). On a success with Hope, the corpse answers up to three questions. On a success with Fear, the corpse answers one question. The corpse answers truthfully, but it can’t impart information it didn’t know in life. On a failure, or once the corpse has finished answering your questions, the body turns to dust."
  },
  {
    id: 'splendor_healing_hands',
    name: 'HEALING HANDS',
    domain: 'Splendor',
    level: 2,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll (13) and target a creature other than yourself within Melee range. On a success, mark a Stress to clear 2 Hit Points or 2 Stress on the target. On a failure, mark a Stress to clear a Hit Point or a Stress on the target. You can’t heal the same target again until your next long rest."
  },
  {
    id: 'splendor_second_wind',
    name: 'SECOND WIND',
    domain: 'Splendor',
    level: 3,
    type: 'Ability',
    recallCost: 2,
    description: 'Once per rest, when you succeed on an attack against an adversary, you can clear 3 Stress or a Hit Point. On a success with Hope, you also clear 3 Stress or a Hit Point on an ally within Close range of you.'
  },
  {
    id: 'splendor_voice_of_reason',
    name: 'VOICE OF REASON',
    domain: 'Splendor',
    level: 3,
    type: 'Ability',
    recallCost: 1,
    description: "You speak with an unmatched power and authority. You have advantage on action rolls to de-escalate violent situations or convince someone to follow your lead.\nAdditionally, you’re emboldened in moments of duress. When all of your Stress slots are marked, you gain a +1 bonus to your Proficiency for damage rolls."
  },
  {
    id: 'splendor_divination',
    name: 'DIVINATION',
    domain: 'Splendor',
    level: 4,
    type: 'Spell',
    recallCost: 1,
    description: 'Once per long rest, spend 3 Hope to reach out to the forces beyond and ask one “yes or no” question about an event, person, place, or situation in the near future. For a moment, the present falls away and you see the answer before you.'
  },
  {
    id: 'splendor_life_ward',
    name: 'LIFE WARD',
    domain: 'Splendor',
    level: 4,
    type: 'Spell',
    recallCost: 1,
    description: "Spend 3 Hope and choose an ally within Close range. They are marked with a glowing sigil of protection. When this ally would make a death move, they clear a Hit Point instead.\nThis effect ends when it saves the target from a death move, you cast Life Ward on another target, or you take a long rest."
  },
  {
    id: 'splendor_shape_material',
    name: 'SHAPE MATERIAL',
    domain: 'Splendor',
    level: 5,
    type: 'Spell',
    recallCost: 1,
    description: "Spend a Hope to shape a section of natural material you’re touching (such as stone, ice, or wood) to suit your purpose. The area of the material can be no larger than you. For example, you can form a rudimentary tool or create a door.\nYou can only affect the material within Close range of where you’re touching it."
  },
  {
    id: 'splendor_smite',
    name: 'SMITE',
    domain: 'Splendor',
    level: 5,
    type: 'Spell',
    recallCost: 2,
    description: 'Once per rest, spend 3 Hope to charge your powerful smite. When you next successfully attack with a weapon, double the result of your damage roll. This attack deals magic damage regardless of the weapon’s damage type.'
  },
  {
    id: 'splendor_restoration',
    name: 'RESTORATION',
    domain: 'Splendor',
    level: 6,
    type: 'Spell',
    recallCost: 2,
    description: "After a long rest, place a number of tokens equal to your Spellcast trait on this card. Touch a creature and spend any number of tokens to clear 2 Hit Points or 2 Stress for each token spent.\nYou can also spend a token from this card when touching a creature to clear the Vulnerable condition or heal a physical or magical ailment (the GM might require additional tokens depending on the strength of the ailment).\nWhen you take a long rest, clear all unspent tokens."
  },
  {
    id: 'splendor_zone_of_protection',
    name: 'ZONE OF PROTECTION',
    domain: 'Splendor',
    level: 6,
    type: 'Spell',
    recallCost: 2,
    description: "Make a Spellcast Roll (16). Once per long rest on a success, choose a point within Far range and create a visible zone of protection there for all allies within Very Close range of that point. When you do, place a d6 on this card with the 1 value facing up. When an ally in this zone takes damage, they reduce it by the die’s value. You then increase the die’s value by one. When the die’s value would exceed 6, this effect ends."
  },
  {
    id: 'splendor_healing_strike',
    name: 'HEALING STRIKE',
    domain: 'Splendor',
    level: 7,
    type: 'Spell',
    recallCost: 1,
    description: 'When you deal damage to an adversary, you can spend 2 Hope to clear a Hit Point on an ally within Close range.'
  },
  {
    id: 'splendor_splendor_touched',
    name: 'SPLENDOR-TOUCHED',
    domain: 'Splendor',
    level: 7,
    type: 'Ability',
    recallCost: 2,
    description: "When 4 or more of the domain cards in your loadout are from the Splendor domain, gain the following benefits:\n• +3 bonus to your Severe damage threshold\n• Once per long rest, when incoming damage would require you to mark a number of Hit Points, you can choose to mark that much Stress or spend that much Hope instead."
  },
  {
    id: 'splendor_shield_aura',
    name: 'SHIELD AURA',
    domain: 'Splendor',
    level: 8,
    type: 'Spell',
    recallCost: 2,
    description: "Mark a Stress to cast a protective aura on a target within Very Close range. When the target marks an Armor Slot, they reduce the severity of the attack by an additional threshold. If this spell causes a creature who would be damaged to instead mark no Hit Points, the effect ends.\nYou can only hold Shield Aura on one creature at a time."
  },
  {
    id: 'splendor_stunning_sunlight',
    name: 'STUNNING SUNLIGHT',
    domain: 'Splendor',
    level: 8,
    type: 'Spell',
    recallCost: 2,
    description: "Make a Spellcast Roll to unleash powerful rays of burning sunlight against all adversaries in front of you within Far range. On a success, spend any number of Hope and force that many targets you succeeded against to make a Reaction Roll (14).\nTargets who succeed take 3d20+3 magic damage. Targets who fail take 4d20+5 magic damage and are temporarily Stunned. While Stunned, they can’t use reactions and can’t take any other actions until they clear this condition."
  },
  {
    id: 'splendor_overwhelming_aura',
    name: 'OVERWHELMING AURA',
    domain: 'Splendor',
    level: 9,
    type: 'Spell',
    recallCost: 2,
    description: "Make a Spellcast Roll (15) to magically empower your aura. On a success, spend 2 Hope to make your Presence equal to your Spellcast trait until your next long rest.\nWhile this spell is active, an adversary must mark a Stress when they target you with an attack."
  },
  {
    id: 'splendor_salvation_beam',
    name: 'SALVATION BEAM',
    domain: 'Splendor',
    level: 9,
    type: 'Spell',
    recallCost: 2,
    description: 'Make a Spellcast Roll (16). On a success, mark any number of Stress to target a line of allies within Far range. You can clear Hit Points on the targets equal to the number of Stress marked, divided among them however you’d like.'
  },
  {
    id: 'splendor_invigoration',
    name: 'INVIGORATION',
    domain: 'Splendor',
    level: 10,
    type: 'Spell',
    recallCost: 3,
    description: 'When you or an ally within Close range has used a feature that has an exhaustion limit (such as once per rest or once per session), you can spend any number of Hope and roll that many d6s. If any roll a 6, the feature can be used again.'
  },
  {
    id: 'splendor_resurrection',
    name: 'RESURRECTION',
    domain: 'Splendor',
    level: 10,
    type: 'Spell',
    recallCost: 2,
    description: "Make a Spellcast Roll (20). On a success, restore one creature who has been dead no longer than 100 years to full strength. Then roll a d6. On a result of 5 or lower, place this card in your vault permanently.\nOn a failure, you can’t cast Resurrection again for a week."
  }
];
