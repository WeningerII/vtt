import { DomainCard } from '../../../types';

export const MIDNIGHT_DOMAIN_CARDS: DomainCard[] = [
  {
    id: 'midnight_pick_and_pull',
    name: 'PICK AND PULL',
    domain: 'Midnight',
    level: 1,
    type: 'Ability',
    recallCost: 0,
    description: 'You have advantage on action rolls to pick nonmagical locks, disarm nonmagical traps, or steal items from a target (either through stealth or by force).'
  },
  {
    id: 'midnight_rain_of_blades',
    name: 'RAIN OF BLADES',
    domain: 'Midnight',
    level: 1,
    type: 'Spell',
    recallCost: 1,
    description: 'Spend a Hope to make a Spellcast Roll and conjure throwing blades that strike out at all targets within Very Close range. Targets you succeed against take d8+2 magic damage using your Proficiency.\nIf a target you hit is Vulnerable, they take an extra 1d8 damage.'
  },
  {
    id: 'midnight_uncanny_disguise',
    name: 'UNCANNY DISGUISE',
    domain: 'Midnight',
    level: 1,
    type: 'Spell',
    recallCost: 0,
    description: "When you have a few minutes to prepare, you can mark a Stress to don the facade of any humanoid you can picture clearly in your mind. While disguised, you have advantage on Presence Rolls to avoid scrutiny.\nPlace a number of tokens equal to your Spellcast trait on this card. When you take an action while disguised, spend a token from this card. After the action that spends the last token is resolved, the disguise drops."
  },
  {
    id: 'midnight_midnight_spirit',
    name: 'MIDNIGHT SPIRIT',
    domain: 'Midnight',
    level: 2,
    type: 'Spell',
    recallCost: 1,
    description: "Spend a Hope to summon a humanoid-sized spirit that can move or carry things for you until your next rest.\nYou can also send it to attack an adversary. When you do, make a Spellcast Roll against a target within Very Far range. On a success, the spirit moves into Melee range with that target. Roll a number of d6s equal to your Spellcast trait and deal that much magic damage to the target. The spirit then dissipates. You can only have one spirit at a time."
  },
  {
    id: 'midnight_shadowbind',
    name: 'SHADOWBIND',
    domain: 'Midnight',
    level: 2,
    type: 'Spell',
    recallCost: 0,
    description: 'Make a Spellcast Roll against all adversaries within Very Close range. Targets you succeed against are temporarily Restrained as their shadow binds them in place.'
  },
  {
    id: 'midnight_chokehold',
    name: 'CHOKEHOLD',
    domain: 'Midnight',
    level: 3,
    type: 'Ability',
    recallCost: 1,
    description: "When you position yourself behind a creature who’s about your size, you can mark a Stress to pull them into a chokehold, making them temporarily Vulnerable.\nWhen a creature attacks a target who is Vulnerable in this way, they deal an extra 2d6 damage."
  },
  {
    id: 'midnight_veil_of_night',
    name: 'VEIL OF NIGHT',
    domain: 'Midnight',
    level: 3,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll (13). On a success, you can create a temporary curtain of darkness between two points within Far range. Only you can see through this darkness. You’re considered Hidden to adversaries on the other side of the veil, and you have advantage on attacks you make through the darkness. The veil remains until you cast another spell."
  },
  {
    id: 'midnight_stealth_expertise',
    name: 'STEALTH EXPERTISE',
    domain: 'Midnight',
    level: 4,
    type: 'Ability',
    recallCost: 0,
    description: 'When you roll with Fear while attempting to move unnoticed through a dangerous area, you can mark a Stress to roll with Hope instead.\nIf an ally within Close range is also attempting to move unnoticed and rolls with Fear, you can mark a Stress to change their result to a roll with Hope.'
  },
  {
    id: 'midnight_glyph_of_nightfall',
    name: 'GLYPH OF NIGHTFALL',
    domain: 'Midnight',
    level: 4,
    type: 'Spell',
    recallCost: 1,
    description: 'Make a Spellcast Roll against a target within Very Close range. On a success, spend a Hope to conjure a dark glyph upon their body that exposes their weak points, temporarily reducing the target’s Difficulty by a value equal to your Knowledge (minimum 1).'
  },
  {
    id: 'midnight_hush',
    name: 'HUSH',
    domain: 'Midnight',
    level: 5,
    type: 'Spell',
    recallCost: 1,
    description: "Make a Spellcast Roll against a target within Close range. On a success, spend a Hope to conjure suppressive magic around the target that encompasses everything within Very Close range of them and follows them as they move.\nThe target and anything within the area is Silenced until the GM spends a Fear on their turn to clear this condition, you cast Hush again, or you take Major damage. While Silenced, they can’t make noise and can’t cast spells."
  },
  {
    id: 'midnight_phantom_retreat',
    name: 'PHANTOM RETREAT',
    domain: 'Midnight',
    level: 5,
    type: 'Spell',
    recallCost: 2,
    description: "Spend a Hope to activate Phantom Retreat where you’re currently standing. Spend another Hope at any time before your next rest to disappear from where you are and reappear where you were standing when you activated Phantom Retreat. This spell ends after you reappear."
  },
  {
    id: 'midnight_dark_whispers',
    name: 'DARK WHISPERS',
    domain: 'Midnight',
    level: 6,
    type: 'Spell',
    recallCost: 0,
    description: "You can speak into the mind of any person with whom you’ve made physical contact. Once you’ve opened a channel with them, they can speak back into your mind. Additionally, you can mark a Stress to make a Spellcast Roll against them. On a success, you can ask the GM one of the following questions and receive an answer:\n• Where are they?\n• What are they doing?\n• What are they afraid of?\n• What do they cherish most in the world?"
  },
  {
    id: 'midnight_mass_disguise',
    name: 'MASS DISGUISE',
    domain: 'Midnight',
    level: 6,
    type: 'Spell',
    recallCost: 0,
    description: "When you have a few minutes of silence to focus, you can mark a Stress to change the appearance of all willing creatures within Close range. Their new forms must share a general body structure and size, and can be somebody or something you’ve seen before or entirely fabricated. A disguised creature has advantage on Presence Rolls to avoid scrutiny.\nActivate a Countdown (8). It ticks down as a consequence the GM chooses. When it triggers, the disguise drops."
  },
  {
    id: 'midnight_midnight_touched',
    name: 'MIDNIGHT-TOUCHED',
    domain: 'Midnight',
    level: 7,
    type: 'Ability',
    recallCost: 2,
    description: "When 4 or more of the domain cards in your loadout are from the Midnight domain, gain the following benefits:\n• Once per rest, when you have 0 Hope and the GM would gain a Fear, you can gain a Hope instead.\n• When you make a successful attack, you can mark a Stress to add the result of your Fear Die to your damage roll."
  },
  {
    id: 'midnight_vanishing_dodge',
    name: 'VANISHING DODGE',
    domain: 'Midnight',
    level: 7,
    type: 'Spell',
    recallCost: 1,
    description: 'When an attack made against you that would deal physical damage fails, you can spend a Hope to envelop yourself in shadow, becoming Hidden and teleporting to a point within Close range of the attacker. You remain Hidden until the next time you make an action roll.'
  },
  {
    id: 'midnight_shadowhunter',
    name: 'SHADOWHUNTER',
    domain: 'Midnight',
    level: 8,
    type: 'Ability',
    recallCost: 2,
    description: 'Your prowess is enhanced under the cover of shadow. While you’re shrouded in low light or darkness, you gain a +1 bonus to your Evasion and make attack rolls with advantage.'
  },
  {
    id: 'midnight_spellcharge',
    name: 'SPELLCHARGE',
    domain: 'Midnight',
    level: 8,
    type: 'Spell',
    recallCost: 1,
    description: 'When you take magic damage, place tokens equal to the number of Hit Points you marked on this card. You can store a number of tokens equal to your Spellcast trait.\nWhen you make a successful attack against a target, you can spend any number of tokens to add a d6 for each token spent to your damage roll.'
  },
  {
    id: 'midnight_night_terror',
    name: 'NIGHT TERROR',
    domain: 'Midnight',
    level: 9,
    type: 'Spell',
    recallCost: 2,
    description: "Once per long rest, choose any targets within Very Close range to perceive you as a nightmarish horror. The targets must succeed on a Reaction Roll (16) or become temporarily Horrified. While Horrified, they’re Vulnerable. Steal a number of Fear from the GM equal to the number of targets that are Horrified (up to the number of Fear in the GM’s pool). Roll a number of d6s equal to the number of stolen Fear and deal the total damage to each Horrified target. Discard the stolen Fear."
  },
  {
    id: 'midnight_twilight_toll',
    name: 'TWILIGHT TOLL',
    domain: 'Midnight',
    level: 9,
    type: 'Ability',
    recallCost: 1,
    description: "Choose a target within Far range. When you succeed on an action roll against them that doesn’t result in making a damage roll, place a token on this card. When you deal damage to this target, spend any number of tokens to add a d12 for each token spent to your damage roll. You can only hold Twilight Toll on one creature at a time.\nWhen you choose a new target or take a rest, clear all unspent tokens."
  },
  {
    id: 'midnight_eclipse',
    name: 'ECLIPSE',
    domain: 'Midnight',
    level: 10,
    type: 'Spell',
    recallCost: 2,
    description: "Make a Spellcast Roll (16). Once per long rest on a success, plunge the entire area within Far range into complete darkness only you and your allies can see through. Attack rolls have disadvantage when targeting you or an ally within this shadow.\nAdditionally, when you or an ally succeeds with Hope against an adversary within this shadow, the target must mark a Stress.\nThis spell lasts until the GM spends a Fear on their turn to clear this effect or you take Severe damage."
  },
  {
    id: 'midnight_specter_of_the_dark',
    name: 'SPECTER OF THE DARK',
    domain: 'Midnight',
    level: 10,
    type: 'Spell',
    recallCost: 1,
    description: "Mark a Stress to become Spectral until you make an action roll targeting another creature. While Spectral, you’re immune to physical damage and can float and pass through solid objects. Other creatures can still see you while you’re in this form."
  }
];
