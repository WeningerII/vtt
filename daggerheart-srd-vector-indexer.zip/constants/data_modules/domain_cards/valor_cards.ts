import { DomainCard } from '../../../types';

export const VALOR_DOMAIN_CARDS: DomainCard[] = [
  {
    id: 'valor_bare_bones',
    name: 'BARE BONES',
    domain: 'Valor',
    level: 1,
    type: 'Ability',
    recallCost: 0,
    description: "When you choose not to equip armor, you have a base Armor Score of 3 + your Strength and use the following as your base damage thresholds:\n• Tier 1: 9/19\n• Tier 2: 11/24\n• Tier 3: 13/31\n• Tier 4: 15/38"
  },
  {
    id: 'valor_forceful_push',
    name: 'FORCEFUL PUSH',
    domain: 'Valor',
    level: 1,
    type: 'Ability',
    recallCost: 0,
    description: 'Make an attack with your primary weapon against a target within Melee range. On a success, you deal damage and knock them back to Close range. On a success with Hope, add a d6 to your damage roll.\nAdditionally, you can spend a Hope to make them temporarily Vulnerable.'
  },
  {
    id: 'valor_i_am_your_shield',
    name: 'I AM YOUR SHIELD',
    domain: 'Valor',
    level: 1,
    type: 'Ability',
    recallCost: 1,
    description: 'When an ally within Very Close range would take damage, you can mark a Stress to stand in the way and make yourself the target of the attack instead. When you take damage from this attack, you can mark any number of Armor Slots.'
  },
  {
    id: 'valor_body_basher',
    name: 'BODY BASHER',
    domain: 'Valor',
    level: 2,
    type: 'Ability',
    recallCost: 1,
    description: 'You use the full force of your body in a fight. On a successful attack using a weapon with a Melee range, gain a bonus to your damage roll equal to your Strength.'
  },
  {
    id: 'valor_bold_presence',
    name: 'BOLD PRESENCE',
    domain: 'Valor',
    level: 2,
    type: 'Ability',
    recallCost: 0,
    description: 'When you make a Presence Roll, you can spend a Hope to add your Strength to the roll.\nAdditionally, once per rest when you would gain a condition, you can describe how your bold presence aids you in the situation and avoid gaining the condition.'
  },
  {
    id: 'valor_critical_inspiration',
    name: 'CRITICAL INSPIRATION',
    domain: 'Valor',
    level: 3,
    type: 'Ability',
    recallCost: 1,
    description: 'Once per rest, when you critically succeed on an attack, all allies within Very Close range can clear a Stress or gain a Hope.'
  },
  {
    id: 'valor_lean_on_me',
    name: 'LEAN ON ME',
    domain: 'Valor',
    level: 3,
    type: 'Ability',
    recallCost: 1,
    description: 'Once per long rest, when you console or inspire an ally who failed an action roll, you can both clear 2 Stress.'
  },
  {
    id: 'valor_goad_them_on',
    name: 'GOAD THEM ON',
    domain: 'Valor',
    level: 4,
    type: 'Ability',
    recallCost: 1,
    description: 'Describe how you taunt a target within Close range, then make a Presence Roll against them. On a success, the target must mark a Stress, and the next time the GM spotlights them, they must target you with an attack, which they make with disadvantage.'
  },
  {
    id: 'valor_support_tank',
    name: 'SUPPORT TANK',
    domain: 'Valor',
    level: 4,
    type: 'Ability',
    recallCost: 2,
    description: 'When an ally within Close range fails a roll, you can spend 2 Hope to allow them to reroll either their Hope or Fear Die.'
  },
  {
    id: 'valor_armorer',
    name: 'ARMORER',
    domain: 'Valor',
    level: 5,
    type: 'Ability',
    recallCost: 1,
    description: 'While you’re wearing armor, gain a +1 bonus to your Armor Score.\nDuring a rest, when you choose to repair your armor as a downtime move, your allies also clear an Armor Slot.'
  },
  {
    id: 'valor_rousing_strike',
    name: 'ROUSING STRIKE',
    domain: 'Valor',
    level: 5,
    type: 'Ability',
    recallCost: 1,
    description: 'Once per rest, when you critically succeed on an attack, you and all allies who can see or hear you can clear a Hit Point or 1d4 Stress.'
  },
  {
    id: 'valor_inevitable',
    name: 'INEVITABLE',
    domain: 'Valor',
    level: 6,
    type: 'Ability',
    recallCost: 1,
    description: 'When you fail an action roll, your next action roll has advantage.'
  },
  {
    id: 'valor_rise_up',
    name: 'RISE UP',
    domain: 'Valor',
    level: 6,
    type: 'Ability',
    recallCost: 2,
    description: 'Gain a bonus to your Severe threshold equal to your Proficiency.\nWhen you mark 1 or more Hit Points from an attack, clear a Stress.'
  },
  {
    id: 'valor_shrug_it_off',
    name: 'SHRUG IT OFF',
    domain: 'Valor',
    level: 7,
    type: 'Ability',
    recallCost: 1,
    description: 'When you would take damage, you can mark a Stress to reduce the severity of the damage by one threshold. When you do, roll a d6. On a result of 3 or lower, place this card in your vault.'
  },
  {
    id: 'valor_valor_touched',
    name: 'VALOR-TOUCHED',
    domain: 'Valor',
    level: 7,
    type: 'Ability',
    recallCost: 1,
    description: "When 4 or more of the domain cards in your loadout are from the Valor domain, gain the following benefits:\n• +1 bonus to your Armor Score\n• When you mark 1 or more Hit Points without marking an Armor Slot, clear an Armor Slot."
  },
  {
    id: 'valor_full_surge',
    name: 'FULL SURGE',
    domain: 'Valor',
    level: 8,
    type: 'Ability',
    recallCost: 1,
    description: 'Once per long rest, mark 3 Stress to push your body to its limits. Gain a +2 bonus to all of your character traits until your next rest.'
  },
  {
    id: 'valor_ground_pound',
    name: 'GROUND POUND',
    domain: 'Valor',
    level: 8,
    type: 'Ability',
    recallCost: 2,
    description: 'Spend 2 Hope to strike the ground where you stand and make a Strength Roll against all targets within Very Close range. Targets you succeed against are thrown back to Far range and must make a Reaction Roll (17). Targets who fail take 4d10+8 damage. Targets who succeed take half damage.'
  },
  {
    id: 'valor_hold_the_line',
    name: 'HOLD THE LINE',
    domain: 'Valor',
    level: 9,
    type: 'Ability',
    recallCost: 1,
    description: "Describe the defensive stance you take and spend a Hope. If an adversary moves within Very Close range, they’re pulled into Melee range and Restrained.\nThis condition lasts until you move or fail a roll with Fear, or the GM spends 2 Fear on their turn to clear it."
  },
  {
    id: 'valor_lead_by_example',
    name: 'LEAD BY EXAMPLE',
    domain: 'Valor',
    level: 9,
    type: 'Ability',
    recallCost: 3,
    description: 'When you deal damage to an adversary, you can mark a Stress and describe how you encourage your allies. The next PC to make an attack against that adversary can clear a Stress or gain a Hope.'
  },
  {
    id: 'valor_unbreakable',
    name: 'UNBREAKABLE',
    domain: 'Valor',
    level: 10,
    type: 'Ability',
    recallCost: 4,
    description: 'When you mark your last Hit Point, instead of making a death move, you can roll a d6 and clear a number of Hit Points equal to the result. Then place this card in your vault.'
  },
  {
    id: 'valor_unyielding_armor',
    name: 'UNYIELDING ARMOR',
    domain: 'Valor',
    level: 10,
    type: 'Ability',
    recallCost: 1,
    description: 'When you would mark an Armor Slot, roll a number of d6s equal to your Proficiency. If any roll a 6, reduce the severity by one threshold without marking an Armor Slot.'
  }
];
