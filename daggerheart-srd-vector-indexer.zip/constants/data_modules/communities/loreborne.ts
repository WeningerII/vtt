import { Community } from '../../../types';

export const LOREBORNE_COMMUNITY: Community = {
  id: 'loreborne',
  name: 'Loreborne',
  feature: { 
    name: "Well-Read", 
    description: "You have advantage on rolls that involve the history, culture, or politics of a prominent person or place." 
  }
  // Adjectives: direct, eloquent, inquisitive, patient, rhapsodic, and witty.
};
