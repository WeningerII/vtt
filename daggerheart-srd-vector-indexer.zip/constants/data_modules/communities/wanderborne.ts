import { Community } from '../../../types';

export const WANDERBORNE_COMMUNITY: Community = {
  id: 'wanderborne',
  name: 'Wanderborne',
  feature: { 
    name: "Nomadic Pack", 
    description: "Add a Nomadic Pack to your inventory. Once per session, you can spend a Hope to reach into this pack and pull out a mundane item that’s useful to your situation. Work with the GM to figure out what item you take out." 
  }
  // Adjectives: inscrutable, magnanimous, mirthful, reliable, savvy, and unorthodox.
};
