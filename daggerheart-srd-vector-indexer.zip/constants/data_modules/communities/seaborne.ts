import { Community } from '../../../types';

export const SEABORNE_COMMUNITY: Community = {
  id: 'seaborne',
  name: 'Seaborne',
  feature: { 
    name: "Know the Tide", 
    description: "You can sense the ebb and flow of life. When you roll with Fear, place a token on your community card. You can hold a number of tokens equal to your level. Before you make an action roll, you can spend any number of these tokens to gain a +1 bonus to the roll for each token spent. At the end of each session, clear all unspent tokens." 
  }
  // Adjectives: candid, cooperative, exuberant, fierce, resolute, and weathered.
};
