import { Community } from '../../../types';

export const SLYBORNE_COMMUNITY: Community = {
  id: 'slyborne',
  name: 'Slyborne',
  feature: { 
    name: "Scoundrel", 
    description: "You have advantage on rolls to negotiate with criminals, detect lies, or find a safe place to hide." 
  }
  // Adjectives: calculating, clever, formidable, perceptive, shrewd, and tenacious.
};
