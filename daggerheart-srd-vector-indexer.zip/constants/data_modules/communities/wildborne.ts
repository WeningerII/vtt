import { Community } from '../../../types';

export const WILDBORNE_COMMUNITY: Community = {
  id: 'wildborne',
  name: 'Wildborne',
  feature: { 
    name: "Lightfoot", 
    description: "Your movement is naturally silent. You have advantage on rolls to move without being heard." 
  }
  // Adjectives: hardy, loyal, nurturing, reclusive, sagacious, and vibrant.
};
