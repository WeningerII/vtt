import { Community } from '../../../types';
import { HIGHBORNE_COMMUNITY } from './highborne';
import { LOREBORNE_COMMUNITY } from './loreborne';
import { ORDERBORNE_COMMUNITY } from './orderborne';
import { RIDGEBORNE_COMMUNITY } from './ridgeborne';
import { SEABORNE_COMMUNITY } from './seaborne';
import { SLYBORNE_COMMUNITY } from './slyborne';
import { UNDERBORNE_COMMUNITY } from './underborne';
import { WANDERBORNE_COMMUNITY } from './wanderborne';
import { WILDBORNE_COMMUNITY } from './wildborne';

export const COMMUNITIES: Community[] = [
  HIGHBORNE_COMMUNITY,
  LOREBORNE_COMMUNITY,
  ORDERBORNE_COMMUNITY,
  RIDGEBORNE_COMMUNITY,
  SEABORNE_COMMUNITY,
  SLYBORNE_COMMUNITY,
  UNDERBORNE_COMMUNITY,
  WANDERBORNE_COMMUNITY,
  WILDBORNE_COMMUNITY
];
