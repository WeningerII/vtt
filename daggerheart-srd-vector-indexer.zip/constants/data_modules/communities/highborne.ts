import { Community } from '../../../types';

export const HIGHBORNE_COMMUNITY: Community = {
  id: 'highborne',
  name: 'Highborne',
  feature: { 
    name: "Privilege", 
    description: "You have advantage on rolls to consort with nobles, negotiate prices, or leverage your reputation to get what you want." 
  }
  // Adjectives: amiable, candid, conniving, enterprising, ostentatious, and unflappable.
};
