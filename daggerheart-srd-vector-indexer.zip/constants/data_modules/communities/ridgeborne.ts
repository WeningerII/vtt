import { Community } from '../../../types';

export const RIDGEBORNE_COMMUNITY: Community = {
  id: 'ridgeborne',
  name: 'Ridgeborne',
  feature: { 
    name: "Steady", 
    description: "You have advantage on rolls to traverse dangerous cliffs and ledges, navigate harsh environments, and use your survival knowledge." 
  }
  // Adjectives: bold, hardy, indomitable, loyal, reserved, and stubborn.
};
