import { Community } from '../../../types';

export const ORDERBORNE_COMMUNITY: Community = {
  id: 'orderborne',
  name: 'Orderborne',
  feature: { 
    name: "Dedicated", 
    description: "Record three sayings or values your upbringing instilled in you. Once per rest, when you describe how you’re embodying one of these principles through your current action, you can roll a d20 as your Hope Die." 
  }
  // Adjectives: ambitious, benevolent, pensive, prudent, sardonic, and stoic.
};
