import { Community } from '../../../types';

export const UNDERBORNE_COMMUNITY: Community = {
  id: 'underborne',
  name: 'Underborne',
  feature: { 
    name: "Low-Light Living", 
    description: "When you’re in an area with low light or heavy shadow, you have advantage on rolls to hide, investigate, or perceive details within that area." 
  }
  // Adjectives: composed, elusive, indomitable, innovative, resourceful, and unpretentious.
};
