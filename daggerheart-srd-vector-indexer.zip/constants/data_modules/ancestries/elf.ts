import { Ancestry } from '../../../types';

export const ELF_ANCESTRY: Ancestry = {
  id: 'elf',
  name: 'Elf',
  features: [
    { name: "Quick Reactions", description: "Mark a Stress to gain advantage on a reaction roll." },
    { name: "Celestial Trance", description: "During a rest, you can drop into a trance to choose an additional downtime move." }
  ]
};
