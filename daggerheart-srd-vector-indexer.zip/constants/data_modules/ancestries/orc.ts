import { Ancestry } from '../../../types';

export const ORC_ANCESTRY: Ancestry = {
  id: 'orc',
  name: 'Orc',
  features: [
    { name: "Sturdy", description: "When you have 1 Hit Point remaining, attacks against you have disadvantage." },
    { name: "Tusks", description: "When you succeed on an attack against a target within Melee range, you can spend a Hope to gore the target with your tusks, dealing an extra 1d6 damage." }
  ]
};
