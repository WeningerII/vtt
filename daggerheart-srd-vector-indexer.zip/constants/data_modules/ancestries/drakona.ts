import { Ancestry } from '../../../types';

export const DRAKONA_ANCESTRY: Ancestry = {
  id: 'drakona',
  name: 'Drakona',
  features: [
    { name: "Scales", description: "Your scales act as natural protection. When you would take Severe damage, you can mark a Stress to mark 1 fewer Hit Points." },
    { name: "Elemental Breath", description: "Choose an element for your breath (such as electricity, fire, or ice). You can use this breath against a target or group of targets within Very Close range, treating it as an Instinct weapon that deals d8 magic damage using your Proficiency." }
  ]
};
