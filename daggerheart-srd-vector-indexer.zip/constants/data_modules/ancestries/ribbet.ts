import { Ancestry } from '../../../types';

export const RIBBET_ANCESTRY: Ancestry = {
  id: 'ribbet',
  name: 'Ribbet',
  features: [
    { name: "Amphibious", description: "You can breathe and move naturally underwater." },
    { name: "Long Tongue", description: "You can use your long tongue to grab onto things within Close range. Mark a Stress to use your tongue as a Finesse Close weapon that deals d12 physical damage using your Proficiency." }
  ]
};
