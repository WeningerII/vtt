import { Ancestry } from '../../../types';

export const GIANT_ANCESTRY: Ancestry = {
  id: 'giant',
  name: 'Giant',
  features: [
    { name: "Endurance", description: "Gain an additional Hit Point slot at character creation." },
    { name: "Reach", description: "Treat any weapon, ability, spell, or other feature that has a Melee range as though it has a Very Close range instead." }
  ]
};
