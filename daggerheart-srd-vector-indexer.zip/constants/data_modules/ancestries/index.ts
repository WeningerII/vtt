import { Ancestry } from '../../../types';
import { CLANK_ANCESTRY } from './clank';
import { DRAKONA_ANCESTRY } from './drakona';
import { DWARF_ANCESTRY } from './dwarf';
import { ELF_ANCESTRY } from './elf';
import { FAERIE_ANCESTRY } from './faerie';
import { FAUN_ANCESTRY } from './faun';
import { FIRBOLG_ANCESTRY } from './firbolg';
import { FUNGRIL_ANCESTRY } from './fungril';
import { GALAPA_ANCESTRY } from './galapa';
import { GIANT_ANCESTRY } from './giant';
import { GOBLIN_ANCESTRY } from './goblin';
import { HALFLING_ANCESTRY } from './halfling';
import { HUMAN_ANCESTRY } from './human';
import { INFERNIS_ANCESTRY } from './infernis';
import { KATARI_ANCESTRY } from './katari';
import { ORC_ANCESTRY } from './orc';
import { RIBBET_ANCESTRY } from './ribbet';
import { SIMIAH_ANCESTRY } from './simiah';

export const ANCESTRIES: Ancestry[] = [
  CLANK_ANCESTRY,
  DRAKONA_ANCESTRY,
  DWARF_ANCESTRY,
  ELF_ANCESTRY,
  FAERIE_ANCESTRY,
  FAUN_ANCESTRY,
  FIRBOLG_ANCESTRY,
  FUNGRIL_ANCESTRY,
  GALAPA_ANCESTRY,
  GIANT_ANCESTRY,
  GOBLIN_ANCESTRY,
  HALFLING_ANCESTRY,
  HUMAN_ANCESTRY,
  INFERNIS_ANCESTRY,
  KATARI_ANCESTRY,
  ORC_ANCESTRY,
  RIBBET_ANCESTRY,
  SIMIAH_ANCESTRY
];
