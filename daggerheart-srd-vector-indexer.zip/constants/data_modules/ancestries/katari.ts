import { Ancestry } from '../../../types';

export const KATARI_ANCESTRY: Ancestry = {
  id: 'katari',
  name: 'Katari',
  features: [
    { name: "Feline Instincts", description: "When you make an Agility Roll, you can spend 2 Hope to reroll your Hope Die." },
    { name: "Retracting Claws", description: "Make an Agility Roll to scratch a target within Melee range. On a success, they become temporarily Vulnerable." }
  ]
};
