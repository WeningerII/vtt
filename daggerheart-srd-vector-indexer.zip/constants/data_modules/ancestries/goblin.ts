import { Ancestry } from '../../../types';

export const GOBLIN_ANCESTRY: Ancestry = {
  id: 'goblin',
  name: 'Goblin',
  features: [
    { name: "Surefooted", description: "You ignore disadvantage on Agility Rolls." },
    { name: "Danger Sense", description: "Once per rest, mark a Stress to force an adversary to reroll an attack against you or an ally within Very Close range." }
  ]
};
