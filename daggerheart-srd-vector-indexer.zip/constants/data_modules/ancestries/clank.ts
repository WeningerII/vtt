import { Ancestry } from '../../../types';

export const CLANK_ANCESTRY: Ancestry = {
  id: 'clank',
  name: 'Clank',
  features: [
    { name: "Purposeful Design", description: "Decide who made you and for what purpose. At character creation, choose one of your Experiences that best aligns with this purpose and gain a permanent +1 bonus to it." },
    { name: "Efficient", description: "When you take a short rest, you can choose a long rest move instead of a short rest move." }
  ]
};
