import { Ancestry } from '../../../types';

export const HALFLING_ANCESTRY: Ancestry = {
  id: 'halfling',
  name: 'Halfling',
  features: [
    { name: "Luckbringer", description: "At the start of each session, everyone in your party gains a Hope." },
    { name: "Internal Compass", description: "When you roll a 1 on your Hope Die, you can reroll it." }
  ]
};
