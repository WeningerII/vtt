import { Ancestry } from '../../../types';

export const DWARF_ANCESTRY: Ancestry = {
  id: 'dwarf',
  name: 'Dwarf',
  features: [
    { name: "Thick Skin", description: "When you take Minor damage, you can mark 2 Stress instead of marking a Hit Point." },
    { name: "Increased Fortitude", description: "Spend 3 Hope to halve incoming physical damage." }
  ]
};
