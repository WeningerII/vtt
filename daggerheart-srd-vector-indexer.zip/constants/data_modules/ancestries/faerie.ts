import { Ancestry } from '../../../types';

export const FAERIE_ANCESTRY: Ancestry = {
  id: 'faerie',
  name: 'Faerie',
  features: [
    { name: "Luckbender", description: "Once per session, after you or a willing ally within Close range makes an action roll, you can spend 3 Hope to reroll the Duality Dice." },
    { name: "Wings", description: "You can fly. While flying, you can mark a Stress after an adversary makes an attack against you to gain a +2 bonus to your Evasion against that attack." }
  ]
};
