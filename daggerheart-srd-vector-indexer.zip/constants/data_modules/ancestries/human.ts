import { Ancestry } from '../../../types';

export const HUMAN_ANCESTRY: Ancestry = {
  id: 'human',
  name: 'Human',
  features: [
    { name: "High Stamina", description: "Gain an additional Stress slot at character creation." },
    { name: "Adaptability", description: "When you fail a roll that utilized one of your Experiences, you can mark a Stress to reroll." }
  ]
};
