import { Ancestry } from '../../../types';

export const INFERNIS_ANCESTRY: Ancestry = {
  id: 'infernis',
  name: 'Infernis',
  features: [
    { name: "Fearless", description: "When you roll with Fear, you can mark 2 Stress to change it into a roll with Hope instead." },
    { name: "Dread Visage", description: "You have advantage on rolls to intimidate hostile creatures." }
  ]
};
