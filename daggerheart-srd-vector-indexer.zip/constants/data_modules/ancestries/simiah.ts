import { Ancestry } from '../../../types';

export const SIMIAH_ANCESTRY: Ancestry = {
  id: 'simiah',
  name: 'Simiah',
  features: [
    { name: "Natural Climber", description: "You have advantage on Agility Rolls that involve balancing and climbing." },
    { name: "Nimble", description: "Gain a permanent +1 bonus to your Evasion at character creation." }
  ]
};
