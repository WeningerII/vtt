import { Ancestry } from '../../../types';

export const FAUN_ANCESTRY: Ancestry = {
  id: 'faun',
  name: 'Faun',
  features: [
    { name: "Caprine Leap", description: "You can leap anywhere within Close range as though you were using normal movement, allowing you to vault obstacles, jump across gaps, or scale barriers with ease." },
    { name: "Kick", description: "When you succeed on an attack against a target within Melee range, you can mark a Stress to kick yourself off them, dealing an extra 2d6 damage and knocking back either yourself or the target to Very Close range." }
  ]
};
