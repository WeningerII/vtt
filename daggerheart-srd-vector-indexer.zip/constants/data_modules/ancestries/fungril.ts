import { Ancestry } from '../../../types';

export const FUNGRIL_ANCESTRY: Ancestry = {
  id: 'fungril',
  name: 'Fungril',
  features: [
    { name: "Fungril Network", description: "Make an Instinct Roll (12) to use your mycelial array to speak with others of your ancestry. On a success, you can communicate across any distance." },
    { name: "Death Connection", description: "While touching a corpse that died recently, you can mark a Stress to extract one memory from the corpse related to a specific emotion or sensation of your choice." }
  ]
};
