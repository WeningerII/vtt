import { Ancestry } from '../../../types';

export const FIRBOLG_ANCESTRY: Ancestry = {
  id: 'firbolg',
  name: 'Firbolg',
  features: [
    { name: "Charge", description: "When you succeed on an Agility Roll to move from Far or Very Far range into Melee range with one or more targets, you can mark a Stress to deal 1d12 physical damage to all targets within Melee range." },
    { name: "Unshakable", description: "When you would mark a Stress, roll a d6. On a result of 6, don’t mark it." }
  ]
};
