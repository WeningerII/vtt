
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { SRD_TEXT_TO_USE, DEFAULT_CHARACTER_DATA, MOCK_SRD_DATA } from './src/constants'; 
import { 
  RawChunk, ProcessedChunk, SearchResultItem, LoadingState, CharacterData, SRDData, 
  AppView, ConditionData, GameTermData, InteractiveTermConfig, InteractiveTermActionDetails,
  ClassData, Ancestry, Community, DomainCard, Weapon, Armor, LootItemData, ConsumableItemData, BeastformData, Trait 
} from './types';
import { generateSummaryAndKeywords, findRelevantChunkIndices, processPdfAndExtractStructuredData } from './services/geminiService';
import { chunkSRDDocument } from './services/srdChunker';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorDisplay from './components/ErrorDisplay';
import ChunkCard from './components/ChunkCard';
import SearchBar from './components/SearchBar';
import CharacterCreator from './components/CharacterCreator';
import GameRules from './components/GameRules';
import GameMechanicsDetails from './components/GameMechanicsDetails';
import StartingCampaignGuide from './components/StartingCampaignGuide'; 
import GMToolsDashboard from './components/GMToolsDashboard'; 
import DomainCardReference from './components/DomainCardReference'; 
import EquipmentReference from './components/EquipmentReference';
import VirtualTabletop from './components/VirtualTabletop'; // Added VTT import
import { Button } from './components/common/Button';
import { Card } from './components/common/Card'; 
import LiveStatsPanel from './components/common/LiveStatsPanel'; 
import { formatDamageRoll } from './services/characterStatService'; 

interface CreatorParams {
  classId?: string;
  ancestryId?: string;
  communityId?: string;
}

const App: React.FC = () => {
  const [srdText, setSrdText] = useState<string>('');
  const [rawChunks, setRawChunks] = useState<RawChunk[]>([]);
  const [processedChunks, setProcessedChunks] = useState<ProcessedChunk[]>([]);
  const [searchResults, setSearchResults] = useState<SearchResultItem[]>([]);
  const [loadingState, setLoadingState] = useState<LoadingState>(LoadingState.IDLE);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const idCounterRef = useRef<number>(0);
  const [srdPdfFile, setSrdPdfFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [progressMessage, setProgressMessage] = useState<string | null>(null);

  const [characterData, setCharacterData] = useState<CharacterData>(DEFAULT_CHARACTER_DATA);
  const [srdCreatorData] = useState<SRDData>(MOCK_SRD_DATA);
  const [currentView, setCurrentView] = useState<AppView>('dashboard');
  const [initialCreatorParams, setInitialCreatorParams] = useState<CreatorParams | null>(null);

  const [srdChunkModalContent, setSrdChunkModalContent] = useState<ProcessedChunk | null>(null);
  const [activeModalContent, setActiveModalContent] = useState<InteractiveTermActionDetails['modalData'] | null>(null);


  useEffect(() => {
    if (currentView === 'indexer' && !srdPdfFile && srdText === '') {
      setSrdText(SRD_TEXT_TO_USE);
    }
  }, [currentView, srdPdfFile, srdText]);

  useEffect(() => {
    if (currentView === 'indexer' && srdText === SRD_TEXT_TO_USE && !srdPdfFile && loadingState !== LoadingState.CHUNKING && rawChunks.length === 0) {
      setLoadingState(LoadingState.CHUNKING);
      setError(null);
      setProgressMessage(null);
      const chunks = chunkSRDDocument(srdText, idCounterRef);
      setRawChunks(chunks.filter(c => c.content.length > 0));
      setLoadingState(LoadingState.IDLE);
      setProcessedChunks([]); 
      setSearchResults([]);
    }
  }, [srdText, srdPdfFile, currentView, loadingState, rawChunks.length]);


  const handlePdfFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === "application/pdf") {
      setSrdPdfFile(file);
      setSrdText(''); 
      setRawChunks([]); 
      setProcessedChunks([]);
      setSearchResults([]);
      setSearchTerm('');
      setError(null);
      setProgressMessage(null);
      setLoadingState(LoadingState.IDLE);
    } else if (file) {
      setError("Invalid file type. Please upload a PDF.");
      setSrdPdfFile(null);
      setProgressMessage(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleClearPdfFile = () => {
    setSrdPdfFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = ""; 
    }
    setSrdText(SRD_TEXT_TO_USE); 
    setRawChunks([]); 
    setProcessedChunks([]);
    setSearchResults([]);
    setError(null);
    setSearchTerm('');
    setProgressMessage(null);
    setLoadingState(LoadingState.IDLE); 
  };

  const updateProgressCallback = (message: string) => {
    setProgressMessage(message);
  };

  const handleProcessDocument = async () => {
    setError(null);
    setProcessedChunks([]);
    setSearchResults([]);
    setProgressMessage(null);

    if (srdPdfFile) {
      setLoadingState(LoadingState.PROCESSING_PDF_STRUCTURE); 
      updateProgressCallback("Starting PDF processing...");
      const chunksFromPdf = await processPdfAndExtractStructuredData(srdPdfFile, (message) => {
          if (message.startsWith("Identifying document structure...") || message.startsWith("Preparing PDF data...")) {
              setLoadingState(LoadingState.PROCESSING_PDF_STRUCTURE);
          } else if (message.startsWith("Processing section") || message.startsWith("Found")) {
              setLoadingState(LoadingState.PROCESSING_PDF_SECTIONS);
          }
          setProgressMessage(message);
      });

      if (chunksFromPdf && chunksFromPdf.length > 0) {
        setProcessedChunks(chunksFromPdf);
        setProgressMessage("PDF processed successfully. Index built.");
      } else if (chunksFromPdf && chunksFromPdf.length === 0) {
        setError("Gemini processed the PDF but found no structured content or sections. The PDF might be empty or in an unsupported format for sectioning.");
        setProgressMessage("PDF processing complete, but no sections were extracted.");
      } else {
        if (!progressMessage?.toLowerCase().includes("error")) { 
            setError("Failed to process PDF with Gemini. Check console for details.");
            setProgressMessage("PDF processing failed.");
        }
      }
      setLoadingState(LoadingState.IDLE);
    } else if (rawChunks.length > 0) {
      setLoadingState(LoadingState.PROCESSING_TEXT_CHUNKS);
      setProgressMessage("Processing text chunks (0%)...");
      const newProcessedChunks: ProcessedChunk[] = [];
      for (let i = 0; i < rawChunks.length; i++) {
        const chunk = rawChunks[i];
        try {
          const embeddingData = await generateSummaryAndKeywords(chunk.content);
          if (embeddingData) {
            newProcessedChunks.push({ ...chunk, ...embeddingData });
          } else {
            newProcessedChunks.push({ ...chunk, summary: "Failed to process", keywords: ["error", "processing_failed"] });
          }
        } catch (err: any) {
          console.error(`Error processing chunk ${chunk.id} (${chunk.title}):`, err);
          newProcessedChunks.push({ ...chunk, summary: `Error: ${err.message || 'Unknown error'}`, keywords: ["error", "exception"] });
        }
        setProcessedChunks([...newProcessedChunks]); 
        setProgressMessage(`Processing text chunks (${Math.round(((i + 1) / rawChunks.length) * 100)}%)...`);
      }
      setProgressMessage("Text chunk processing complete. Index built.");
      setLoadingState(LoadingState.IDLE);
    } else {
      setError("No document loaded to process. Upload a PDF or clear selection to use default SRD.");
      setProgressMessage(null);
    }
  };

  const handleSearch = async (query: string) => {
    if (processedChunks.length === 0) {
      setError("Please process the document first to build the index.");
      return;
    }
    setSearchTerm(query);
    setLoadingState(LoadingState.SEARCHING);
    setError(null);
    setProgressMessage(null);
    setSearchResults([]);

    try {
      const chunkInfos = processedChunks.map(pc => ({ id: pc.id, summary: pc.summary, keywords: pc.keywords }));
      const relevantIndices = await findRelevantChunkIndices(query, chunkInfos);

      const results = relevantIndices
        .map(index => processedChunks[index])
        .filter(Boolean) as SearchResultItem[];
      setSearchResults(results);
    } catch (err: any) {
      console.error("Search error:", err);
      setError(`Search failed: ${err.message || 'Unknown error'}`);
    }
    setLoadingState(LoadingState.IDLE);
  };

  const goToCharacterSheet = () => {
    setCurrentView('sheet');
  };

  const handleViewSrdChunk = (chunk: ProcessedChunk) => {
    setSrdChunkModalContent(chunk);
  };
  
  const handleInteractiveTermAction = (termConfig: InteractiveTermConfig) => {
    if (termConfig.action.type === 'modal' && termConfig.action.modalData) {
      setActiveModalContent(termConfig.action.modalData);
    } else if (termConfig.action.type === 'navigate' && termConfig.action.targetView) {
      if (termConfig.action.targetView === 'creator' && termConfig.action.targetId) {
        const creatorParams: CreatorParams = {};
        if (termConfig.originalTermData && (termConfig.originalTermData as ClassData).subclasses) { 
          creatorParams.classId = termConfig.action.targetId;
        } else if (termConfig.originalTermData && (termConfig.originalTermData as Ancestry).features) { 
            creatorParams.ancestryId = termConfig.action.targetId;
        } else if (termConfig.originalTermData && (termConfig.originalTermData as Community).feature) { 
             creatorParams.communityId = termConfig.action.targetId;
        }
        setInitialCreatorParams(creatorParams);
      }
      setCurrentView(termConfig.action.targetView);
    } else if (termConfig.action.type === 'filter' && termConfig.action.targetView && termConfig.action.filterContext) {
      setCurrentView(termConfig.action.targetView);
    }
  };


  const allInteractiveTerms = useMemo(() => {
    const configs: InteractiveTermConfig[] = [];
    
    (srdCreatorData.conditions || []).forEach(cond => {
      configs.push({
        id: `condition-${cond.id}`,
        name: cond.name,
        action: { type: 'modal', modalData: cond },
        originalTermData: cond
      });
    });

    (srdCreatorData.gameTerms || []).forEach(term => {
      configs.push({
        id: `game_term-${term.id}`,
        name: term.name,
        action: { type: 'modal', modalData: term },
        originalTermData: term
      });
    });

    (srdCreatorData.classes || []).forEach(cls => {
      configs.push({
        id: `class-${cls.id}`,
        name: cls.name,
        action: { 
          type: 'navigate', 
          targetView: 'creator', 
          targetId: cls.id,
        },
        originalTermData: cls
      });
    });
    
    (srdCreatorData.ancestries || []).forEach(anc => {
        configs.push({
            id: `ancestry-${anc.id}`,
            name: anc.name,
            action: {
                type: 'navigate',
                targetView: 'creator',
                targetId: anc.id,
            },
            originalTermData: anc
        });
    });

    (srdCreatorData.communities || []).forEach(com => {
        configs.push({
            id: `community-${com.id}`,
            name: com.name,
            action: {
                type: 'navigate',
                targetView: 'creator',
                targetId: com.id,
            },
            originalTermData: com
        });
    });
    
    (srdCreatorData.domainCards ? Array.from(new Set(srdCreatorData.domainCards.map(dc => dc.domain))) : []).forEach(domainName => {
      configs.push({
        id: `domain_concept-${domainName.toLowerCase()}`,
        name: domainName,
        action: {
          type: 'navigate',
          targetView: 'domainCardsRef',
          filterContext: { domain: domainName } 
        },
        originalTermData: { id: `domain_concept-${domainName.toLowerCase()}`, name: domainName, description: `Information about the ${domainName} domain.` }
      });
    });

    return configs;
  }, [srdCreatorData]);


  const renderNav = () => (
    <nav className="mb-8 flex justify-center space-x-2 sm:space-x-4 flex-wrap">
       <Button
        onClick={() => setCurrentView('dashboard')}
        variant={currentView === 'dashboard' ? 'primary' : 'secondary'}
        aria-current={currentView === 'dashboard' ? 'page' : undefined}
      >
        Dashboard
      </Button>
      <Button
        onClick={() => setCurrentView('indexer')}
        variant={currentView === 'indexer' ? 'primary' : 'secondary'}
        aria-current={currentView === 'indexer' ? 'page' : undefined}
      >
        SRD Indexer
      </Button>
       <Button
        onClick={() => setCurrentView('startingCampaign')}
        variant={currentView === 'startingCampaign' ? 'primary' : 'secondary'}
        aria-current={currentView === 'startingCampaign' ? 'page' : undefined}
      >
        Starting Campaign
      </Button>
      <Button
        onClick={() => setCurrentView('rules')}
        variant={currentView === 'rules' ? 'primary' : 'secondary'}
        aria-current={currentView === 'rules' ? 'page' : undefined}
      >
        Core Rules
      </Button>
      <Button
        onClick={() => setCurrentView('mechanics')}
        variant={currentView === 'mechanics' ? 'primary' : 'secondary'}
        aria-current={currentView === 'mechanics' ? 'page' : undefined}
      >
        Detailed Mechanics
      </Button>
       <Button
        onClick={() => setCurrentView('equipment')}
        variant={currentView === 'equipment' ? 'primary' : 'secondary'}
        aria-current={currentView === 'equipment' ? 'page' : undefined}
      >
        Equipment
      </Button>
      <Button
        onClick={() => setCurrentView('gmTools')}
        variant={currentView === 'gmTools' ? 'primary' : 'secondary'}
        aria-current={currentView === 'gmTools' ? 'page' : undefined}
      >
        GM Tools
      </Button>
      <Button
        onClick={() => setCurrentView('tabletop')}
        variant={currentView === 'tabletop' ? 'primary' : 'secondary'}
        aria-current={currentView === 'tabletop' ? 'page' : undefined}
      >
        Virtual Tabletop
      </Button>
      <Button
        onClick={() => setCurrentView('domainCardsRef')}
        variant={currentView === 'domainCardsRef' ? 'primary' : 'secondary'}
        aria-current={currentView === 'domainCardsRef' ? 'page' : undefined}
      >
        Domain Cards
      </Button>
      <Button
        onClick={() => {
          setInitialCreatorParams(null); 
          setCurrentView('creator');
        }}
        variant={currentView === 'creator' ? 'primary' : 'secondary'}
        aria-current={currentView === 'creator' ? 'page' : undefined}
      >
        Character Creator
      </Button>
      {characterData && characterData.name && characterData.class && ( 
        <Button
          onClick={() => setCurrentView('sheet')}
          variant={currentView === 'sheet' ? 'primary' : 'secondary'}
          aria-current={currentView === 'sheet' ? 'page' : undefined}
        >
          View Character Sheet
        </Button>
      )}
    </nav>
  );

const CharacterSheetDisplay: React.FC<{ data: CharacterData }> = ({ data }) => {
  const formatModifier = (value: number) => value >= 0 ? `+${value}` : value.toString();

  return (
    <Card title={`${data.name || "Unnamed Character"} - Level ${data.level} ${data.class?.name || ''}`} className="max-w-4xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
        
        <div className="space-y-3">
          <LiveStatsPanel character={data} />
          <div className="mt-4 space-y-1 text-sm">
             <p><strong>Pronouns:</strong> {data.pronouns || 'N/A'}</p>
             <p><strong>Description:</strong> {data.description || 'N/A'}</p>
             <p><strong>Class:</strong> {data.class?.name || 'N/A'} {data.subclass ? `(${data.subclass.name})` : ''}</p>
             {data.subclass?.spellcastTrait && <p><strong>Spellcast Trait:</strong> {data.subclass.spellcastTrait}</p>}
             <p><strong>Ancestry:</strong> {data.ancestry?.name || 'N/A'}</p>
             <p><strong>Community:</strong> {data.community?.name || 'N/A'}</p>
             <p><strong>Stress:</strong> {data.stress.current}/{data.stress.max}</p>
             <p><strong>Hope:</strong> {data.hope.current}/{data.hope.max}</p>
          </div>
        </div>

        
        <div className="space-y-4">
          <div>
            <h4 className="text-lg font-semibold text-sky-300 mb-1">Traits:</h4>
            <ul className="list-disc list-inside ml-2 text-slate-300 text-sm">
              {(data.traits || []).map(trait => (
                <li key={trait.name}>{trait.name}: {formatModifier(trait.value)}</li>
              ))}
            </ul>
          </div>
           <div>
            <h4 className="text-lg font-semibold text-sky-300 mb-1">Gold:</h4>
            <p className="text-slate-300 text-sm">{data.gold.handfuls} Handful(s)</p>
          </div>
           <div>
            <h4 className="text-lg font-semibold text-sky-300 mb-1">Inventory:</h4>
            <p className="text-slate-300 text-sm whitespace-pre-line">{data.inventory.join(', ') || 'Empty'}</p>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <h4 className="text-xl font-semibold text-sky-300 mb-2 border-t border-slate-700 pt-4">Features & Abilities:</h4>
        {data.features && data.features.length > 0 ? (
          <div className="space-y-3 max-h-60 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-800">
            {data.features.map((feature, index) => (
              <div key={`${feature.name}-${index}`} className="p-3 bg-slate-700/50 rounded">
                <strong className="text-sky-200">{feature.name}</strong> <span className="text-xs text-slate-400">({feature.source})</span>
                <p className="text-xs text-slate-300 mt-1 whitespace-pre-line">{feature.description}</p>
              </div>
            ))}
          </div>
        ) : <p className="text-slate-400 text-sm">No special features selected/derived yet.</p>}
      </div>
      
      <div className="mt-6">
        <h4 className="text-xl font-semibold text-sky-300 mb-2 border-t border-slate-700 pt-4">Experiences:</h4>
        {data.experiences && data.experiences.some(exp => exp.text) ? (
            <ul className="list-disc list-inside ml-2 text-slate-300 text-sm">
                {data.experiences.map((exp, index) => exp.text && (
                <li key={index}>{exp.text} ({formatModifier(exp.modifier)})</li>
                ))}
            </ul>
        ) : <p className="text-slate-400 text-sm">No experiences defined.</p>}
      </div>

      <div className="mt-6">
        <h4 className="text-xl font-semibold text-sky-300 mb-2 border-t border-slate-700 pt-4">Domain Cards:</h4>
        {data.domainCards && data.domainCards.length > 0 ? (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {data.domainCards.map(card => (
                    <div key={card.id} className="p-3 bg-slate-700/50 rounded">
                        <strong className="text-sky-200">{card.name}</strong> <span className="text-xs text-slate-400">({card.domain} Lvl {card.level})</span>
                        <p className="text-xs text-slate-300 mt-1 whitespace-pre-line">{card.description}</p>
                    </div>
                ))}
            </div>
        ) : <p className="text-slate-400 text-sm">No domain cards selected.</p>}
      </div>
      
      {data.background && (
        <div className="mt-6">
          <h4 className="text-xl font-semibold text-sky-300 mb-2 border-t border-slate-700 pt-4">Background:</h4>
          <p className="text-slate-300 whitespace-pre-line text-sm">{data.background}</p>
        </div>
      )}
      {data.connections && (
        <div className="mt-6">
          <h4 className="text-xl font-semibold text-sky-300 mb-2 border-t border-slate-700 pt-4">Connections:</h4>
          <p className="text-slate-300 whitespace-pre-line text-sm">{data.connections}</p>
        </div>
      )}
    </Card>
  );
};


  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card title="SRD Document Indexer & Search" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  Process the Daggerheart SRD (default text or your uploaded PDF) using the Gemini AI. 
                  This creates a searchable index of game rules, lore, and mechanics for quick and efficient reference during your adventures.
                </p>
                <Button onClick={() => setCurrentView('indexer')} className="w-full mt-auto">
                  Open Indexer
                </Button>
              </Card>
              <Card title="Starting a Campaign" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  Guidance on beginning your Daggerheart journey, including Session Zero and collaborative Setting Creation.
                </p>
                <Button onClick={() => setCurrentView('startingCampaign')} className="w-full mt-auto">
                  Start Campaign Guide
                </Button>
              </Card>
              <Card title="Core Game Rules" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  Browse a selection of Daggerheart's core mechanics, including combat, stress, conditions, and more, directly from the processed SRD. Interactive terms provide quick definitions.
                </p>
                <Button onClick={() => setCurrentView('rules')} className="w-full mt-auto">
                  Browse Core Rules
                </Button>
              </Card>
              <Card title="Detailed Game Mechanics" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  Explore in-depth mechanics such as GM Moves, Adversary Actions, Special Rolls (Trait, Spellcast, Reaction), Action Economy, Hope & Fear, and more.
                </p>
                <Button onClick={() => setCurrentView('mechanics')} className="w-full mt-auto">
                  View Detailed Mechanics
                </Button>
              </Card>
              <Card title="Equipment Reference" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  Browse all weapons, armor, loot, and consumables available in Daggerheart. Filter by type, tier, and search for specific items.
                </p>
                <Button onClick={() => setCurrentView('equipment')} className="w-full mt-auto">
                  Browse Equipment
                </Button>
              </Card>
               <Card title="GM Tools" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  Resources for Game Masters: GM Guidance, Core GM Mechanics, Adversaries, Environments, and the Witherwild Campaign Frame.
                </p>
                <Button onClick={() => setCurrentView('gmTools')} className="w-full mt-auto">
                  Access GM Tools
                </Button>
              </Card>
              <Card title="Virtual Tabletop" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  A lightweight grid map for moving tokens and tracking turns during quick encounters.
                </p>
                <Button onClick={() => setCurrentView('tabletop')} className="w-full mt-auto">
                  Open Tabletop
                </Button>
              </Card>
               <Card title="Domain Card Reference" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  A complete reference of all Domain Cards available in Daggerheart, detailing their abilities, spells, and grimoires. Card descriptions feature interactive terms.
                </p>
                <Button onClick={() => setCurrentView('domainCardsRef')} className="w-full mt-auto">
                  Browse Domain Cards
                </Button>
              </Card>
              <Card title="Character Creator" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  Forge your Daggerheart hero. This step-by-step guide helps you select your class, ancestry, community, 
                  assign traits, choose equipment, pick domain cards, and define your unique background and experiences. Descriptions include interactive terms.
                </p>
                <Button onClick={() => { setInitialCreatorParams(null); setCurrentView('creator');}} className="w-full mt-auto">
                  Create New Character
                </Button>
              </Card>
              <Card title="View Character Sheet" className="flex flex-col">
                <p className="text-slate-300 text-sm mb-4 flex-grow">
                  Review your active character's complete profile, including statistics, features, abilities, inventory, 
                  domain cards, and personal story. 
                  {(!characterData || !characterData.name || !characterData.class) && <span className="block mt-2 text-amber-400">No character created yet.</span>}
                </p>
                <Button 
                  onClick={() => setCurrentView('sheet')} 
                  disabled={!characterData || !characterData.name || !characterData.class}
                  className="w-full mt-auto"
                >
                  View Character
                </Button>
              </Card>
            </div>
          </div>
        );
      case 'startingCampaign':
        return <StartingCampaignGuide 
                  processedChunks={processedChunks} 
                  interactiveTerms={allInteractiveTerms} 
                  onTermClick={handleInteractiveTermAction} 
                />;
      case 'gmTools':
        return <GMToolsDashboard 
                  processedChunks={processedChunks} 
                  interactiveTerms={allInteractiveTerms} 
                  onTermClick={handleInteractiveTermAction} 
                />;
      case 'tabletop':
        return <VirtualTabletop />;
      case 'domainCardsRef':
        return <DomainCardReference 
                  srdData={srdCreatorData} 
                  onTermClick={handleInteractiveTermAction} 
                  interactiveTerms={allInteractiveTerms} 
                />;
      case 'equipment':
        return <EquipmentReference 
                  srdData={srdCreatorData} 
                  onTermClick={handleInteractiveTermAction} 
                  interactiveTerms={allInteractiveTerms} 
                />;
      case 'rules':
        return <GameRules 
                  processedChunks={processedChunks} 
                  onTermClick={handleInteractiveTermAction} 
                  interactiveTerms={allInteractiveTerms} 
                />;
      case 'mechanics':
        return <GameMechanicsDetails 
                  processedChunks={processedChunks} 
                  onTermClick={handleInteractiveTermAction} 
                  interactiveTerms={allInteractiveTerms} 
                />;
      case 'creator':
        return (
          <CharacterCreator
            character={characterData} 
            setCharacter={setCharacterData} 
            srdData={srdCreatorData}
            goToSheet={goToCharacterSheet}
            srdChunks={processedChunks}
            onViewSrdChunk={handleViewSrdChunk}
            onTermClick={handleInteractiveTermAction}
            interactiveTerms={allInteractiveTerms}
            initialParams={initialCreatorParams || undefined}
            onParamsConsumed={() => setInitialCreatorParams(null)}
          />
        );
      case 'sheet':
        return characterData.name && characterData.class ? <CharacterSheetDisplay data={characterData} /> : <p className="text-slate-400 text-center">No character data to display. Create a character first!</p>;
      case 'indexer':
      default:
        const isProcessingPdf = loadingState === LoadingState.PROCESSING_PDF_STRUCTURE || loadingState === LoadingState.PROCESSING_PDF_SECTIONS;
        const isProcessingText = loadingState === LoadingState.PROCESSING_TEXT_CHUNKS;
        const isProcessing = isProcessingPdf || isProcessingText;
        const isAnythingLoading = Object.values(LoadingState).includes(loadingState) && loadingState !== LoadingState.IDLE;

        return (
          <>
            <ErrorDisplay message={error} />
            <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
              <section className="bg-slate-800/50 backdrop-blur-md p-6 rounded-xl shadow-2xl border border-slate-700">
                <h2 className="text-2xl font-semibold text-sky-300 mb-4 border-b-2 border-sky-700 pb-2">Document Processing</h2>

                <div className="mb-6">
                  <label htmlFor="srd-pdf-upload" className="block text-sm font-medium text-slate-300 mb-1">Upload Custom SRD (PDF)</label>
                  <div className="flex items-center space-x-2">
                    <input
                      ref={fileInputRef}
                      type="file"
                      id="srd-pdf-upload"
                      accept=".pdf"
                      onChange={handlePdfFileChange}
                      className="block w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-sky-600 file:text-sky-50 hover:file:bg-sky-500 disabled:opacity-50 disabled:cursor-not-allowed"
                      aria-describedby="pdf-file-info"
                      disabled={isAnythingLoading}
                    />
                  </div>
                  {srdPdfFile && (
                    <div id="pdf-file-info" className="mt-2 text-sm text-slate-400 flex items-center justify-between">
                      <span>Selected: <span className="font-medium text-sky-300">{srdPdfFile.name}</span></span>
                      <Button 
                        onClick={handleClearPdfFile} 
                        variant="danger" 
                        size="sm" 
                        className="ml-2"
                        disabled={isAnythingLoading}
                       >
                        Clear PDF
                      </Button>
                    </div>
                  )}
                </div>
                
                {srdPdfFile && loadingState === LoadingState.IDLE && !error && (
                  <p className="text-xs text-green-300 mb-4 bg-green-900/30 p-2 rounded-md">
                    PDF '{srdPdfFile.name}' selected. Click "Process Document" to analyze with Gemini.
                  </p>
                )}
                 {!srdPdfFile && srdText === SRD_TEXT_TO_USE && rawChunks.length > 0 && loadingState === LoadingState.IDLE && !error && (
                     <p className="text-xs text-blue-300 mb-4 bg-blue-900/30 p-2 rounded-md">
                        Default Daggerheart SRD text loaded and chunked. Ready to process.
                     </p>
                 )}


                <Button
                  onClick={handleProcessDocument}
                  disabled={isAnythingLoading || (!srdPdfFile && rawChunks.length === 0)}
                  className="w-full"
                  title={!srdPdfFile && rawChunks.length === 0 ? "No document chunks to process. Default SRD might be loading or empty." : (srdPdfFile ? "Process uploaded PDF with Gemini." : "Process default SRD text.")}
                >
                  {isProcessingPdf ? (
                    <>
                      <LoadingSpinner size="h-5 w-5" />
                      <span className="ml-2">Processing PDF...</span>
                    </>
                  ) : isProcessingText ? (
                     <>
                      <LoadingSpinner size="h-5 w-5" />
                      <span className="ml-2">Processing Text Chunks...</span>
                    </>
                  ) : (
                    "Process Document & Build Index"
                  )}
                </Button>
                {progressMessage && (
                    <p className="mt-2 text-sm text-sky-300 text-center" aria-live="polite">{progressMessage}</p>
                )}

                {!srdPdfFile && (
                  <div className="mt-6">
                    <h3 className="text-xl font-medium text-slate-300 mb-3">Raw Chunks (Default SRD) ({rawChunks.length})</h3>
                    {loadingState === LoadingState.CHUNKING && rawChunks.length === 0 && <div className="flex justify-center my-4"><LoadingSpinner /></div>}
                    <div className="max-h-96 overflow-y-auto bg-slate-900/70 p-4 rounded-lg border border-slate-700 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-800">
                      {rawChunks.length > 0 ? (
                        rawChunks.map(chunk => (
                          <div key={chunk.id} className="p-3 mb-2 bg-slate-700/50 rounded-md text-sm">
                            <strong className="text-sky-400">{chunk.title}</strong>
                            <p className="text-slate-400 mt-1 truncate" title={chunk.content.substring(0, 300)}>{chunk.content.substring(0, 100)}...</p>
                          </div>
                        ))
                      ) : (
                         loadingState !== LoadingState.CHUNKING && loadingState !== LoadingState.PROCESSING_PDF_STRUCTURE && loadingState !== LoadingState.PROCESSING_PDF_SECTIONS && (
                          <p className="text-slate-500">
                            {srdText === SRD_TEXT_TO_USE ? "Default SRD text loaded, but no chunks generated. This might indicate an issue with the chunker or the SRD text structure." : "Default SRD text not yet chunked."}
                          </p>
                         )
                      )}
                    </div>
                  </div>
                )}
                {srdPdfFile && (
                    <div className="mt-6 p-4 bg-slate-700/50 rounded-lg text-slate-400 text-sm">
                        Raw Chunks view is not applicable for PDF uploads. The PDF will be processed directly by Gemini to create indexed content.
                    </div>
                )}
              </section>

              <section className="bg-slate-800/50 backdrop-blur-md p-6 rounded-xl shadow-2xl border border-slate-700">
                <h2 className="text-2xl font-semibold text-sky-300 mb-6 border-b-2 border-sky-700 pb-2">Indexed Content & Search</h2>
                <SearchBar onSearch={handleSearch} isLoading={loadingState === LoadingState.SEARCHING || isProcessing} />

                {searchTerm && searchResults.length > 0 && (
                  <div className="mb-8">
                    <h3 className="text-xl font-medium text-slate-300 mb-3" aria-live="polite">Search Results for "{searchTerm}" ({searchResults.length})</h3>
                    <div className="max-h-[500px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-800">
                      {searchResults.map(chunk => (
                        <ChunkCard key={`search-${chunk.id}`} chunk={chunk} isSearchResult={true} onTermClick={handleInteractiveTermAction} interactiveTerms={allInteractiveTerms} />
                      ))}
                    </div>
                  </div>
                )}
                {searchTerm && searchResults.length === 0 && loadingState !== LoadingState.SEARCHING && !isProcessing && (
                  <p className="text-slate-400 text-center py-4" aria-live="polite">No relevant sections found for "{searchTerm}".</p>
                )}

                <h3 className="text-xl font-medium text-slate-300 mb-3 mt-4">All Processed Chunks ({processedChunks.length})</h3>
                {isProcessing && processedChunks.length === 0 && <div className="flex justify-center my-4"><LoadingSpinner /></div>}
                <div className="max-h-[600px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-800">
                  {processedChunks.length > 0 ? (
                    processedChunks.map(chunk => (
                      <ChunkCard key={chunk.id} chunk={chunk} onTermClick={handleInteractiveTermAction} interactiveTerms={allInteractiveTerms} />
                    ))
                  ) : (
                    !isProcessing && <p className="text-slate-500">
                        No chunks processed yet. 
                        {srdPdfFile ? "Click \"Process Document\" to analyze the PDF with Gemini." : "Click \"Process Document\" to build the index from the default SRD."}
                    </p>
                  )}
                </div>
              </section>
            </div>
          </>
        );
    }
  };
  
  const getTagline = () => {
    switch (currentView) {
      case 'dashboard':
        return "Your central hub for Daggerheart tools and utilities.";
      case 'indexer':
        return "Process and search the Daggerheart System Reference Document using Gemini.";
      case 'startingCampaign':
        return "Guidance for beginning your Daggerheart campaign.";
      case 'rules':
        return "Browse core Daggerheart game mechanics in a structured format.";
      case 'mechanics':
        return "Dive into detailed game mechanics including action resolution, GM moves, and special rolls.";
      case 'equipment':
        return "Browse weapons, armor, loot, and consumables.";
      case 'gmTools':
        return "Essential tools and guides for Game Masters.";
      case 'tabletop':
        return "A simple virtual tabletop for your Daggerheart encounters.";
      case 'domainCardsRef':
        return "Reference all Daggerheart Domain Cards.";
      case 'creator':
        return "Create your Daggerheart hero step by step.";
      case 'sheet':
        return "Review your generated character.";
      default:
        return "Explore the world of Daggerheart.";
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-sky-900 p-4 sm:p-8 text-slate-100 antialiased" style={{ fontFamily: "'Inter', sans-serif" }}>
      <header className="text-center mb-6">
        <h1 className="text-4xl sm:text-5xl font-bold text-sky-400" style={{ fontFamily: "'Orbitron', sans-serif" }}>
          Daggerheart Utility Suite
        </h1>
        <p className="text-slate-400 mt-2 text-lg">
          {getTagline()}
        </p>
      </header>

      {renderNav()}
      {renderContent()}

      {srdChunkModalContent && (
        <div 
          className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          onClick={() => setSrdChunkModalContent(null)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="srd-modal-title"
        >
          <div 
            className="bg-slate-800 p-6 rounded-lg shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-700 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-700"
            onClick={(e) => e.stopPropagation()} 
          >
            <div className="flex justify-between items-center mb-4">
              <h2 id="srd-modal-title" className="text-2xl font-semibold text-sky-400">{srdChunkModalContent.title}</h2>
              <Button variant="danger" size="sm" onClick={() => setSrdChunkModalContent(null)} aria-label="Close SRD content modal">
                Close
              </Button>
            </div>
            <h3 className="text-lg font-medium text-sky-300 mb-1">Summary:</h3>
            <p className="text-sm text-slate-300 mb-4 whitespace-pre-line">{srdChunkModalContent.summary}</p>
            <h3 className="text-lg font-medium text-sky-300 mb-1">Keywords:</h3>
            <div className="flex flex-wrap gap-2 mb-4">
              {srdChunkModalContent.keywords.map((keyword, index) => (
                <span key={index} className="bg-sky-700 text-sky-100 text-xs px-2 py-1 rounded-full">
                  {keyword}
                </span>
              ))}
            </div>
            <h3 className="text-lg font-medium text-sky-300 mb-1">Full Content:</h3>
            {srdChunkModalContent.contentTruncated && (
                <p className="text-xs text-amber-400 italic mb-2">(Content was summarized by Gemini due to length in the original PDF processing step)</p>
            )}
            <pre className="text-xs text-slate-400 whitespace-pre-wrap break-words font-sans bg-slate-900 p-3 rounded-md">
              {srdChunkModalContent.content}
            </pre>
          </div>
        </div>
      )}

      {activeModalContent && (
        <div 
          className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 z-[51]"
          onClick={() => setActiveModalContent(null)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="interactive-term-modal-title"
        >
          <div 
            className="bg-slate-800 p-6 rounded-lg shadow-2xl max-w-md w-full max-h-[80vh] overflow-y-auto border border-slate-700 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-700"
            onClick={(e) => e.stopPropagation()} 
          >
            <div className="flex justify-between items-center mb-4">
              <h2 id="interactive-term-modal-title" className="text-xl font-semibold text-sky-400">{activeModalContent.name}</h2>
              <Button variant="danger" size="sm" onClick={() => setActiveModalContent(null)} aria-label={`Close ${activeModalContent.name} definition modal`}>
                Close
              </Button>
            </div>
            <p className="text-sm text-slate-300 whitespace-pre-line">
              {activeModalContent.description}
            </p>
            {activeModalContent.effectsSummary && (
                 <div className="mt-3 pt-3 border-t border-slate-700">
                    <h3 className="text-md font-semibold text-sky-300 mb-1">Effects Summary:</h3>
                    <p className="text-sm text-slate-300 whitespace-pre-line">{activeModalContent.effectsSummary}</p>
                 </div>
            )}
            {activeModalContent.srdPageReference && (
              <p className="text-xs text-slate-500 mt-4 italic">SRD Ref: {activeModalContent.srdPageReference}</p>
            )}
          </div>
        </div>
      )}


      <footer className="text-center mt-12 py-6 border-t border-slate-700">
        <p className="text-slate-500 text-sm">Powered by React, Tailwind CSS, and Google Gemini API.</p>
        {currentView === 'indexer' && srdPdfFile && <p className="text-xs text-slate-600 mt-1">Custom SRD: {srdPdfFile.name}</p>}
        {currentView === 'indexer' && !srdPdfFile && srdText && <p className="text-xs text-slate-600 mt-1">Using default Daggerheart SRD text.</p>}
      </footer>
    </div>
  );
};

export default App;
