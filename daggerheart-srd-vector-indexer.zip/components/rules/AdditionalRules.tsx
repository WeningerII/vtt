
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const AdditionalRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-3">
    <p>The following rules apply to many aspects of the game.</p>

    <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-1">ROUNDING UP</h4>
    <p>This game doesn’t use fractions; if you need to round to a whole number, round up unless otherwise specified. When in doubt, resolve any ambiguity in favor of the PCs.</p>

    <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-1">REROLLING DICE</h4>
    <p>When a feature allows you to reroll a die, you always take the new result unless the feature specifically says otherwise.</p>

    <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-1">INCOMING DAMAGE</h4>
    <p>Incoming damage means the total damage from a single attack or source, before Armor Slots are marked.</p>

    <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-1">SIMULTANEOUS EFFECTS</h4>
    <p>If the resolution order of multiple effects is unclear, the person in control of the effects (player or GM) decides what order to resolve them in.</p>

    <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-1">STACKING EFFECTS</h4>
    <p>Unless stated otherwise, all effects beside conditions and advantage/disadvantage can stack.</p>

    <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-1">ONGOING SPELL EFFECTS</h4>
    <p>If an effect doesn’t have a listed mechanical expiration, it only ends when decided by the controlling player, the GM, or the demands of the fiction.</p>

    <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-1">SPENDING RESOURCES</h4>
    <p>Unless an effect states otherwise, you can’t spend Hope or mark Stress multiple times on the same feature to increase or repeat its effects on the same roll.</p>

    <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-1">USING FEATURES AFTER A ROLL</h4>
    <p>If a feature allows you to affect a roll after the result has been totaled, you can use it after the GM declares whether the roll succeeds or fails, but not after the consequences unfold or another roll is made.</p>
  </div>
);

const AdditionalRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available here if needed in the future, but for now, content is static.
  // The original chunk "CORE MECHANICS > Additional Rules" might still be passed but this component now focuses only on the general rules.
  return (
    <Card title={ruleDisplayName}>
      <AdditionalRulesContent />
    </Card>
  );
};

export default AdditionalRules;
