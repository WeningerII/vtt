
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const LevelingUpRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-3">
    <p>Your party levels up whenever the GM decides you’ve reached a narrative milestone (usually about every 3 sessions). All party members level up at the same time.</p>
    <p>Daggerheart has 10 PC levels divided into 4 tiers:</p>
    <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
      <li>Tier 1 encompasses level 1 only.</li>
      <li>Tier 2 encompasses levels 2–4.</li>
      <li>Tier 3 encompasses levels 5–7.</li>
      <li>Tier 4 encompasses levels 8–10.</li>
    </ul>
    <p>Your tier affects your damage thresholds, tier achievements, and access to advancements.</p>
    
    <div className="mt-4">
        <h4 className="text-lg font-semibold text-sky-300 mb-1">STEP ONE: TIER ACHIEVEMENTS</h4>
        <p className="text-sm">Take any applicable tier achievements.</p>
        <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
            <li>At level 2, you gain a new Experience at +2 and permanently increase your Proficiency by 1.</li>
            <li>At level 5, you gain a new Experience at +2, permanently increase your Proficiency by 1, and clear any marked traits.</li>
            <li>At level 8, you gain a new Experience at +2, permanently increase your Proficiency by 1, and clear any marked traits.</li>
        </ul>
        <p className="text-xs text-slate-400 italic">SRD Page: 42 (Daggerheart SRD)</p>
    </div>
    
    <div className="mt-4">
        <h4 className="text-lg font-semibold text-sky-300 mb-1">STEP TWO: ADVANCEMENTS</h4>
        <p className="text-sm">Choose any two advancements with at least one unmarked slot from your tier or below. Options with multiple slots can be chosen more than once. When you choose an advancement, mark one of its slots.</p>
        <ul className="list-disc list-inside ml-4 my-2 space-y-2 text-sm">
            <li><strong>When you choose to increase two unmarked character traits and mark them:</strong> Choose two unmarked character traits and gain a permanent +1 bonus to them. You can’t increase these stats again until the next tier (when your tier achievement allows you to clear those marks).</li>
            <li><strong>When you choose to permanently add 1 or more Hit Point slots:</strong> Darken the outline of the next rectangle in the Hit Point section of your character sheet in pen or permanent marker.</li>
            <li><strong>When you choose to permanently add 1 or more Stress slots:</strong> Darken the outline of the next rectangle in the Stress section of your character sheet in pen or permanent marker.</li>
            <li><strong>When you choose to increase an Experience:</strong> Gain a permanent +1 bonus to an Experience.</li>
            <li><strong>When you take an additional domain card:</strong> You can choose an additional domain card at or below your level or from your class’s domains. If you’ve multiclassed, you can instead select a card at or below half your level from your chosen multiclass domain.</li>
            <li><strong>When you choose to increase your Evasion:</strong> Gain a permanent +1 bonus to your Evasion.</li>
            <li><strong>When you choose to take an upgraded subclass card:</strong> Take the next card for your subclass. If you have only the foundation card, take a specialization; if you have a specialization already, take a mastery. Then cross out this tier’s multiclass option.</li>
            <li><strong>When you choose to increase your Proficiency:</strong> Fill in one of the open circles in the “Proficiency” section of your character sheet, then increase your weapon’s number of damage dice by 1. The black box around this advancement’s slots indicates you must spend two advancements and mark both level-up slots in order to take it as an option.</li>
            <li><strong>When you choose to multiclass:</strong> Choose an additional class, select one of its domains, and gain its class feature. Add the appropriate multiclass module to your character sheet and take the foundation card from one of its subclasses. Then cross out the “upgraded subclass” advancement option in this tier and all other “multiclass” advancement options on your character sheet. The black box around this advancement’s slots indicates you must spend two advancements and mark both level-up slots in order to take it as an option.</li>
        </ul>
    </div>

    <div className="mt-4">
        <h4 className="text-lg font-semibold text-sky-300 mb-1">STEP THREE: DAMAGE THRESHOLDS</h4>
        <p className="text-sm">Increase all damage thresholds by 1.</p>
    </div>
    
    <div className="mt-4">
        <h4 className="text-lg font-semibold text-sky-300 mb-1">STEP FOUR: DOMAIN CARDS</h4>
        <p className="text-sm">Acquire a new domain card at your level or lower from one of your class’s domains and add it to your loadout or vault. If your loadout is already full, you can’t add the new card to it until you move another into your vault. You can also exchange one domain card you’ve previously acquired for a different domain card of the same level or lower.</p>
    </div>
  </div>
);

const LevelingUpRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component uses static content for leveling up.
  // The original chunk "CORE MECHANICS > Additional Rules" might be passed as context but isn't directly used for rendering this specific static content.
  return (
    <Card title={ruleDisplayName}>
      <LevelingUpRulesContent />
    </Card>
  );
};

export default LevelingUpRules;
