
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const TurnOrderActionEconomyRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-4">
    <p>
      Daggerheart’s turns don’t follow a traditional, rigid format:
      there is no explicit initiative mechanic and characters don’t
      have a set number of actions they can take or things they can
      do before the spotlight passes to someone else. A player with
      the spotlight describes what their character does and the
      spotlight simply swings to whoever:
    </p>
    <ul className="list-alpha list-inside ml-4 my-2 space-y-1 text-sm">
      <li>the fiction would naturally turn it toward</li>
      <li>hasn’t had the focus in a while, or</li>
      <li>a triggered mechanic puts it on</li>
    </ul>

    <div className="mt-4 pt-3 border-t border-slate-700">
      <h4 className="text-lg font-semibold text-sky-300 mb-2">Optional: Spotlight Tracker Tool</h4>
      <p>
        If your group prefers a more traditional action economy,
        you can use tokens to track how many times a player has
        had the spotlight: At the start of a session or scene, each
        player adds a certain number of tokens (we recommend
        3) to their character sheet and removes a token each
        time they take an action. If the spotlight would swing to
        someone without any tokens, it swings to someone else
        instead. Once every player has used all their available
        tokens, players refill their character sheet with the same
        number of tokens as before, then continue playing.
      </p>
    </div>
     <p className="text-xs text-slate-400 italic mt-2">SRD Page: 40</p>
  </div>
);

const TurnOrderActionEconomyRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component now uses static content for Turn Order & Action Economy.
  return (
    <Card title={ruleDisplayName}>
      <TurnOrderActionEconomyRulesContent />
    </Card>
  );
};

export default TurnOrderActionEconomyRules;
