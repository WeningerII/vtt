
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const MulticlassingRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-3">
    <p>Starting at level 5, you can choose multiclassing as an option when leveling up. When you multiclass, you choose an additional class, gain access to one of its domains, and acquire its class feature.</p>
    <p>Take the appropriate multiclass module and add it to the right side of your character sheet, then choose a foundation card from one of its subclasses. If your foundation cards specify different Spellcast traits, you can choose which one to apply when making a Spellcast roll.</p>
    <p>Whenever you have the option to acquire a new domain card, you can choose from cards at or below half your current level (rounded up) from the domain you chose when you selected the multiclass advancement.</p>
    <p className="text-xs text-slate-400 italic">SRD Page: 43 (Daggerheart SRD)</p>
  </div>
);

const MulticlassingRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component uses static content for multiclassing.
  // The original chunk "CORE MECHANICS > Additional Rules" might be passed as context but isn't directly used for rendering this specific static content.
  return (
    <Card title={ruleDisplayName}>
      <MulticlassingRulesContent />
    </Card>
  );
};

export default MulticlassingRules;
