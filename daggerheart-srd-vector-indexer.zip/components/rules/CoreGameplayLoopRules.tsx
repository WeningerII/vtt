
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const CoreGameplayLoopRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-4">
    <p>The core gameplay loop is the procedure that drives every scene, both in and out of combat:</p>
    
    <div className="space-y-3 mt-3">
      <div>
        <h4 className="text-md font-semibold text-sky-200 mb-1">STEP 1: SET THE SCENE</h4>
        <p className="text-sm">The GM describes a scenario, establishing the PCs’ surroundings and any dangers, NPCs, or other important details the characters would notice.</p>
      </div>
      
      <div>
        <h4 className="text-md font-semibold text-sky-200 mb-1">STEP 2: ASK AND ANSWER QUESTIONS</h4>
        <p className="text-sm">The players ask clarifying questions to explore the scene more deeply and gather information that could inform their characters’ actions. The GM responds to these questions by giving the players information their characters could easily obtain, or by asking questions of their own to the players. The players also respond to any questions the GM poses to them. In this way, the table builds out the fiction collaboratively.</p>
      </div>
      
      <div>
        <h4 className="text-md font-semibold text-sky-200 mb-1">STEP 3: BUILD ON THE FICTION</h4>
        <p className="text-sm">As the scene develops, the players find opportunities to take action—problems to solve, obstacles to overcome, mysteries to investigate, and so on. The players describe how their characters proceed; if their proposed actions carry no chance of failure (or if failure would be boring), they automatically succeed. But if the outcome of their action is unknown, the GM calls for an action roll. Either way, the table works the outcome into the story and moves the fiction forward, narrating how the PC’s actions have changed things.</p>
      </div>
      
      <div>
        <h4 className="text-md font-semibold text-sky-200 mb-1">STEP 4: GO BACK TO STEP 1</h4>
        <p className="text-sm">The process repeats from the beginning, with the GM relaying any updated details or material changes to the players. This process continues until the end of the scene is triggered by a mechanic or arrives organically.</p>
      </div>
    </div>
  </div>
);

const CoreGameplayLoopRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component now uses static content for Core Gameplay Loop.
  // The original chunk "CORE MECHANICS > Core Gameplay Loop" might still be passed but this component displays this static content.
  return (
    <Card title={ruleDisplayName}>
      <CoreGameplayLoopRulesContent />
    </Card>
  );
};

export default CoreGameplayLoopRules;
