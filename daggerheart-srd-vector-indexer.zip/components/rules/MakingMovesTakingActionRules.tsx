import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const MakingMovesTakingActionRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-4">
    <p>
      Any time a character does something to advance the story,
      such as speaking with another character, interacting with the
      environment, making an attack, casting a spell, or using a
      class feature, they are making a move.
    </p>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">ACTION ROLLS</h4>
      <p>
        Any move where success would be trivial or failure would be
        boring automatically succeeds, but any move that’s difficult to
        accomplish or risky to attempt triggers an action roll.
      </p>
    </div>

    <div>
      <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">OVERVIEW</h5>
      <p>
        All action rolls require a pair of d12s called Duality Dice.
        These are two visually distinct twelve-sided dice, with one die
        representing Hope and the other representing Fear.
      </p>
      <p>
        To make an action roll, you roll the Duality Dice, sum the
        results, apply any relevant modifiers, and compare the total to
        a Difficulty number to determine the outcome:
      </p>
      <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
        <li>
          <strong>Success with Hope:</strong> If your total meets or beats the
          Difficulty AND your Hope Die shows a higher result than
          your Fear Die, you rolled a “Success with Hope.” You
          succeed and gain a Hope.
        </li>
        <li>
          <strong>Success with Fear:</strong> If your total meets or beats the
          Difficulty AND your Fear Die shows a higher result than
          your Hope Die, you rolled a “Success with Fear.” You
          succeed with a cost or complication, but the GM gains a
          Fear.
        </li>
        <li>
          <strong>Failure with Hope:</strong> If your total is less than the Difficulty
          AND your Hope Die shows a higher result than your Fear
          Die, you rolled a “Failure with Hope.” You fail with a minor
          consequence and gain a Hope, then the spotlight swings
          to the GM.
        </li>
        <li>
          <strong>Failure with Fear:</strong> If your total is less than the Difficulty
          AND your Fear Die shows a higher result than your Hope
          Die, you rolled a “Failure with Fear.” You fail with a major
          consequence and the GM gains a Fear, then the spotlight
          swings to the GM.
        </li>
        <li>
          <strong>Critical Success:</strong> If the Duality Dice show matching
          results, you rolled a “Critical Success” (“Crit”). You
          automatically succeed with a bonus, gain a Hope, and
          clear a Stress. If this was an attack roll, you deal critical
          damage.
        </li>
      </ul>
      <p className="text-xs text-slate-400 italic mt-1">Note: A Critical Success counts as a roll “with Hope.”</p>
      <p>
        After resolving the action roll, the table works together to
        weave the outcome into the narrative and play continues.
      </p>
    </div>

    <div>
      <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">FAILING FORWARD</h5>
      <p>
        In Daggerheart, every time you roll the dice, the scene
        changes in some way. There is no such thing as a roll where
        “nothing happens,” because the fiction constantly evolves
        based on the successes and failures of the characters.
      </p>
    </div>

    <div>
      <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">PROCEDURE</h5>
      <p>The following steps describe in more detail the procedure that all action rolls utilize:</p>
      <div className="space-y-2 mt-2">
        <p><strong>STEP 1: PICK AN APPROPRIATE TRAIT</strong><br />
        Some actions and effects specify in their description which
        trait applies to the roll; otherwise, the GM tells the acting
        player which character trait best applies to the action being
        attempted. If more than one trait could apply to the roll, the
        GM chooses or lets the acting player decide.</p>
        
        <p><strong>STEP 2: DETERMINE THE DIFFICULTY</strong><br />
        Some actions and features say in their description what the
        Difficulty is. Otherwise, the GM determines the Difficulty
        based on the scenario. The GM can choose whether to share
        the Difficulty with the table. In either case, the GM should
        communicate the potential consequences of failure to the
        acting player.</p>

        <p><strong>STEP 3: APPLY EXTRA DICE AND MODIFIERS</strong><br />
        The acting player decides whether to Utilize an Experience or
        activate other effects, then, if applicable, adds the appropriate
        tokens and dice (such as advantage or Rally dice) to their dice
        pool.</p>
        <p className="text-xs text-slate-400 italic mt-1">Note: Unless an action, ability, or feature specifically allows
        for it, a player must declare the use of any Experiences, extra
        dice, or other modifiers before they roll.</p>

        <p><strong>STEP 4: ROLL THE DICE</strong><br />
        The acting player rolls their entire dice pool and announces
        the results in the format of “[total result] with [Hope/Fear]”—
        or “Critical Success!” in the case of matching Duality Dice.</p>
        <p className="text-xs text-slate-400 italic mt-1">Example: A player is making an action roll with a +1 in the
        relevant trait and no other modifiers; they roll the Duality
        Dice and get a result of 5 on their Hope Die and 7 on their
        Fear Die, then announce “I rolled a 13 with Fear!”</p>

        <p><strong>STEP 5: RESOLVE THE OUTCOME</strong><br />
        The active player and the GM work together, along with the
        suggestions and support of the rest of the table, to resolve the
        outcome of the action.</p>
      </div>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">GM MOVES AND ADVERSARY ACTIONS</h4>
      <p>
        GMs also make moves. They should consider making a move
        when a player does one of the following things:
      </p>
      <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
        <li>Rolls with Fear on an action roll.</li>
        <li>Fails an action roll.</li>
        <li>Does something that would have consequences.</li>
        <li>Gives them a golden opportunity.</li>
        <li>Looks to them for what happens next.</li>
      </ul>
      <p>
        After the GM turn is done, the spotlight goes back to the PCs.
        Many adversaries and environments have Fear Features,
        especially powerful or consequential moves that the GM must
        spend Fear to activate.
      </p>
      <p className="text-xs text-slate-400 italic mt-1">Note: This Fear is in addition to any Fear the GM has
      previously spent to seize the spotlight or activate another
      action or ability.</p>
    </div>

    <div>
        <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">ADVERSARY ACTIONS</h5>
        <p>
            When play passes to the GM, the GM can make a GM move to
            spotlight an adversary. A spotlighted adversary can:
        </p>
        <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
            <li>Move within Close range and make a standard attack</li>
            <li>Move within Close range and use an adversary action</li>
            <li>Clear a condition</li>
            <li>Sprint within Far or Very Far range on the battlefield</li>
            <li>Do anything else the fiction demands or the GM deems appropriate</li>
        </ul>
        <p>
            The GM can spend additional Fear to spotlight additional
            adversaries. Once the GM has finished, the spotlight swings
            back to the PCs.
        </p>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">SPECIAL ROLLS</h4>
      <p>
        Some rolls have unique specifications or otherwise modify
        the action roll procedure: trait rolls, Spellcast Rolls, attack
        rolls, and damage rolls. Unless otherwise noted, you can apply
        any bonus, modifier, or effect to a special roll as if it were a
        standard action roll.
      </p>

      <div className="space-y-3 mt-2">
        <h5 className="text-md font-semibold text-sky-200 mb-1">TRAIT ROLLS</h5>
        <p>
          An action roll that specifies which character trait applies to it
          is called a trait roll. In the text of a feature or effect, a trait roll
          is referenced with the format “[Trait] Roll (Difficulty)” (e.g.,
          “Agility Roll (12)”). If the text of an effect doesn’t specify a
          trait roll’s Difficulty, the GM sets the Difficulty based on the
          circumstances.
        </p>
        <p>
          Features and effects that affect a trait roll also affect any
          action roll that uses the same trait, including attack rolls,
          Spellcast rolls, and standard action rolls.
        </p>
        <p className="text-xs text-slate-400 italic mt-1">Example: The katari’s ancestry feature “Feline Instincts,”
        which allows the katari to reroll an Agility Roll, can also
        be used on a standard action roll using Agility to traverse
        dangerous terrain or on an attack roll made with a
        weapon that uses Agility.</p>

        <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">SPELLCAST ROLLS</h5>
        <p>
          Spellcast Rolls are trait rolls that require you to use your
          Spellcast trait. Your Spellcast trait, if you have one, is
          determined by your subclass.
        </p>
        <p>
          Spellcast Rolls are only made when a character uses a feature
          that requires one. A successful Spellcast Roll activates the
          effect as described by the feature.
        </p>
        <p className="text-xs text-slate-400 italic mt-1">Notes:<br />
        A Spellcast Roll that can damage a target is also considered
        an attack roll.<br />
        When you cast a spell, the text tells you when the effect ends.
        The GM can spend a Fear to end a temporary effect. If your
        spell doesn’t specify when it ends, it ends when you choose or
        at a natural moment of the story. You can choose to end your
        spell early.<br />
        You can cast and maintain the effects of more than one spell
        at the same time.</p>

        <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">REACTION ROLLS</h5>
        <p>
          A reaction roll is made in response to an attack or a hazard,
          representing a character’s attempt to avoid or withstand an
          imminent effect.
        </p>
        <p>
          Reaction rolls work like action rolls, except they don’t generate
          Hope or Fear, don’t trigger additional GM moves, and other
          characters can’t aid you with Help an Ally.
        </p>
        <p>
          If you critically succeed on a reaction roll, you don’t clear
          a Stress or gain a Hope, but you do ignore any effects that
          would have impacted you on a success, such as taking
          damage or marking Stress.
        </p>

        <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">GROUP ACTION ROLLS</h5>
        <p>
          When multiple PCs take action together, the party chooses
          one PC to lead the action. Each other player then describes
          how their character collaborates on the task. The leader
          makes an action roll as usual, while the other players make
          reaction rolls using whichever traits they and the GM decide
          fit best.
        </p>
        <p>
          The lead character gains a +1 bonus to their lead action roll for
          each of these reaction rolls that succeeded and a −1 penalty
          for each these reaction rolls that failed.
        </p>

        <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">TAG TEAM ROLLS</h5>
        <p>
          Each player can, once per session, initiate a Tag Team Roll
          between their character and another PC by spending 3 Hope.
          The players work with one another to describe how they
          combine their actions in a unique and exciting way. Both
          players make separate action rolls; before resolving the roll’s
          outcome, choose one of the rolls to apply to both actions. On
          a roll with Hope, all PCs involved gain a Hope. On a roll with
          Fear, the GM gains a Fear token for each PC involved.
        </p>
        <p>
          On a successful Tag Team attack roll, both players roll damage
          and add the totals together to determine the damage dealt,
          which is then treated as if it came from a single source. If the
          attacks deal different types of damage, the players choose
          which type to deal.
        </p>
        <p className="text-xs text-slate-400 italic mt-1">Notes:<br />
        A Tag Team Roll counts as a single action roll for the
        purposes of any countdowns or features that track action
        rolls.<br />
        Though each player may only initiate one Tag Team Roll per
        session, one PC can be involved in multiple Tag Team Rolls.</p>
      </div>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">ADVANTAGE & DISADVANTAGE</h4>
      <p>
        Some features and effects let you roll with advantage or
        disadvantage on an action or reaction roll:
      </p>
      <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
        <li>
          <strong>Advantage</strong> represents an opportunity that you seize to
          increase your chances of success. When you roll with
          advantage, you roll a d6 advantage die with your dice pool
          and add its result to your total.
        </li>
        <li>
          <strong>Disadvantage</strong> represents an additional difficulty, hardship,
          or challenge you face when attempting an action. When
          you roll with disadvantage, you roll a d6 disadvantage die
          with your dice pool and subtract its result from your total.
        </li>
      </ul>
      <p>
        Advantage or disadvantage can be granted or imposed by
        mechanical triggers or at the GM’s discretion. When a PC aids
        you with Help an Ally, they roll their own advantage die and
        you add it to your total.
      </p>
      <p>
        Advantage and disadvantage dice cancel each out, one-forone, when they would be added to the same dice pool, so
        you’ll never roll both at the same time. If you have advantage
        or disadvantage from other sources that don’t affect your own
        dice pool, such as another player’s Help an Ally move, their
        effects stack with your rolled results.
      </p>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">HOPE & FEAR</h4>
      <p>
        Hope and Fear are metacurrencies representing the cosmic
        forces that shape the events of your table’s story. Hope
        powers PC abilities and features, while Fear powers the
        abilities of the GM and the adversaries and environments they
        control.
      </p>
      <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">HOPE</h5>
      <p>
        Every PC starts with 2 Hope at character creation and gains
        more throughout play. A PC can have a maximum of 6 Hope at
        one time, and Hope carries over between sessions.
      </p>
      <p>Players can spend Hope to:</p>
      <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
        <li>
          <strong>Help an Ally</strong><br />
          When you Help an Ally who is making an action roll,
          describe how you do so and roll an advantage die. Multiple
          players can spend Hope to help the same acting player,
          but that player only adds the highest result to their final
          total.
        </li>
        <li>
          <strong>Utilize an Experience</strong><br />
          When you Utilize an Experience on a relevant roll, add its
          modifier to the result. You can spend multiple Hope to
          utilize multiple Experiences.
        </li>
        <li>
          <strong>Initiate a Tag Team Roll</strong><br />
          Spend 3 Hope to initiate a Tag Team roll, combining the
          actions of two PCs into one impressive act of synergy.
          When you make a Tag Team roll, both players roll their
          action rolls and then choose which set of results to apply
          to the outcome.
        </li>
        <li>
          <strong>Activate a Hope Feature</strong><br />
          A Hope Feature is any effect that allows (or requires) you
          to spend a specified amount of Hope to activate it. Class
          Hope features are class-specific features, detailed on your
          character sheet, that cost 3 Hope to activate.
        </li>
      </ul>
      <p className="text-xs text-slate-400 italic mt-1">Note: When using a Hope Feature, if you rolled with Hope
      for that action, the Hope you gain from that roll can be spent
      on that feature (or toward it, if it requires spending multiple
      Hope).</p>

      <h5 className="text-md font-semibold text-sky-200 mt-3 mb-1">FEAR</h5>
      <p>
        The GM gains Fear whenever a player rolls with Fear and can
        spend Fear at any time to make or enhance a GM move or to
        use a Fear Feature. The GM can have up to 12 Fear at one
        time. Fear carries over between sessions.
      </p>
    </div>
    <p className="text-xs text-slate-400 italic mt-2">SRD Pages: 40-42</p>
  </div>
);

const MakingMovesTakingActionRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component now uses the static content defined above.
  return (
    <Card title={ruleDisplayName}>
      <MakingMovesTakingActionRulesContent />
    </Card>
  );
};

export default MakingMovesTakingActionRules;