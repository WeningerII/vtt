
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const StressRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-4">
    <p>
      Stress represents how much mental, physical, and emotional
      strain a character can endure. Some special abilities or effects
      require the character activating them to mark Stress, and
      the GM can require a PC to mark Stress as a GM move or to
      represent the cost, complication, or consequence of an action
      roll.
    </p>
    <p>
      When a character marks their last Stress, they become
      Vulnerable (see: Conditions) until they clear at least 1 Stress.
      When a character must mark 1 or more Stress but can’t, they
      mark 1 HP instead. A character can’t use a move that requires
      them to mark Stress if all of their Stress is marked.
    </p>
    <p>
      PCs can clear Stress by making downtime moves (see:
      Downtime). A PC’s maximum Stress is determined by their
      class, but they can increase it through advancements, abilities,
      and other effects.
    </p>
    <p className="text-xs text-slate-400 italic mt-2">SRD Page: 43</p>
  </div>
);

const StressRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component now uses static content for Stress rules.
  return (
    <Card title={ruleDisplayName}>
      <StressRulesContent />
    </Card>
  );
};

export default StressRules;
