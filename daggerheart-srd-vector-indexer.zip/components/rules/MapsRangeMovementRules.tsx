
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const MapsRangeMovementRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-4">
    <p>
      You can play Daggerheart using “theater of the mind” or maps
      and miniatures. The conversions below from abstract ranges
      to physical measurements assume 1 inch of map represents
      about 5 feet of fictional space.
    </p>
    <p>
      Daggerheart uses the following ranges to translate fictional
      positioning into relative distance for the purposes of targeting,
      movement, and other game mechanics:
    </p>
    <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
      <li>
        <strong className="text-sky-200">Melee:</strong> Close enough to touch, up to a few feet away.
      </li>
      <li>
        <strong className="text-sky-200">Very Close:</strong> Close enough to see fine details, about 5–10
        feet away. While in danger, a character can move, as part
        of their action, from Very Close range into Melee range. On
        a map: anything within the shortest length of a game card
        (2-3 inches).
      </li>
      <li>
        <strong className="text-sky-200">Close:</strong> Close enough to see prominent details, about
        10–30 feet away. While in danger, a character can move,
        as part of their action, from Close range into Melee range.
        On a map: anything within the length of a pencil (5-6 inches).
      </li>
      <li>
        <strong className="text-sky-200">Far:</strong> Close enough to see very little detail, about 30–100
        feet away. While in danger, a character must make an
        Agility Roll to safely move from Far range into Melee range.
        On a map: anything within the length of the long edge of a
        piece of copy paper (11–12 inches).
      </li>
      <li>
        <strong className="text-sky-200">Very Far:</strong> Too far to make out any details, about 100–300
        feet away. While in danger, a character must make an
        Agility Roll to safely move from Very Far range into Melee
        range. On a map: anything beyond Far range, but still within
        the bounds of the conflict or scene.
      </li>
      <li>
        <strong className="text-sky-200">Out of Range:</strong> Anything beyond a character’s Very Far
        range is Out of Range and usually can’t be targeted.
      </li>
    </ul>
    <p>
      Range is measured from the source of an effect, such as the
      attacker or spellcaster, to the target or object of an effect.
      A weapon, spell, ability, item, or other effect’s stated range is
      a maximum range; unless otherwise noted, it can be used at
      closer distances.
    </p>

    <div className="mt-4 pt-3 border-t border-slate-700">
      <h4 className="text-lg font-semibold text-sky-300 mb-2">Optional Rule: Defined Ranges</h4>
      <p>
        If your table would rather operate with more precise range
        rules, you can use a 1-inch grid battle map during combat.
        If you do, use the following guidelines for play:
      </p>
      <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
        <li>Melee: 1 square</li>
        <li>Very Close: 3 squares</li>
        <li>Close: 6 squares</li>
        <li>Far: 12 squares</li>
        <li>Very Far: 13+ squares</li>
        <li>Out of Range: Off the battlemap</li>
      </ul>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">MOVEMENT UNDER PRESSURE</h4>
      <p>
        When you’re under pressure or in danger and make an action
        roll, you can move to a location within Close range as part of
        that action. If you’re not already making an action roll, or if
        you want to move farther than your Close range, you need to
        succeed on an Agility Roll to safely reposition yourself.
      </p>
      <p>
        An adversary can move within Close range for free as part of
        an action, or within Very Far range as a separate action.
      </p>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">AREA OF EFFECT</h4>
      <p>
        Unless stated otherwise, all the targets of a group effect must
        be within Very Close range of a single origin point within your
        effect’s range.
      </p>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">LINE OF SIGHT & COVER</h4>
      <p>
        Unless stated otherwise, a ranged attacker must have line
        of sight to their intended target to make an attack roll. If a
        partial obstruction lies between the attacker and target, the
        target has cover. Attacks made through cover are rolled with
        disadvantage. If the obstruction is total, there is no line of
        sight.
      </p>
    </div>
    <p className="text-xs text-slate-400 italic mt-2">SRD Page: 44</p>
  </div>
);

const MapsRangeMovementRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component now uses static content.
  return (
    <Card title={ruleDisplayName}>
      <MapsRangeMovementRulesContent />
    </Card>
  );
};

export default MapsRangeMovementRules;
