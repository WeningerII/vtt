
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const TheSpotlightRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-4">
    <p>
      The spotlight is a symbol that represents the table’s
      attention—and therefore the immediate focus of both the
      narrative and the game mechanics. Any time a character
      or player becomes the focus of a scene, they “are in the
      spotlight” or “have the spotlight.”
    </p>
    <p>
      The spotlight moves around the table organically as scenes
      unfold unless a mechanical trigger determines where the
      spotlight goes next. For example, when a player fails an action
      roll, the mechanics prompt the GM to seize the spotlight and
      make a GM move.
    </p>
  </div>
);

const TheSpotlightRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component now uses static content for The Spotlight.
  // The original chunk "CORE MECHANICS > The Spotlight" might still be passed but this component displays this static content.
  return (
    <Card title={ruleDisplayName}>
      <TheSpotlightRulesContent />
    </Card>
  );
};

export default TheSpotlightRules;
