import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const DowntimeRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-4">
    <p>Between conflicts, the party can take a rest to recover expended resources and deepen their bonds. During a rest, each PC can make up to two downtime moves.</p>
    <p>When the party rests, they must choose between a short rest and a long rest. If a party takes three short rests in a row, their next rest must be a long rest.</p>
    <p>If a short rest is interrupted, such as by an adversary's attack, the characters don’t gain its benefits. If a long rest is interrupted, the characters only gain the benefits of a short rest.</p>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">SHORT REST</h4>
      <p>A short rest lasts enough time for the party to catch its breath, about an hour in-world. Each player can move domain cards between their loadout and vault for free, then choose twice from the following list of downtime moves (players can choose the same move twice):</p>
      <ul className="list-disc list-inside ml-4 my-2 space-y-1">
        <li><strong>Tend to Wounds:</strong> Clear 1d4+Tier Hit Points for yourself or an ally.</li>
        <li><strong>Clear Stress:</strong> Clear 1d4+Tier Stress.</li>
        <li><strong>Repair Armor:</strong> Clear 1d4+Tier Armor Slots from your or an ally’s armor.</li>
        <li><strong>Prepare:</strong> Describe how you prepare yourself for the path ahead, then gain a Hope. If you choose to Prepare with one or more members of your party, you each gain 2 Hope.</li>
      </ul>
      <p>At the end of a short rest, any features or effects with a limited number of uses per rest refresh and any features or effects that last until your next rest expire.</p>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">LONG REST</h4>
      <p>A long rest is when the characters make camp and relax or sleep for several in-game hours. Each player can move domain cards between their loadout and vault for free, then choose twice from the following list of downtime moves (players can choose the same move twice):</p>
      <ul className="list-disc list-inside ml-4 my-2 space-y-1">
        <li><strong>Tend to All Wounds:</strong> Clear all Hit Points for yourself or an ally.</li>
        <li><strong>Clear All Stress:</strong> Clear all Stress.</li>
        <li><strong>Repair All Armor:</strong> Clear all Armor Slots from your or an ally’s armor.</li>
        <li><strong>Prepare:</strong> Describe how you prepare for the next day’s adventure, then gain a Hope. If you choose to Prepare with one or more members of your party, you each gain 2 Hope.</li>
        <li><strong>Work on a Project:</strong> With GM approval, a PC may pursue a long-term project, such as deciphering an ancient text or crafting a new weapon. The first time they start a new project, assign it a countdown. Each time a PC makes the Work on a Project move, they either advance their project’s countdown automatically or make an action roll to advance it (GM’s choice).</li>
      </ul>
      <p>At the end of a long rest, any features or effects with a limited number of uses per rest or per long rest refresh and any features or effects that last until your next rest or until your next long rest expire.</p>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">DOWNTIME CONSEQUENCES</h4>
      <p>On a short rest, the GM gains 1d4 Fear. On a long rest, they gain Fear equal to 1d4 + the number of PCs, and they can advance a long-term countdown of their choice.</p>
    </div>
  </div>
);

const DowntimeRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component now uses static content.
  return (
    <Card title={ruleDisplayName}>
      <DowntimeRulesContent />
    </Card>
  );
};

export default DowntimeRules;
