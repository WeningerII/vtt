
import React from 'react';
import { Card } from '../common/Card';
import InteractiveTextRenderer from '../common/InteractiveTextRenderer';
import { RuleDisplayComponentProps } from '../GameRules';

const flowOfTheGameText = `Daggerheart is a conversation. The GM describes fictional scenarios involving the PCs, and the players take turns describing how their characters react. The goal of every person at the table is to build upon everyone else’s ideas and collaboratively tell a satisfying story. The system facilitates this collaborative process by providing structure to the conversation and mechanics for resolving moments of tension where fate or fortune determine the outcome of events.`;

const playerPrinciplesText = `To get the most out of Daggerheart, we recommend players keep the following principles and practices in mind throughout each session:`;

const principlesList = [
  "Be a fan of your character and their journey.",
  "Spotlight your friends.",
  "Address the characters and address the players.",
  "Build the world together.",
  "Play to find out what happens.",
  "Hold on gently."
];

const bestPracticesList = [
  "Embrace danger.",
  "Use your resources.",
  "Tell the story.",
  "Discover your character."
];

const FlowOfTheGameRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName, interactiveTerms, onTermClick }) => {
  return (
    <Card title={ruleDisplayName}>
      <div className="text-slate-300 space-y-4">
        <p><InteractiveTextRenderer text={flowOfTheGameText} terms={interactiveTerms} onTermClick={onTermClick} /></p>

        <div>
          <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">PLAYER PRINCIPLES & BEST PRACTICES</h4>
          <p><InteractiveTextRenderer text={playerPrinciplesText} terms={interactiveTerms} onTermClick={onTermClick} /></p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 mt-3">
            <div>
              <h5 className="text-md font-semibold text-sky-200 mb-1">PRINCIPLES</h5>
              <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
                {principlesList.map((item, index) => (
                  <li key={`principle-${index}`}><InteractiveTextRenderer text={item} terms={interactiveTerms} onTermClick={onTermClick} /></li>
                ))}
              </ul>
            </div>
            <div>
              <h5 className="text-md font-semibold text-sky-200 mb-1">BEST PRACTICES</h5>
              <ul className="list-disc list-inside ml-4 space-y-1 text-sm">
                {bestPracticesList.map((item, index) => (
                  <li key={`practice-${index}`}><InteractiveTextRenderer text={item} terms={interactiveTerms} onTermClick={onTermClick} /></li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default FlowOfTheGameRules;
