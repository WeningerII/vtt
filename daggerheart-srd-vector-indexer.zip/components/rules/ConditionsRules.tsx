
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const ConditionsRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-4">
    <p>
      Conditions are effects that grant specific benefits or
      drawbacks to the target they are attached to.
    </p>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">STANDARD CONDITIONS</h4>
      <p>Daggerheart has three standard conditions:</p>
      <ul className="list-none my-2 space-y-3 pl-2">
        <li>
          <strong className="block text-sky-200">HIDDEN</strong>
          <p className="text-sm">
            While you’re out of sight from all enemies and they
            don’t otherwise know your location, you gain the Hidden
            condition. Any rolls against a Hidden creature have
            disadvantage. After an adversary moves to where they
            would see you, you move into their line of sight, or you
            make an attack, you are no longer Hidden.
          </p>
        </li>
        <li>
          <strong className="block text-sky-200">RESTRAINED</strong>
          <p className="text-sm">
            Restrained characters can’t move, but you can still take
            actions from their current position.
          </p>
        </li>
        <li>
          <strong className="block text-sky-200">VULNERABLE</strong>
          <p className="text-sm">
            When a creature is Vulnerable, all rolls targeting them have
            advantage.
          </p>
        </li>
      </ul>
      <p>
        Some features can apply special or unique conditions, which
        work as described in the feature text.
      </p>
      <p>
        Unless otherwise noted, the same condition can’t be applied
        more than once to the same target.
      </p>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">TEMPORARY TAGS & SPECIAL CONDITIONS</h4>
      <p>
        The <strong className="text-sky-200">temporary</strong> tag denotes a condition or effect that the
        affected creature can clear by making a move against it. When
        an affected PC makes a move to clear a temporary condition
        or effect, it normally requires a successful action roll using
        an appropriate trait. When an affected adversary makes a
        move to clear a temporary condition or effect, the GM puts
        the spotlight on the adversary and describes how they do it;
        this doesn’t require a roll but it does use up that adversary’s
        spotlight.
      </p>
      <p>
        Special conditions are only cleared when specific requirements
        are met, such as completing a certain action or using a
        particular item. The requirements for clearing these conditions
        are stated in the text of the effect that applies the condition.
      </p>
    </div>
    <p className="text-xs text-slate-400 italic mt-2">SRD Page: 45</p>
  </div>
);

const ConditionsRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component now uses static content for Conditions.
  // The original chunk for "CORE MECHANICS > Conditions" might be passed, but this component focuses on displaying the provided static text.
  return (
    <Card title={ruleDisplayName}>
      <ConditionsRulesContent />
    </Card>
  );
};

export default ConditionsRules;
