
import React from 'react';
import { Card } from '../common/Card';
import { RuleDisplayComponentProps } from '../GameRules';

const CombatRulesContent: React.FC = () => (
  <div className="text-slate-300 space-y-4">
    <p>
      Though Daggerheart relies on the same flow of collaborative
      storytelling in and out of combat, physical conflicts rely
      more heavily on several key mechanics related to attacking,
      maneuvering, and taking damage.
    </p>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">EVASION</h4>
      <p>
        Evasion represents a character’s ability to avoid attacks and
        other unwanted effects. Any roll made against a PC has a
        Difficulty equal to the target’s Evasion. A PC’s base Evasion
        is determined by their class, but can be modified by domain
        cards, equipment, conditions, and other effects.
      </p>
      <p className="text-xs text-slate-400 italic mt-1">
        Note: attacks rolled against adversaries use the target’s
        Difficulty instead of Evasion.
      </p>
    </div>

    <div>
      <h4 className="text-lg font-semibold text-sky-300 mt-4 mb-2">HIT POINTS & DAMAGE THRESHOLDS</h4>
      <p>
        Hit Points (HP) represent a character’s ability to withstand
        physical injury. When a character takes damage, they mark 1
        to 3 HP, based on their damage thresholds:
      </p>
      <ul className="list-disc list-inside ml-4 my-2 space-y-1 text-sm">
        <li>
          If the final damage is at or above the character’s <strong className="text-sky-200">Severe
          damage threshold</strong>, they mark 3 HP.
        </li>
        <li>
          If the final damage is at or above the character’s <strong className="text-sky-200">Major
          damage threshold</strong> but below their Severe damage
          threshold, they mark 2 HP.
        </li>
        <li>
          If the final damage is below the character’s <strong className="text-sky-200">Major damage
          threshold</strong>, they mark 1 HP.
        </li>
        <li>
          If incoming damage is ever reduced to 0 or less, no HP is
          marked.
        </li>
      </ul>
      <p>
        A PC’s damage thresholds are calculated by adding their level
        to the listed damage thresholds of their equipped armor. A
        PC’s starting HP is based on their class, but they can gain
        additional Hit Points through advancements, features, and
        other effects.
      </p>
      <p>
        An adversary’s Damage Thresholds and HP are listed in their
        stat blocks.
      </p>
      <p>
        When a character marks their last Hit Point, they fall. If a PC
        falls, they make a death move.
      </p>
      <p>
        Characters can clear Hit Points by taking downtime moves
        (see: Downtime) or by activating relevant special abilities or
        effects.
      </p>
    </div>

    <div className="mt-4 pt-3 border-t border-slate-700">
      <h5 className="text-md font-semibold text-sky-200 mb-1">Optional Rule: Massive Damage</h5>
      <p>
        If a character ever takes damage equal to twice their
        Severe threshold, they mark 4 HP instead of 3.
      </p>
    </div>
    <p className="text-xs text-slate-400 italic mt-2">SRD Page: 43</p>
  </div>
);

const CombatRules: React.FC<RuleDisplayComponentProps> = ({ ruleDisplayName }) => {
  // The 'chunk' prop is available but this component now uses static content for Combat rules.
  return (
    <Card title={ruleDisplayName}>
      <CombatRulesContent />
    </Card>
  );
};

export default CombatRules;
