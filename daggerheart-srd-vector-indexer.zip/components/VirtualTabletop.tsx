
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { VTTToken, VTTGridConfig, VTTTurn } from '../types';
import { Card } from './common/Card';
import { Button } from './common/Button';
import { Input } from './common/Input';
import { Select } from './common/Select'; // If needed for color selection or other dropdowns
import { nanoid } from 'https://esm.sh/nanoid@5.0.7'; // Using esm.sh for nanoid


const DEFAULT_CELL_SIZE = 40;
const INITIAL_GRID_ROWS = 20;
const INITIAL_GRID_COLS = 30;
const TOKEN_COLORS = ['#EF4444', '#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#6EE7B7', '#FDE047'];

const VirtualTabletop: React.FC = () => {
  const [gridConfig, setGridConfig] = useState<VTTGridConfig>({
    rows: INITIAL_GRID_ROWS,
    cols: INITIAL_GRID_COLS,
    cellSize: DEFAULT_CELL_SIZE,
  });
  const [tokens, setTokens] = useState<VTTToken[]>([]);
  const [selectedTokenId, setSelectedTokenId] = useState<string | null>(null);
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [zoomLevel, setZoomLevel] = useState(1);
  const [isPanning, setIsPanning] = useState(false);
  const [lastPanPosition, setLastPanPosition] = useState({ x: 0, y: 0 });
  const svgRef = useRef<SVGSVGElement>(null);
  const [draggingTokenId, setDraggingTokenId] = useState<string | null>(null);
  
  const [turnOrder, setTurnOrder] = useState<VTTTurn[]>([]);
  const [currentTurnIndex, setCurrentTurnIndex] = useState<number>(-1);
  const [newTurnName, setNewTurnName] = useState('');

  const [diceRollResult, setDiceRollResult] = useState<string | null>(null);
  const [showAddTokenModal, setShowAddTokenModal] = useState(false);
  const [newTokenColor, setNewTokenColor] = useState(TOKEN_COLORS[0]);
  const [newTokenLabel, setNewTokenLabel] = useState('');


  const handleAddToken = () => {
    const newToken: VTTToken = {
      id: nanoid(),
      x: Math.floor(gridConfig.cols / 2),
      y: Math.floor(gridConfig.rows / 2),
      color: newTokenColor,
      label: newTokenLabel || undefined,
      size: 1,
    };
    setTokens(prev => [...prev, newToken]);
    setShowAddTokenModal(false);
    setNewTokenLabel(''); // Reset for next token
  };

  const handleRemoveSelectedToken = () => {
    if (selectedTokenId) {
      setTokens(prev => prev.filter(token => token.id !== selectedTokenId));
      setSelectedTokenId(null);
    }
  };

  const handleGridConfigChange = (field: keyof VTTGridConfig, value: string) => {
    const numValue = parseInt(value, 10);
    if (!isNaN(numValue) && numValue > 0) {
      setGridConfig(prev => ({ ...prev, [field]: numValue }));
    }
  };

  const handleMouseDownOnBackground = (e: React.MouseEvent<SVGSVGElement>) => {
    if (e.target === svgRef.current) { // Ensure click is on background
      setIsPanning(true);
      setLastPanPosition({ x: e.clientX, y: e.clientY });
      setSelectedTokenId(null); // Deselect token when clicking background
    }
  };
  
  const handleTokenMouseDown = (e: React.MouseEvent, tokenId: string) => {
    e.stopPropagation(); // Prevent background panning when starting drag on token
    setSelectedTokenId(tokenId);
    setDraggingTokenId(tokenId);
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (isPanning && svgRef.current) {
      const dx = e.clientX - lastPanPosition.x;
      const dy = e.clientY - lastPanPosition.y;
      setPanOffset(prev => ({ x: prev.x + dx, y: prev.y + dy }));
      setLastPanPosition({ x: e.clientX, y: e.clientY });
    } else if (draggingTokenId && svgRef.current) {
      const CTM = svgRef.current.getScreenCTM();
      if (CTM) {
        const svgPoint = svgRef.current.createSVGPoint();
        svgPoint.x = e.clientX;
        svgPoint.y = e.clientY;
        const { x: svgX, y: svgY } = svgPoint.matrixTransform(CTM.inverse());

        const gridX = Math.round((svgX - panOffset.x / zoomLevel) / (gridConfig.cellSize) - 0.5);
        const gridY = Math.round((svgY - panOffset.y / zoomLevel) / (gridConfig.cellSize) - 0.5);
        
        setTokens(prevTokens => prevTokens.map(token => 
          token.id === draggingTokenId ? { ...token, x: Math.max(0, Math.min(gridConfig.cols - token.size, gridX)), y: Math.max(0, Math.min(gridConfig.rows - token.size, gridY)) } : token
        ));
      }
    }
  }, [isPanning, lastPanPosition, draggingTokenId, panOffset.x, panOffset.y, zoomLevel, gridConfig.cellSize, gridConfig.cols, gridConfig.rows]);

  const handleMouseUp = useCallback(() => {
    setIsPanning(false);
    setDraggingTokenId(null);
  }, []);

  useEffect(() => {
    if (isPanning || draggingTokenId) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    } else {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isPanning, draggingTokenId, handleMouseMove, handleMouseUp]);

  const handleZoom = (delta: number) => {
    setZoomLevel(prev => Math.max(0.1, Math.min(3, prev + delta)));
  };
  
  const handleWheel = (e: React.WheelEvent<SVGSVGElement>) => {
    e.preventDefault();
    const zoomDelta = e.deltaY > 0 ? -0.1 : 0.1; // Adjust sensitivity
    handleZoom(zoomDelta);
  };


  const resetView = () => {
    setPanOffset({ x: 0, y: 0 });
    setZoomLevel(1);
  };
  
  const clearBoard = () => {
    setTokens([]);
    setSelectedTokenId(null);
    setTurnOrder([]);
    setCurrentTurnIndex(-1);
  }

  // Turn Tracker Logic
  const handleAddTurnEntry = () => {
    if (newTurnName.trim()) {
      setTurnOrder(prev => [...prev, { id: nanoid(), name: newTurnName.trim(), type: 'player' }]);
      setNewTurnName('');
    }
  };

  const handleRemoveTurnEntry = (id: string) => {
    setTurnOrder(prev => prev.filter(turn => turn.id !== id));
    // Adjust currentTurnIndex if necessary
    if (turnOrder.length -1 === currentTurnIndex && turnOrder[currentTurnIndex]?.id === id){
        setCurrentTurnIndex(prev => prev > 0 ? prev -1 : -1);
    } else if (turnOrder.findIndex(t=>t.id ===id) < currentTurnIndex) {
        setCurrentTurnIndex(prev => prev -1);
    }
  };

  const handleNextTurn = () => {
    if (turnOrder.length > 0) {
      setCurrentTurnIndex(prev => (prev + 1) % turnOrder.length);
    }
  };

  // Dice Roller Logic
  const rollDice = (sides: number, count: number = 1) => {
    let total = 0;
    let rolls = [];
    for (let i = 0; i < count; i++) {
      const roll = Math.floor(Math.random() * sides) + 1;
      rolls.push(roll);
      total += roll;
    }
    setDiceRollResult(`${count}d${sides}: ${rolls.join(' + ')} = ${total}`);
  };

  const mapWidth = gridConfig.cols * gridConfig.cellSize;
  const mapHeight = gridConfig.rows * gridConfig.cellSize;

  return (
    <div className="flex flex-col md:flex-row gap-4 max-w-full mx-auto p-4 h-[calc(100vh-200px)]"> {/* Adjust height as needed */}
      {/* Controls Panel */}
      <Card title="VTT Controls" className="w-full md:w-80 flex-shrink-0 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-800">
        <div className="space-y-4">
          {/* Grid Settings */}
          <fieldset className="border border-slate-600 p-3 rounded-md">
            <legend className="text-sm font-medium text-sky-300 px-1">Grid Settings</legend>
            <Input label="Rows" type="number" value={gridConfig.rows.toString()} onChange={e => handleGridConfigChange('rows', e.target.value)} wrapperClassName="mb-2" />
            <Input label="Columns" type="number" value={gridConfig.cols.toString()} onChange={e => handleGridConfigChange('cols', e.target.value)} wrapperClassName="mb-2" />
            <Input label="Cell Size (px)" type="number" value={gridConfig.cellSize.toString()} onChange={e => handleGridConfigChange('cellSize', e.target.value)} />
          </fieldset>

          {/* Token Management */}
          <fieldset className="border border-slate-600 p-3 rounded-md">
            <legend className="text-sm font-medium text-sky-300 px-1">Tokens</legend>
            <Button onClick={() => setShowAddTokenModal(true)} className="w-full mb-2">Add Token</Button>
            <Button onClick={handleRemoveSelectedToken} disabled={!selectedTokenId} variant="danger" className="w-full">Remove Selected</Button>
          </fieldset>
          
          {/* View Controls */}
           <fieldset className="border border-slate-600 p-3 rounded-md">
            <legend className="text-sm font-medium text-sky-300 px-1">View Controls</legend>
            <div className="grid grid-cols-2 gap-2">
                <Button onClick={() => handleZoom(0.1)}>Zoom In</Button>
                <Button onClick={() => handleZoom(-0.1)}>Zoom Out</Button>
                <Button onClick={resetView} className="col-span-2">Reset View</Button>
            </div>
          </fieldset>

          {/* Dice Roller */}
          <fieldset className="border border-slate-600 p-3 rounded-md">
            <legend className="text-sm font-medium text-sky-300 px-1">Dice Roller</legend>
            <div className="grid grid-cols-3 gap-2 mb-2">
              {[4, 6, 8, 10, 12, 20].map(sides => (
                <Button key={`d${sides}`} onClick={() => rollDice(sides)} size="sm">d{sides}</Button>
              ))}
            </div>
            {diceRollResult && <p className="text-center text-sky-300 bg-slate-700 p-2 rounded text-sm">{diceRollResult}</p>}
          </fieldset>

          {/* Turn Tracker */}
          <fieldset className="border border-slate-600 p-3 rounded-md">
            <legend className="text-sm font-medium text-sky-300 px-1">Turn Tracker</legend>
            <div className="flex gap-2 mb-2">
              <Input type="text" placeholder="Character/NPC Name" value={newTurnName} onChange={e => setNewTurnName(e.target.value)} wrapperClassName="flex-grow" />
              <Button onClick={handleAddTurnEntry} size="sm">+</Button>
            </div>
            <ul className="max-h-32 overflow-y-auto mb-2 text-sm space-y-1">
              {turnOrder.map((turn, index) => (
                <li key={turn.id} className={`flex justify-between items-center p-1.5 rounded ${index === currentTurnIndex ? 'bg-sky-700 text-white' : 'bg-slate-700'}`}>
                  <span>{turn.name}</span>
                  <Button onClick={() => handleRemoveTurnEntry(turn.id)} variant="danger" size="sm" className="px-1.5 py-0.5 text-xs">X</Button>
                </li>
              ))}
            </ul>
            <Button onClick={handleNextTurn} disabled={turnOrder.length === 0} className="w-full">Next Turn</Button>
          </fieldset>
          
          <Button onClick={clearBoard} variant="danger" className="w-full mt-4">Clear Board & Turns</Button>
        </div>
      </Card>

      {/* Grid Area */}
      <div className="flex-grow bg-slate-700 border border-slate-600 rounded-lg shadow-lg overflow-hidden relative cursor-grab">
        <svg 
          ref={svgRef} 
          width="100%" 
          height="100%" 
          onWheel={handleWheel}
          onMouseDownCapture={handleMouseDownOnBackground}
          className={isPanning ? 'cursor-grabbing' : ''}
        >
          <defs>
            <pattern id="gridPattern" width={gridConfig.cellSize} height={gridConfig.cellSize} patternUnits="userSpaceOnUse"
              style={{ transform: `scale(${zoomLevel}) translate(${panOffset.x / zoomLevel / gridConfig.cellSize}, ${panOffset.y / zoomLevel / gridConfig.cellSize})` }}
            >
              <path d={`M ${gridConfig.cellSize} 0 L 0 0 0 ${gridConfig.cellSize}`} fill="none" stroke="#525f7f" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#gridPattern)" />
          
          <g style={{ transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${zoomLevel})` }}>
            {/* Tokens */}
            {tokens.map(token => (
              <g 
                key={token.id} 
                transform={`translate(${token.x * gridConfig.cellSize + gridConfig.cellSize / 2}, ${token.y * gridConfig.cellSize + gridConfig.cellSize / 2})`}
                onMouseDown={(e) => handleTokenMouseDown(e, token.id)}
                className="cursor-pointer hover:opacity-80 transition-opacity"
                aria-label={token.label || `Token ${token.id}`}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setSelectedTokenId(token.id); }}
              >
                <circle
                  cx="0"
                  cy="0"
                  r={(gridConfig.cellSize / 2 * 0.8) * token.size}
                  fill={token.color}
                  stroke={selectedTokenId === token.id ? 'white' : '#1E293B'} // Highlight selected
                  strokeWidth={selectedTokenId === token.id ? 2 / zoomLevel : 1 / zoomLevel}
                />
                {token.label && (
                  <text 
                    x="0" y="0" 
                    dy=".3em" // Adjust for vertical centering
                    textAnchor="middle" 
                    fill="#FFFFFF" 
                    fontSize={gridConfig.cellSize * 0.3 / zoomLevel}
                    className="pointer-events-none select-none"
                  >
                    {token.label.substring(0,2).toUpperCase()}
                  </text>
                )}
              </g>
            ))}
          </g>
        </svg>
      </div>
      
      {/* Add Token Modal */}
      {showAddTokenModal && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <Card title="Add New Token" className="w-full max-w-sm">
            <Input 
              label="Token Label (Optional)" 
              value={newTokenLabel} 
              onChange={(e) => setNewTokenLabel(e.target.value)} 
              placeholder="e.g., PC1, G1"
              wrapperClassName="mb-4" 
            />
            <div className="mb-4">
                <label className="block text-sm font-medium text-slate-300 mb-1">Token Color</label>
                <div className="flex flex-wrap gap-2">
                    {TOKEN_COLORS.map(color => (
                        <button
                            key={color}
                            type="button"
                            onClick={() => setNewTokenColor(color)}
                            className={`w-8 h-8 rounded-full border-2 ${newTokenColor === color ? 'border-sky-400 ring-2 ring-sky-300' : 'border-transparent hover:border-slate-400'}`}
                            style={{ backgroundColor: color }}
                            aria-label={`Select color ${color}`}
                        />
                    ))}
                </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <Button variant="secondary" onClick={() => setShowAddTokenModal(false)}>Cancel</Button>
              <Button onClick={handleAddToken}>Add Token</Button>
            </div>
          </Card>
        </div>
      )}

    </div>
  );
};

export default VirtualTabletop;
