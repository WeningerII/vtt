
import React, { useState, useMemo } from 'react';
import { SRDData, Weapon, Armor, LootItemData, ConsumableItemData, InteractiveTermConfig } from '../types'; // Updated import
import { Card } from './common/Card';
// Button is not used directly, removed to avoid linting errors if any.
import { Select } from './common/Select';
import { Input } from './common/Input';
import InteractiveTextRenderer from './common/InteractiveTextRenderer';

interface EquipmentReferenceProps {
  srdData: SRDData;
  interactiveTerms: InteractiveTermConfig[]; // Updated prop type
  onTermClick: (term: InteractiveTermConfig) => void; // Updated prop type
}

type EquipmentCategory = 'all' | 'weapons' | 'armor' | 'loot' | 'consumables';
type WeaponSubCategory = 'all' | 'primary' | 'secondary' | 'wheelchair';

const WeaponIntroductoryText: React.FC<{interactiveTerms: InteractiveTermConfig[], onTermClick: (term: InteractiveTermConfig) => void}> = ({interactiveTerms, onTermClick}) => (
  <Card className="mb-6 bg-slate-800 border-slate-700">
    <h4 className="text-xl font-semibold text-sky-300 mb-3">Understanding Weapons</h4>
    <div className="text-slate-300 space-y-3 text-sm">
      <p><InteractiveTextRenderer text="All weapons have a tier, trait, range, damage die, damage type, and burden. Some weapons also have a feature." terms={interactiveTerms} onTermClick={onTermClick}/></p>
      
      <div>
        <strong className="text-sky-200 block">CATEGORY</strong>
        <p><InteractiveTextRenderer text="A weapon’s category specifies whether it is a Primary or Secondary weapon. Your character can only equip up to one weapon of each category at a time." terms={interactiveTerms} onTermClick={onTermClick}/></p>
      </div>
      
      <div>
        <strong className="text-sky-200 block">TRAIT</strong>
        <p><InteractiveTextRenderer text="A weapon’s trait specifies which trait to use when making an attack roll with it." terms={interactiveTerms} onTermClick={onTermClick}/></p>
      </div>

      <div>
        <strong className="text-sky-200 block">RANGE</strong>
        <p><InteractiveTextRenderer text="A weapon’s range specifies the maximum distance between the attacker and their target when attacking with it." terms={interactiveTerms} onTermClick={onTermClick}/></p>
      </div>

      <div>
        <strong className="text-sky-200 block">DAMAGE</strong>
        <p><InteractiveTextRenderer text="A weapon’s damage indicates the size of the damage dice you roll on a successful attack with it; you roll a number of dice equal to your Proficiency. If the damage includes a flat modifier, this number is added to the total damage rolled, but is not altered or affected by Proficiency." terms={interactiveTerms} onTermClick={onTermClick}/></p>
      </div>

      <div>
        <strong className="text-sky-200 block">DAMAGE TYPE</strong>
        <p><InteractiveTextRenderer text="A weapon’s damage type indicates whether it deals physical or magic damage. Weapons that deal magic damage can only be wielded by characters with a Spellcast trait." terms={interactiveTerms} onTermClick={onTermClick}/></p>
      </div>

      <div>
        <strong className="text-sky-200 block">BURDEN</strong>
        <p><InteractiveTextRenderer text="A weapon’s burden indicates how many hands it occupies when equipped. Your character’s maximum burden is 2 hands." terms={interactiveTerms} onTermClick={onTermClick}/></p>
      </div>
      
      <div>
        <strong className="text-sky-200 block">FEATURE</strong>
        <p><InteractiveTextRenderer text="A weapon’s feature is a special rule that stays in effect while the weapon is equipped." terms={interactiveTerms} onTermClick={onTermClick}/></p>
      </div>

      <p className="italic text-slate-400"><InteractiveTextRenderer text="You can throw an equipped weapon at a target within Very Close range, making the attack roll with Finesse. On a success, deal damage as usual for that weapon. Once thrown, the weapon is no longer considered equipped. Until you retrieve and re-equip it, you can’t attack with it or benefit from its features." terms={interactiveTerms} onTermClick={onTermClick}/></p>
    </div>
  </Card>
);


const EquipmentReference: React.FC<EquipmentReferenceProps> = ({ srdData, interactiveTerms, onTermClick }) => {
  const [activeCategory, setActiveCategory] = useState<EquipmentCategory>('weapons');
  const [weaponSubCategory, setWeaponSubCategory] = useState<WeaponSubCategory>('all');
  const [selectedTier, setSelectedTier] = useState<string>(''); 
  const [searchTerm, setSearchTerm] = useState<string>('');

  const TIER_OPTIONS = ['', '1', '2', '3', '4'];

  const isCombatWheelchair = (weapon: Weapon) => weapon.name.toLowerCase().includes('wheelchair');

  const filteredWeapons = useMemo(() => {
    return (srdData.weapons || []).filter(weapon => {
      const tierMatch = selectedTier ? weapon.tier === parseInt(selectedTier) : true;
      const termMatch = searchTerm ? 
        weapon.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        weapon.feature.toLowerCase().includes(searchTerm.toLowerCase()) ||
        weapon.trait.toLowerCase().includes(searchTerm.toLowerCase())
        : true;
      
      let subCategoryMatch = true;
      if (weaponSubCategory === 'primary') subCategoryMatch = weapon.category === 'Primary' && !isCombatWheelchair(weapon);
      else if (weaponSubCategory === 'secondary') subCategoryMatch = weapon.category === 'Secondary';
      else if (weaponSubCategory === 'wheelchair') subCategoryMatch = isCombatWheelchair(weapon);
      
      return tierMatch && termMatch && subCategoryMatch;
    });
  }, [srdData.weapons, selectedTier, searchTerm, weaponSubCategory]);

  const filteredArmor = useMemo(() => {
    return (srdData.armor || []).filter(armor => {
      const tierMatch = selectedTier ? armor.tier === parseInt(selectedTier) : true;
      const termMatch = searchTerm ? 
        armor.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        armor.feature.toLowerCase().includes(searchTerm.toLowerCase())
        : true;
      return tierMatch && termMatch;
    });
  }, [srdData.armor, selectedTier, searchTerm]);

  const filteredLoot = useMemo(() => {
    return (srdData.lootItems || []).filter(item => {
      const termMatch = searchTerm ? 
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        item.description.toLowerCase().includes(searchTerm.toLowerCase())
        : true;
      return termMatch;
    });
  }, [srdData.lootItems, searchTerm]);

  const filteredConsumables = useMemo(() => {
    return (srdData.consumableItems || []).filter(item => {
      const termMatch = searchTerm ? 
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        item.description.toLowerCase().includes(searchTerm.toLowerCase())
        : true;
      return termMatch;
    });
  }, [srdData.consumableItems, searchTerm]);

  const renderWeaponCard = (weapon: Weapon) => (
    <Card 
      key={weapon.id} 
      className="flex flex-col h-full"
      titleClassName="text-base sm:text-lg"
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="text-sky-300 font-semibold text-base sm:text-lg">{weapon.name}</h3>
        <span className="text-xs bg-slate-700 px-2 py-1 rounded-full text-sky-200 whitespace-nowrap">Tier {weapon.tier}</span>
      </div>
      <div className="text-xs text-slate-400 space-y-0.5 flex-grow">
        <p><strong>Category:</strong> {isCombatWheelchair(weapon) ? 'Combat Wheelchair' : weapon.category}</p>
        <p><strong>Trait:</strong> <InteractiveTextRenderer text={weapon.trait} terms={interactiveTerms} onTermClick={onTermClick}/></p>
        <p><strong>Range:</strong> <InteractiveTextRenderer text={weapon.range} terms={interactiveTerms} onTermClick={onTermClick}/></p>
        <p><strong>Damage:</strong> <InteractiveTextRenderer text={weapon.damage} terms={interactiveTerms} onTermClick={onTermClick}/></p>
        <p><strong>Burden:</strong> {weapon.burden}</p>
        {weapon.feature && weapon.feature !== "—" && <p className="mt-1"><strong>Feature:</strong> <span className="italic"><InteractiveTextRenderer text={weapon.feature} terms={interactiveTerms} onTermClick={onTermClick}/></span></p>}
      </div>
    </Card>
  );

  const renderArmorCard = (armorItem: Armor) => (
     <Card 
      key={armorItem.id} 
      className="flex flex-col h-full"
      titleClassName="text-base sm:text-lg"
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="text-sky-300 font-semibold text-base sm:text-lg">{armorItem.name}</h3>
        <span className="text-xs bg-slate-700 px-2 py-1 rounded-full text-sky-200 whitespace-nowrap">Tier {armorItem.tier}</span>
      </div>
      <div className="text-xs text-slate-400 space-y-0.5 flex-grow">
        <p><strong>Base Score:</strong> {armorItem.baseScore}</p>
        <p><strong>Base Thresholds:</strong> <InteractiveTextRenderer text={armorItem.baseThresholds} terms={interactiveTerms} onTermClick={onTermClick}/></p>
        {armorItem.feature && armorItem.feature !== "—" && <p className="mt-1"><strong>Feature:</strong> <span className="italic"><InteractiveTextRenderer text={armorItem.feature} terms={interactiveTerms} onTermClick={onTermClick}/></span></p>}
      </div>
    </Card>
  );

  const renderItemCard = (item: LootItemData | ConsumableItemData, type: 'Loot' | 'Consumable') => (
    <Card 
      key={item.id} 
      className="flex flex-col h-full"
      titleClassName="text-base sm:text-lg"
    >
        <h3 className="text-sky-300 font-semibold text-base sm:text-lg mb-1">{item.name}</h3>
      <div className="text-xs text-slate-400 space-y-0.5 flex-grow">
        <p className="whitespace-pre-line"><InteractiveTextRenderer text={item.description} terms={interactiveTerms} onTermClick={onTermClick}/></p>
        {item.srdPage && <p className="mt-1 text-slate-500">SRD p.{item.srdPage} {item.srdRoll && item.srdRoll !== -1 ? `(Roll: ${item.srdRoll})` : ''}</p>}
      </div>
    </Card>
  );

  return (
    <div className="max-w-7xl mx-auto">
      <h2 className="text-3xl font-bold text-sky-400 text-center mb-8" style={{ fontFamily: "'Orbitron', sans-serif" }}>
        Equipment Reference
      </h2>

      <Card className="mb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 items-end">
          <Input
            label="Search All Equipment"
            type="text"
            placeholder="E.g., Sword, Healing, Heavy..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            wrapperClassName="sm:col-span-2 md:col-span-1"
          />
          <Select
            label="Filter by Category"
            value={activeCategory}
            onChange={(e) => {
              const newCategory = e.target.value as EquipmentCategory;
              setActiveCategory(newCategory);
              if (newCategory === 'loot' || newCategory === 'consumables') {
                setSelectedTier('');
              }
              if (newCategory !== 'weapons' && newCategory !== 'all') {
                setWeaponSubCategory('all');
              }
            }}
          >
            <option value="all">All Equipment</option>
            <option value="weapons">Weapons</option>
            <option value="armor">Armor</option>
            <option value="loot">Loot</option>
            <option value="consumables">Consumables</option>
          </Select>

          {(activeCategory === 'all' || activeCategory === 'weapons' || activeCategory === 'armor') && (
            <Select
              label="Filter by Tier"
              value={selectedTier}
              onChange={(e) => setSelectedTier(e.target.value)}
            >
              {TIER_OPTIONS.map(tier => (
                <option key={`tier-${tier}`} value={tier}>{tier === '' ? 'All Tiers' : `Tier ${tier}`}</option>
              ))}
            </Select>
          )}
          {(activeCategory === 'all' || activeCategory === 'weapons') && (
             <Select
              label="Weapon Type"
              value={weaponSubCategory}
              onChange={(e) => setWeaponSubCategory(e.target.value as WeaponSubCategory)}
            >
              <option value="all">All Weapons</option>
              <option value="primary">Primary</option>
              <option value="secondary">Secondary</option>
              <option value="wheelchair">Combat Wheelchairs</option>
            </Select>
          )}
        </div>
      </Card>

      {(activeCategory === 'all' || activeCategory === 'weapons') && (
        <section className="mb-10">
          <h3 className="text-2xl font-semibold text-sky-300 mb-4 border-b border-slate-700 pb-2">Weapons</h3>
          <WeaponIntroductoryText interactiveTerms={interactiveTerms} onTermClick={onTermClick} />
          {filteredWeapons.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredWeapons.map(renderWeaponCard)}
            </div>
          ) : <p className="text-slate-400">No weapons match your filters.</p>}
        </section>
      )}

      {(activeCategory === 'all' || activeCategory === 'armor') && (
        <section className="mb-10">
          <h3 className="text-2xl font-semibold text-sky-300 mb-4 border-b border-slate-700 pb-2">Armor</h3>
          {filteredArmor.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredArmor.map(renderArmorCard)}
            </div>
          ) : <p className="text-slate-400">No armor matches your filters.</p>}
        </section>
      )}

      {(activeCategory === 'all' || activeCategory === 'loot') && (
        <section className="mb-10">
          <h3 className="text-2xl font-semibold text-sky-300 mb-4 border-b border-slate-700 pb-2">Loot</h3>
          {filteredLoot.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredLoot.map(item => renderItemCard(item, 'Loot'))}
            </div>
          ) : <p className="text-slate-400">No loot items match your filters.</p>}
        </section>
      )}

      {(activeCategory === 'all' || activeCategory === 'consumables') && (
        <section className="mb-10">
          <h3 className="text-2xl font-semibold text-sky-300 mb-4 border-b border-slate-700 pb-2">Consumables</h3>
          {filteredConsumables.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredConsumables.map(item => renderItemCard(item, 'Consumable'))}
            </div>
          ) : <p className="text-slate-400">No consumables match your filters.</p>}
        </section>
      )}

    </div>
  );
};

export default EquipmentReference;
