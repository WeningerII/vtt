
import React from 'react';
import { ProcessedChunk, InteractiveTermConfig } from '../types';
import ChunkCard from './ChunkCard';
import { Card } from './common/Card';

interface GMToolsDashboardProps {
  processedChunks: ProcessedChunk[];
  interactiveTerms: InteractiveTermConfig[];
  onTermClick: (term: InteractiveTermConfig) => void;
}

const GM_SECTION_TITLES = [
  "RUNNING AN ADVENTURE > Introduction",
  "RUNNING AN ADVENTURE > GM Guidance",
  "RUNNING AN ADVENTURE > Core GM Mechanics",
  "RUNNING AN ADVENTURE > Adversaries and Environments",
  "RUNNING AN ADVENTURE > The Witherwild Campaign Frame"
];

const GMToolsDashboard: React.FC<GMToolsDashboardProps> = ({ processedChunks, interactiveTerms, onTermClick }) => {
  const relevantChunks = GM_SECTION_TITLES.map(title => 
    processedChunks.find(chunk => chunk.title.trim().toUpperCase() === title.toUpperCase())
  ).filter(Boolean) as ProcessedChunk[];

  return (
    <div className="max-w-5xl mx-auto">
      <h2 className="text-3xl font-bold text-sky-400 text-center mb-8" style={{ fontFamily: "'Orbitron', sans-serif" }}>
        GM Tools &amp; Running the Game
      </h2>
      {relevantChunks.length > 0 ? (
        <div className="space-y-6">
          {relevantChunks.map(chunk => (
            <ChunkCard 
              key={chunk.id} 
              chunk={chunk} 
              isSearchResult={true} 
              interactiveTerms={interactiveTerms}
              onTermClick={onTermClick}
            />
          ))}
        </div>
      ) : (
         <Card>
          <p className="text-slate-400 text-center py-8">
            GM Tools sections not found. 
            Please ensure the SRD document has been processed via the "SRD Indexer" tab.
            Looked for sections under "RUNNING AN ADVENTURE".
          </p>
        </Card>
      )}
    </div>
  );
};

export default GMToolsDashboard;
