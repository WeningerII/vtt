
import React from 'react';
import { CharacterData, Weapon } from '../../types';
import { formatDamageRoll } from '../../services/characterStatService'; // Assuming this service exists
import { Card } from './Card';

interface LiveStatsPanelProps {
  character: CharacterData | null;
}

const StatItem: React.FC<{ label: string; value: string | number | undefined; className?: string }> = ({ label, value, className }) => (
  <div className={`flex justify-between items-center py-1 ${className}`}>
    <span className="text-slate-400 text-sm">{label}:</span>
    <span className="text-sky-300 font-semibold text-sm">{value !== undefined ? value : 'N/A'}</span>
  </div>
);

const LiveStatsPanel: React.FC<LiveStatsPanelProps> = ({ character }) => {
  if (!character) {
    return (
      <Card title="Live Stats" className="mt-4">
        <p className="text-slate-400">No character data available.</p>
      </Card>
    );
  }

  const primaryDamage = formatDamageRoll(character.activePrimaryWeapon, character.proficiency);
  const secondaryDamage = formatDamageRoll(character.activeSecondaryWeapon, character.proficiency);

  return (
    <Card title="Live Character Stats" className="sticky top-4 backdrop-blur-lg bg-slate-800/80 border border-sky-700/50 shadow-xl z-10">
      <div className="grid grid-cols-2 gap-x-4 gap-y-1">
        <StatItem label="HP" value={`${character.hp.current} / ${character.hp.max}`} />
        <StatItem label="Evasion" value={character.evasion} />
        <StatItem label="Armor Score" value={character.armorScore} />
        <StatItem label="Proficiency" value={character.proficiency} />
        <StatItem label="Major Threshold" value={character.damageThresholds.major} />
        <StatItem label="Severe Threshold" value={character.damageThresholds.severe} />
        
        {character.activePrimaryWeapon && (
          <StatItem label={`${character.activePrimaryWeapon.name}`} value={primaryDamage || 'N/A'} className="col-span-2 border-t border-slate-700 pt-1 mt-1" />
        )}
        {character.activeSecondaryWeapon && (
          <StatItem label={`${character.activeSecondaryWeapon.name}`} value={secondaryDamage || 'N/A'} className="col-span-2" />
        )}
      </div>
      {/* Placeholder for future: breakdown on hover/expand and temporary modifiers */}
    </Card>
  );
};

export default LiveStatsPanel;
