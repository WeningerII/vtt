
import React from 'react';
import { InteractiveTermConfig } from '../../types'; // Updated import

// Helper function for escaping regex special characters
const escapeRegExp = (string: string): string => {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
};

interface InteractiveTextRendererProps {
  text: string;
  terms: InteractiveTermConfig[]; // Updated prop type
  onTermClick: (term: InteractiveTermConfig) => void; // Updated prop type
}

const InteractiveTextRenderer: React.FC<InteractiveTextRendererProps> = ({ text, terms, onTermClick }) => {
  if (!text || !terms || terms.length === 0) {
    return <>{text}</>;
  }

  const sortedTerms = [...terms].sort((a, b) => b.name.length - a.name.length);

  const termMap = new Map<string, InteractiveTermConfig>();
  sortedTerms.forEach(term => termMap.set(term.name.toLowerCase(), term));

  const regex = new RegExp(`\\b(${sortedTerms.map(term => escapeRegExp(term.name)).join('|')})\\b`, 'gi');
  
  const parts = text.split(regex);

  return (
    <>
      {parts.map((part, index) => {
        const lowerPart = part.toLowerCase();
        const matchedTermConfig = termMap.get(lowerPart);

        if (matchedTermConfig) {
          return (
            <button
              key={`${matchedTermConfig.id}-${index}`}
              type="button"
              onClick={() => onTermClick(matchedTermConfig)}
              className="text-sky-400 underline hover:text-sky-300 focus:text-sky-200 focus:outline-none focus:ring-1 focus:ring-sky-300 rounded px-0.5 py-0 transition-colors font-medium"
              aria-label={`View details for ${matchedTermConfig.name}`}
            >
              {part}
            </button>
          );
        }
        return <React.Fragment key={`text-${index}`}>{part}</React.Fragment>;
      })}
    </>
  );
};

export default InteractiveTextRenderer;
