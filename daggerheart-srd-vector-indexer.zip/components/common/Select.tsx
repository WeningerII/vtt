
import React from 'react';

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  wrapperClassName?: string;
}

const Select: React.FC<SelectProps> = ({ label, id, children, className, wrapperClassName, ...props }) => {
  const selectId = id || (label ? label.toLowerCase().replace(/\s+/g, '-') : undefined);
  return (
    <div className={wrapperClassName}>
      {label && <label htmlFor={selectId} className="block text-sm font-medium text-slate-300 mb-1">{label}</label>}
      <select
        id={selectId}
        className={`w-full p-2.5 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:ring-sky-500 focus:border-sky-500 text-slate-100 placeholder-slate-400 ${className}`}
        {...props}
      >
        {children}
      </select>
    </div>
  );
};

export { Select };
