
import React from 'react';

interface CardProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
  titleClassName?: string;
  contentClassName?: string;
}

const Card: React.FC<CardProps> = ({ title, children, className, titleClassName, contentClassName }) => {
  return (
    <div className={`bg-slate-800/70 backdrop-blur-md p-6 rounded-xl shadow-xl border border-slate-700 ${className}`}>
      {title && <h3 className={`text-xl font-semibold text-sky-400 mb-4 border-b border-slate-700 pb-2 ${titleClassName}`}>{title}</h3>}
      <div className={contentClassName}>
        {children}
      </div>
    </div>
  );
};

export { Card };
