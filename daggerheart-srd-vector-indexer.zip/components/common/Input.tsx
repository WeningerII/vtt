
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  wrapperClassName?: string;
}

const Input: React.FC<InputProps> = ({ label, id, type = "text", className, wrapperClassName, ...props }) => {
  const inputId = id || (label ? label.toLowerCase().replace(/\s+/g, '-') : undefined);
  return (
    <div className={wrapperClassName}>
      {label && <label htmlFor={inputId} className="block text-sm font-medium text-slate-300 mb-1">{label}</label>}
      <input
        type={type}
        id={inputId}
        className={`w-full p-2.5 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:ring-sky-500 focus:border-sky-500 text-slate-100 placeholder-slate-400 ${className}`}
        {...props}
      />
    </div>
  );
};

export { Input };
