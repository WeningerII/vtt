
import React, { useState } from 'react';
import { SRDData, DomainCard as DomainCardType, InteractiveTermConfig } from '../types'; // Updated import
import { Card } from './common/Card';
import { Select } from './common/Select';
import { Input } from './common/Input';
import { DOMAINS_LIST } from '../constants';
import InteractiveTextRenderer from './common/InteractiveTextRenderer';

interface DomainCardReferenceProps {
  srdData: SRDData;
  interactiveTerms: InteractiveTermConfig[]; // Updated prop type
  onTermClick: (term: InteractiveTermConfig) => void; // Updated prop type
}

const DomainCardReference: React.FC<DomainCardReferenceProps> = ({ srdData, interactiveTerms, onTermClick }) => {
  const [selectedDomain, setSelectedDomain] = useState<string>('');
  const [selectedLevel, setSelectedLevel] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const levels = Array.from(new Set(srdData.domainCards.map(card => card.level))).sort((a, b) => a - b);

  const filteredCards = srdData.domainCards.filter(card => {
    const domainMatch = selectedDomain ? card.domain === selectedDomain : true;
    const levelMatch = selectedLevel ? card.level === parseInt(selectedLevel) : true;
    const termMatch = searchTerm ? 
      card.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      card.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      card.type.toLowerCase().includes(searchTerm.toLowerCase())
      : true;
    return domainMatch && levelMatch && termMatch;
  });

  return (
    <div className="max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold text-sky-400 text-center mb-8" style={{ fontFamily: "'Orbitron', sans-serif" }}>
        Domain Card Reference
      </h2>
      
      <Card className="mb-8" contentClassName="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
        <Input
          label="Search Name/Description"
          type="text"
          placeholder="E.g., Fireball, Heal, Attack"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <Select 
          label="Filter by Domain"
          value={selectedDomain}
          onChange={(e) => setSelectedDomain(e.target.value)}
        >
          <option value="">All Domains</option>
          {DOMAINS_LIST.map(domain => (
            <option key={domain} value={domain}>{domain}</option>
          ))}
        </Select>
        <Select
          label="Filter by Level"
          value={selectedLevel}
          onChange={(e) => setSelectedLevel(e.target.value)}
        >
          <option value="">All Levels</option>
          {levels.map(level => (
            <option key={level} value={level.toString()}>{level}</option>
          ))}
        </Select>
      </Card>

      {filteredCards.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCards.map((card: DomainCardType) => (
            <Card key={card.id} titleClassName="text-lg" className="flex flex-col h-full">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sky-300 font-semibold text-lg">{card.name}</h3>
                <span className="text-xs bg-slate-700 px-2 py-1 rounded-full text-sky-200">{card.domain} - Lvl {card.level}</span>
              </div>
              <p className="text-xs text-slate-400 mb-2">Type: <span className="font-medium">{card.type}</span> | Recall Cost: <span className="font-medium">{card.recallCost}</span></p>
              <div className="text-sm text-slate-300 whitespace-pre-line flex-grow overflow-y-auto max-h-60 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-700">
                <InteractiveTextRenderer text={card.description} terms={interactiveTerms} onTermClick={onTermClick} />
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <p className="text-slate-400 text-center py-8">
            No domain cards match your filters.
          </p>
        </Card>
      )}
    </div>
  );
};

export default DomainCardReference;
