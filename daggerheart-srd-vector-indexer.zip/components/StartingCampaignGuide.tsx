
import React from 'react';
import { ProcessedChunk, InteractiveTermConfig } from '../types';
import ChunkCard from './ChunkCard';
import { Card } from './common/Card';

interface StartingCampaignGuideProps {
  processedChunks: ProcessedChunk[];
  interactiveTerms: InteractiveTermConfig[];
  onTermClick: (term: InteractiveTermConfig) => void;
}

const SECTION_TITLES = [
  "STARTING A CAMPAIGN > Session Zero",
  "STARTING A CAMPAIGN > Setting Creation"
];

const StartingCampaignGuide: React.FC<StartingCampaignGuideProps> = ({ processedChunks, interactiveTerms, onTermClick }) => {
  const relevantChunks = SECTION_TITLES.map(title => 
    processedChunks.find(chunk => chunk.title.trim().toUpperCase() === title.toUpperCase())
  ).filter(Boolean) as ProcessedChunk[];

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold text-sky-400 text-center mb-8" style={{ fontFamily: "'Orbitron', sans-serif" }}>
        Starting Your Daggerheart Campaign
      </h2>
      {relevantChunks.length > 0 ? (
        <div className="space-y-6">
          {relevantChunks.map(chunk => (
            <ChunkCard 
              key={chunk.id} 
              chunk={chunk} 
              isSearchResult={true} 
              interactiveTerms={interactiveTerms}
              onTermClick={onTermClick}
            />
          ))}
        </div>
      ) : (
        <Card>
          <p className="text-slate-400 text-center py-8">
            Starting campaign guide sections not found. 
            Please ensure the SRD document has been processed via the "SRD Indexer" tab.
            Looked for: "{SECTION_TITLES.join('", "')}".
          </p>
        </Card>
      )}
    </div>
  );
};

export default StartingCampaignGuide;
