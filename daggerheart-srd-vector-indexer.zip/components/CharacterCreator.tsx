
import React, { useState, useEffect, useCallback } from 'react';
import { CharacterData, ClassData, Ancestry, Community, Weapon, Armor, DomainCard, Trait, SRDData, ProcessedChunk, FeatureEntry, InteractiveTermConfig, Subclass } from '../types';
import { STARTING_POTION_CHOICES, STARTING_INVENTORY_ITEMS, TRAIT_NAMES, INITIAL_TRAIT_MODIFIERS, DEFAULT_CHARACTER_DATA } from '../constants'; 
import { Button } from './common/Button';
import { Select } from './common/Select';
import { Input } from './common/Input';
import { Card } from './common/Card';
import InteractiveTextRenderer from './common/InteractiveTextRenderer';
import LiveStatsPanel from './common/LiveStatsPanel'; // Import LiveStatsPanel
import { calculateAllCharacterStats, getCharacterFeatures, formatDamageRoll } from '../services/characterStatService'; // Import calculation service

interface CharacterCreatorProps {
  character: CharacterData;
  setCharacter: React.Dispatch<React.SetStateAction<CharacterData>>;
  srdData: SRDData;
  goToSheet: () => void;
  srdChunks?: ProcessedChunk[]; 
  onViewSrdChunk?: (chunk: ProcessedChunk) => void;
  interactiveTerms: InteractiveTermConfig[];
  onTermClick: (term: InteractiveTermConfig) => void;
  initialParams?: { classId?: string; ancestryId?: string; communityId?: string };
  onParamsConsumed: () => void;
}

const TOTAL_STEPS = 10;

type TraitModifierValue = typeof INITIAL_TRAIT_MODIFIERS[number];

const getAvailableModifiers = (assignedValues: TraitModifierValue[], allModifiers: readonly TraitModifierValue[]): TraitModifierValue[] => {
  const counts = [...allModifiers].reduce((acc, mod) => {
    acc[mod] = (acc[mod] || 0) + 1;
    return acc;
  }, {} as Record<TraitModifierValue, number>);

  assignedValues.forEach(val => {
    if (counts[val] > 0) {
      counts[val]--;
    }
  });

  return Object.entries(counts)
    .filter(([, count]) => count > 0)
    .map(([mod]) => parseInt(mod) as TraitModifierValue)
    .sort((a,b) => b-a);
};

const findSrdChunk = (itemName: string, srdChunks?: ProcessedChunk[]): ProcessedChunk | undefined => {
  if (!srdChunks || !itemName) return undefined;
  const searchTerm = itemName.toLowerCase();
  return srdChunks.find(chunk => chunk.title.toLowerCase().includes(searchTerm) || chunk.summary.toLowerCase().includes(searchTerm));
};


const CharacterCreator: React.FC<CharacterCreatorProps> = ({ 
    character, 
    setCharacter, 
    srdData, 
    goToSheet, 
    srdChunks, 
    onViewSrdChunk,
    interactiveTerms,
    onTermClick,
    initialParams,
    onParamsConsumed
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [localCharacter, setLocalCharacter] = useState<CharacterData>(() => {
    const initialChar = character.name && character.traits?.length > 0 && character.class ? character : DEFAULT_CHARACTER_DATA;
     if (!initialChar.traits || initialChar.traits.length === 0) {
        initialChar.traits = TRAIT_NAMES.map(name => ({ name, value: 0 } as Trait));
    }
    if(!initialChar.features) initialChar.features = [];
    return JSON.parse(JSON.stringify(initialChar)); // Deep copy
  });
  
  const [assignedTraitValues, setAssignedTraitValues] = useState<TraitModifierValue[]>([]);

  const [selectedClassSrd, setSelectedClassSrd] = useState<ProcessedChunk | undefined>();
  const [selectedAncestrySrd, setSelectedAncestrySrd] = useState<ProcessedChunk | undefined>();
  const [selectedCommunitySrd, setSelectedCommunitySrd] = useState<ProcessedChunk | undefined>();

  // Initialize and recalculate stats whenever fundamental character aspects change
  useEffect(() => {
    let charToProcess = localCharacter;
  
    if (initialParams) {
      let paramsApplied = false;
      if (initialParams.classId && (!charToProcess.class || charToProcess.class.id !== initialParams.classId)) {
        const preselectedClass = srdData.classes.find(c => c.id === initialParams.classId);
        if (preselectedClass) {
          charToProcess = {
            ...charToProcess,
            class: preselectedClass,
            subclass: null,
            inventory: [...STARTING_INVENTORY_ITEMS, preselectedClass.classItems].filter(Boolean),
            domainCards: []
          };
          setSelectedClassSrd(findSrdChunk(preselectedClass.name, srdChunks));
          paramsApplied = true;
        }
      }
      if (initialParams.ancestryId && (!charToProcess.ancestry || charToProcess.ancestry.id !== initialParams.ancestryId)) {
        const preselectedAncestry = srdData.ancestries.find(a => a.id === initialParams.ancestryId);
        if (preselectedAncestry) {
          charToProcess = {...charToProcess, ancestry: preselectedAncestry};
          setSelectedAncestrySrd(findSrdChunk(preselectedAncestry.name, srdChunks));
          paramsApplied = true;
        }
      }
      if (initialParams.communityId && (!charToProcess.community || charToProcess.community.id !== initialParams.communityId)) {
        const preselectedCommunity = srdData.communities.find(c => c.id === initialParams.communityId);
        if (preselectedCommunity) {
          charToProcess = {...charToProcess, community: preselectedCommunity};
          setSelectedCommunitySrd(findSrdChunk(preselectedCommunity.name, srdChunks));
          paramsApplied = true;
        }
      }
      if (paramsApplied) {
        onParamsConsumed(); 
      }
    }
    
    // Ensure traits are initialized
    if (!charToProcess.traits || charToProcess.traits.length === 0) {
        charToProcess.traits = TRAIT_NAMES.map(name => ({ name, value: 0 } as Trait));
    }
    
    const calculatedStats = calculateAllCharacterStats(charToProcess);
    
    const currentHpCapped = Math.min(charToProcess.hp.current, calculatedStats.maxHP);

    setLocalCharacter(prev => ({
      ...prev, // Persist non-calculated fields like name, inventory choices, etc. from charToProcess or prev
      ...charToProcess, // Apply selections from initialParams or existing state
      hp: { current: currentHpCapped, max: calculatedStats.maxHP },
      evasion: calculatedStats.evasion,
      armorScore: calculatedStats.armorScore,
      damageThresholds: { major: calculatedStats.major, severe: calculatedStats.severe },
      proficiency: calculatedStats.proficiency,
      features: calculatedStats.features,
    }));

    const currentTraitValues = (charToProcess.traits || [])
        .map(t => t.value)
        .filter(v => INITIAL_TRAIT_MODIFIERS.includes(v as TraitModifierValue)) as TraitModifierValue[];
    setAssignedTraitValues(currentTraitValues);

    if (charToProcess.class && !selectedClassSrd) setSelectedClassSrd(findSrdChunk(charToProcess.class.name, srdChunks));
    if (charToProcess.ancestry && !selectedAncestrySrd) setSelectedAncestrySrd(findSrdChunk(charToProcess.ancestry.name, srdChunks));
    if (charToProcess.community && !selectedCommunitySrd) setSelectedCommunitySrd(findSrdChunk(charToProcess.community.name, srdChunks));

  // eslint-disable-next-line react-hooks/exhaustive-deps 
  }, [
    // Only run this effect when these fundamental inputs change
    character.name, // To re-initialize if the whole character prop changes
    initialParams, 
    // srdData and srdChunks are stable but included for safety if they were to change
    srdData, 
    srdChunks, 
    onParamsConsumed 
  ]);


  // This specific useEffect will run calculations whenever a direct input to stats changes on localCharacter
  useEffect(() => {
    const newCalcdStats = calculateAllCharacterStats(localCharacter);
    
    // Check if an update is truly needed to prevent potential loops if stringify is too slow/complex
    // This is a shallow check; for deep objects like features, more robust checking or careful effect dependencies are key
    if (localCharacter.hp.max !== newCalcdStats.maxHP ||
        localCharacter.evasion !== newCalcdStats.evasion ||
        localCharacter.armorScore !== newCalcdStats.armorScore ||
        localCharacter.damageThresholds.major !== newCalcdStats.major ||
        localCharacter.damageThresholds.severe !== newCalcdStats.severe ||
        localCharacter.proficiency !== newCalcdStats.proficiency ||
        JSON.stringify(localCharacter.features) !== JSON.stringify(newCalcdStats.features) // Be cautious with stringify for performance
    ) {
        const currentHpCapped = Math.min(localCharacter.hp.current, newCalcdStats.maxHP);
        setLocalCharacter(prev => ({
            ...prev,
            hp: { ...prev.hp, max: newCalcdStats.maxHP, current: currentHpCapped },
            evasion: newCalcdStats.evasion,
            armorScore: newCalcdStats.armorScore,
            damageThresholds: { major: newCalcdStats.major, severe: newCalcdStats.severe },
            proficiency: newCalcdStats.proficiency,
            features: newCalcdStats.features,
        }));
    }
  }, [
      localCharacter.class, 
      localCharacter.subclass, 
      localCharacter.ancestry, 
      localCharacter.community, 
      localCharacter.level, 
      localCharacter.traits, 
      localCharacter.activeArmor,
      // Add other direct inputs if any are missed:
      // localCharacter.activePrimaryWeapon (if it grants passive stats beyond damage string)
      // localCharacter.activeSecondaryWeapon (if it grants passive stats beyond damage string)
      // localCharacter.domainCards (if they grant passive stats)
  ]);


  const handleInputChange = (field: keyof CharacterData, value: any) => {
    setLocalCharacter(prev => ({ ...prev, [field]: value }));
  };
  
  const handleTraitAssignment = (traitName: string, newValueStr: string) => {
    const newValue = newValueStr === "" ? 0 : parseInt(newValueStr); 
    setLocalCharacter(prev => {
      const oldTraitValueFromState = prev.traits.find(t => t.name === traitName)?.value;
      const newTraits = prev.traits.map(t => t.name === traitName ? { ...t, value: newValue } : t);
      
      let newAssignedValues = [...assignedTraitValues];
      if (INITIAL_TRAIT_MODIFIERS.includes(oldTraitValueFromState as TraitModifierValue)) {
          const index = newAssignedValues.indexOf(oldTraitValueFromState as TraitModifierValue);
          if (index > -1) {
            newAssignedValues.splice(index, 1);
          }
      }
      if (INITIAL_TRAIT_MODIFIERS.includes(newValue as TraitModifierValue)) {
          const countInInitial = INITIAL_TRAIT_MODIFIERS.filter(m => m === (newValue as TraitModifierValue)).length;
          const countInNewAssigned = newAssignedValues.filter(m => m === (newValue as TraitModifierValue)).length;
          if (countInNewAssigned < countInInitial) {
            newAssignedValues.push(newValue as TraitModifierValue);
          }
      }
      setAssignedTraitValues(newAssignedValues);
      // Stats will be recalculated by the useEffect hook that depends on localCharacter.traits
      return { ...prev, traits: newTraits };
    });
  };

  const handleClassSelect = (classIdOrName: string) => {
    const selectedClass = srdData.classes.find(c => c.id === classIdOrName || c.name === classIdOrName);
    if (selectedClass) {
      setSelectedClassSrd(findSrdChunk(selectedClass.name, srdChunks));
      setLocalCharacter(prev => {
        const baseInventory = [...STARTING_INVENTORY_ITEMS, selectedClass.classItems].filter((item, index, self) => self.indexOf(item) === index && item); 
        // Stats will be recalculated by the useEffect hook
        return {
            ...prev,
            class: selectedClass,
            subclass: null, 
            inventory: baseInventory,
            domainCards: [], 
        };
      });
    }
  };
  
  const handleSubclassSelect = (subclassName: string) => {
    const selectedSubclass = localCharacter.class?.subclasses.find(sc => sc.name === subclassName);
    if (selectedSubclass) {
       setLocalCharacter(prev => {
        // Stats will be recalculated by the useEffect hook
        return {...prev, subclass: selectedSubclass};
      });
    }
  };
  
  const handleAncestrySelect = (ancestryIdOrName: string) => {
    const selectedAncestry = srdData.ancestries.find(a => a.id === ancestryIdOrName || a.name === ancestryIdOrName);
    if (selectedAncestry) {
        setSelectedAncestrySrd(findSrdChunk(selectedAncestry.name, srdChunks));
        setLocalCharacter(prev => {
            // Stats will be recalculated by the useEffect hook
            return {...prev, ancestry: selectedAncestry};
        });
    }
  };

  const handleCommunitySelect = (communityIdOrName: string) => {
    const selectedCommunity = srdData.communities.find(c => c.id === communityIdOrName || c.name === communityIdOrName);
    if (selectedCommunity) {
        setSelectedCommunitySrd(findSrdChunk(selectedCommunity.name, srdChunks));
        setLocalCharacter(prev => {
            // Stats will be recalculated by the useEffect hook
            return {...prev, community: selectedCommunity};
        });
    }
  };
  
  const handlePrimaryWeaponSelect = (weaponName: string) => {
    const weapon = srdData.weapons.find(w => w.name === weaponName && w.category === 'Primary');
    setLocalCharacter(prev => ({...prev, activePrimaryWeapon: weapon || null }));
  };
  
  const handleSecondaryWeaponSelect = (weaponName: string) => {
    const weapon = srdData.weapons.find(w => w.name === weaponName && w.category === 'Secondary');
    setLocalCharacter(prev => ({...prev, activeSecondaryWeapon: weapon || null }));
  };

  const handleArmorSelect = (armorName: string) => {
    const selectedArmor = srdData.armor.find(a => a.name === armorName);
    setLocalCharacter(prev => {
        // Stats will be recalculated by the useEffect hook
        return { ...prev, activeArmor: selectedArmor || null };
    });
  };

  const handleDomainCardSelect = (cardId: string) => {
    const card = srdData.domainCards.find(c => c.id === cardId);
    if (card) {
      setLocalCharacter(prev => {
        const existingCardIndex = prev.domainCards.findIndex(dc => dc.id === cardId);
        if (existingCardIndex > -1) { 
          return { ...prev, domainCards: prev.domainCards.filter(dc => dc.id !== cardId) };
        } else if (prev.domainCards.length < 2) { 
          return { ...prev, domainCards: [...prev.domainCards, card] };
        }
        return prev; 
      });
    }
  };
  
  const nextStep = () => {
    if (currentStep === 3 && !isStep3Valid()) {
      alert("Please assign all trait modifiers correctly before proceeding.");
      return;
    }
    // Force a final stat calculation before moving to sheet or next step if needed
    const finalCalcdStats = calculateAllCharacterStats(localCharacter);
    const finalCharacterState = {
        ...localCharacter,
        hp: { ...localCharacter.hp, max: finalCalcdStats.maxHP, current: Math.min(localCharacter.hp.current, finalCalcdStats.maxHP) },
        evasion: finalCalcdStats.evasion,
        armorScore: finalCalcdStats.armorScore,
        damageThresholds: { major: finalCalcdStats.major, severe: finalCalcdStats.severe },
        proficiency: finalCalcdStats.proficiency,
        features: finalCalcdStats.features,
    };

    if (currentStep < TOTAL_STEPS) {
        setLocalCharacter(finalCharacterState); // Ensure state is updated before step change if logic depends on it
        setCurrentStep(s => s + 1);
    } else {
      setCharacter(finalCharacterState); 
      goToSheet();
    }
  };
  
  const prevStep = () => currentStep > 1 && setCurrentStep(s => s - 1);

  const isStep3Valid = () => {
    const traitValues = localCharacter.traits
        .map(t => t.value)
        .filter(v => INITIAL_TRAIT_MODIFIERS.includes(v as TraitModifierValue)) as TraitModifierValue[];
    
    const initialModifiersCounts = [...INITIAL_TRAIT_MODIFIERS].reduce((acc, mod) => {
        acc[mod] = (acc[mod] || 0) + 1;
        return acc;
    }, {} as Record<number, number>); 

    const assignedModifiersCounts = traitValues.reduce((acc, mod) => {
        acc[mod] = (acc[mod] || 0) + 1;
        return acc;
    }, {} as Record<number, number>);

    return INITIAL_TRAIT_MODIFIERS.length === traitValues.length &&
           Object.keys(initialModifiersCounts).every(modKey => {
             const modNum = parseInt(modKey);
             return initialModifiersCounts[modNum] === (assignedModifiersCounts[modNum] || 0);
           });
  };
  
  const SrdInfoDisplay: React.FC<{chunk?: ProcessedChunk, itemName: string}> = ({ chunk, itemName }) => {
    if (!chunk) return <p className="mt-1 text-xs text-slate-500 italic">No SRD info found for {itemName}.</p>;
    return (
      <div className="mt-2 p-2 bg-slate-700/50 rounded-md border border-slate-600 text-xs">
        <p className="text-slate-300 whitespace-pre-line">
            <InteractiveTextRenderer text={chunk.summary} terms={interactiveTerms} onTermClick={onTermClick} />
        </p>
        {onViewSrdChunk && (
          <Button size="sm" variant="secondary" onClick={() => onViewSrdChunk(chunk)} className="mt-1 text-xs py-0.5 px-1.5">
            View Full SRD Entry
          </Button>
        )}
      </div>
    );
  };


  const Step4Component = React.memo(() => {
    return (
      <Card title="Step 4: Core Stats Preview (Calculated)" contentClassName="space-y-1">
        {/* This step is mostly superseded by the LiveStatsPanel, but can show additional derived info */}
        <p className="text-xs text-slate-400">
            <InteractiveTextRenderer 
                text="Core stats like HP, Evasion, Proficiency are derived from your Class, Level, and other choices. Armor (next step) will adjust Evasion, Armor Score, and Damage Thresholds further. See Live Stats Panel above for current values."
                terms={interactiveTerms}
                onTermClick={onTermClick}
            />
         </p>
      </Card>
    );
  });

  const Step5Component = React.memo(() => {
    return (
      <Card title="Step 5: Starting Equipment">
        <Select label="Primary Weapon (Tier 1)" value={localCharacter.activePrimaryWeapon?.name || ""} onChange={e => handlePrimaryWeaponSelect(e.target.value)}>
          <option value="">-- Select Primary Weapon --</option>
          {srdData.weapons.filter(w => w.tier === 1 && w.category === 'Primary').map(w => <option key={w.id} value={w.name}>{w.name} ({w.damage}, {w.trait})</option>)}
        </Select>
        {localCharacter.activePrimaryWeapon && <p className="mt-1 text-xs text-slate-400 italic">
            Feature: <InteractiveTextRenderer text={localCharacter.activePrimaryWeapon.feature} terms={interactiveTerms} onTermClick={onTermClick} />
        </p>}
        
        <Select label="Secondary Weapon (Tier 1, Optional)" value={localCharacter.activeSecondaryWeapon?.name || ""} onChange={e => handleSecondaryWeaponSelect(e.target.value)} wrapperClassName="mt-4">
          <option value="">-- No Secondary Weapon --</option>
           {srdData.weapons.filter(w => w.tier === 1 && w.category === 'Secondary').map(w => <option key={w.id} value={w.name}>{w.name} ({w.damage}, {w.trait})</option>)}
        </Select>
        {localCharacter.activeSecondaryWeapon && <p className="mt-1 text-xs text-slate-400 italic">
            Feature: <InteractiveTextRenderer text={localCharacter.activeSecondaryWeapon.feature} terms={interactiveTerms} onTermClick={onTermClick} />
        </p>}

        <Select label="Armor (Tier 1)" value={localCharacter.activeArmor?.name || ""} onChange={e => handleArmorSelect(e.target.value)} wrapperClassName="mt-4">
          <option value="">-- No Armor --</option>
          {srdData.armor.filter(a => a.tier === 1).map(a => <option key={a.id} value={a.name}>{a.name} (Score: {a.baseScore}, Thresh: {a.baseThresholds})</option>)}
        </Select>
        {localCharacter.activeArmor && <p className="mt-1 text-xs text-slate-400 italic">
            Feature: <InteractiveTextRenderer text={localCharacter.activeArmor.feature} terms={interactiveTerms} onTermClick={onTermClick} />
        </p>}
      </Card>
    );
  });

  const renderStepContent = () => {
    switch (currentStep) {
      case 1: 
        return (
          <Card title="Step 1: Class & Subclass">
            <Select label="Choose your Class" value={localCharacter.class?.id || ""} onChange={e => handleClassSelect(e.target.value)}>
              <option value="">-- Select Class --</option>
              {srdData.classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
            {localCharacter.class && (
              <>
                <SrdInfoDisplay chunk={selectedClassSrd} itemName={localCharacter.class.name} />
                <p className="mt-3 text-sm text-slate-300">Domains: <span className="font-semibold text-sky-300">{localCharacter.class.domains.join(', ')}</span></p>
                <p className="mt-1 text-sm text-slate-300">Class Items: <span className="italic text-slate-400">{localCharacter.class.classItems}</span></p>
                
                <div className="mt-3 space-y-2 text-sm bg-slate-700/50 p-3 rounded-md shadow">
                    <div>
                        <strong className="text-sky-300 block">{localCharacter.class.classFeature.name} (Class Feature)</strong>
                        <p className="text-slate-400 italic text-xs whitespace-pre-line">
                           <InteractiveTextRenderer text={localCharacter.class.classFeature.description} terms={interactiveTerms} onTermClick={onTermClick} />
                        </p>
                    </div>
                    <div>
                        <strong className="text-sky-300 block">{localCharacter.class.hopeFeature.name} (Hope Feature)</strong>
                        <p className="text-slate-400 italic text-xs whitespace-pre-line">
                           <InteractiveTextRenderer text={localCharacter.class.hopeFeature.description} terms={interactiveTerms} onTermClick={onTermClick} />
                        </p>
                    </div>
                </div>

                <Select label="Choose your Subclass" value={localCharacter.subclass?.name || ""} onChange={e => handleSubclassSelect(e.target.value)} wrapperClassName="mt-4" disabled={!localCharacter.class}>
                  <option value="">-- Select Subclass --</option>
                  {localCharacter.class?.subclasses.map(sc => <option key={sc.name} value={sc.name}>{sc.name}</option>)}
                </Select>
                {localCharacter.subclass && (
                    <div className="mt-2 space-y-2 text-sm bg-slate-700/50 p-3 rounded-md shadow">
                        {localCharacter.subclass.features.filter(f => f.featureType === 'Foundation').map(feature => (
                             <div key={feature.name}>
                                <strong className="text-sky-300 block">{feature.name} ({localCharacter.subclass?.name} Foundation)</strong>
                                <p className="text-slate-400 italic text-xs whitespace-pre-line">
                                   <InteractiveTextRenderer text={feature.description} terms={interactiveTerms} onTermClick={onTermClick} />
                                </p>
                            </div>
                        ))}
                        {localCharacter.subclass.spellcastTrait && (
                            <div>
                                 <strong className="text-sky-300 block">Spellcast Trait</strong>
                                 <p className="text-slate-400 italic text-xs">{localCharacter.subclass.spellcastTrait}</p>
                            </div>
                        )}
                    </div>
                )}
              </>
            )}
          </Card>
        );
      case 2: 
        return (
          <Card title="Step 2: Heritage">
            <Select label="Choose your Ancestry" value={localCharacter.ancestry?.id || ""} onChange={e => handleAncestrySelect(e.target.value)}>
              <option value="">-- Select Ancestry --</option>
              {srdData.ancestries.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
            </Select>
            {localCharacter.ancestry && <SrdInfoDisplay chunk={selectedAncestrySrd} itemName={localCharacter.ancestry.name} />}
            {localCharacter.ancestry && <div className="mt-2 text-sm text-slate-300 space-y-1">Features: {localCharacter.ancestry.features.map(f=>(<div key={f.name}><span className="font-semibold text-sky-300">{f.name}:</span> <span className="italic text-slate-400 text-xs"><InteractiveTextRenderer text={f.description} terms={interactiveTerms} onTermClick={onTermClick} /></span></div>))}</div>}

            <Select label="Choose your Community" value={localCharacter.community?.id || ""} onChange={e => handleCommunitySelect(e.target.value)} wrapperClassName="mt-6">
              <option value="">-- Select Community --</option>
              {srdData.communities.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
            {localCharacter.community && <SrdInfoDisplay chunk={selectedCommunitySrd} itemName={localCharacter.community.name} />}
            {localCharacter.community && <p className="mt-2 text-sm text-slate-300"><span className="font-semibold text-sky-300">{localCharacter.community.feature.name}:</span> <span className="italic text-slate-400 text-xs"><InteractiveTextRenderer text={localCharacter.community.feature.description} terms={interactiveTerms} onTermClick={onTermClick} /></span></p>}
          </Card>
        );
      case 3: 
        const availableOptionsForDropdown = getAvailableModifiers(assignedTraitValues, INITIAL_TRAIT_MODIFIERS);
        return (
          <Card title="Step 3: Assign Character Traits">
            <p className="mb-4 text-slate-300">Assign each modifier ({INITIAL_TRAIT_MODIFIERS.map(m => m > 0 ? `+${m}` : m).join(', ')}) to one trait.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
            {(localCharacter.traits || []).map((trait) => {
              const currentTraitValue = trait.value; 
              let options = [...availableOptionsForDropdown]; 
              if (INITIAL_TRAIT_MODIFIERS.includes(currentTraitValue as TraitModifierValue) && !options.includes(currentTraitValue as TraitModifierValue)) {
                options.push(currentTraitValue as TraitModifierValue);
                options.sort((a,b) => b-a); 
              }
              
              return (
                <div key={trait.name}>
                  <label htmlFor={`trait-${trait.name}`} className="block text-sm font-medium text-slate-200 mb-1">{trait.name}</label>
                   <select
                      id={`trait-${trait.name}`}
                      value={INITIAL_TRAIT_MODIFIERS.includes(currentTraitValue as TraitModifierValue) ? currentTraitValue.toString() : ""}
                      onChange={(e) => handleTraitAssignment(trait.name, e.target.value)}
                      className="w-full p-2.5 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:ring-sky-500 focus:border-sky-500 text-slate-100"
                    >
                      <option value="">-- Select --</option>
                      {options.map(mod => (
                        <option key={`${trait.name}-${mod}`} value={mod.toString()}>{mod > 0 ? `+${mod}` : mod}</option>
                      ))}
                    </select>
                </div>
              );
            })}
            </div>
            {!isStep3Valid() && <p className="mt-4 text-sm text-yellow-400">Please assign each unique modifier from the list exactly once.</p>}
             {isStep3Valid() && <p className="mt-4 text-sm text-green-400">All traits correctly assigned.</p>}
          </Card>
        );
      case 4: 
         return <Step4Component />;
      case 5: 
         return <Step5Component />;
      case 6: 
        const currentPotionName = localCharacter.inventory.find(item => STARTING_POTION_CHOICES.some(p => p.name === item ));
        return (
          <Card title="Step 6: Inventory">
            <p className="mb-3 text-slate-300">Your character starts with:</p>
            <ul className="list-disc list-inside ml-4 mb-4 text-slate-400 space-y-1 text-sm">
              {localCharacter.inventory.filter(item => !STARTING_POTION_CHOICES.some(p => p.name === item)).map(item => <li key={item}>{item}</li>)}
            </ul>
            <Select label="Choose your starting potion" value={currentPotionName || ""} 
              onChange={e => {
                const newPotionName = e.target.value;
                setLocalCharacter(prev => {
                  let newInventory = prev.inventory.filter(item => !STARTING_POTION_CHOICES.some(p => p.name === item)); 
                  if (newPotionName) {
                    newInventory.push(newPotionName);
                  }
                  return {...prev, inventory: newInventory};
                });
              }} 
              wrapperClassName="mt-4">
              <option value="">-- Select Potion --</option>
              {STARTING_POTION_CHOICES.map(p => <option key={p.id} value={p.name}>{p.name} (<InteractiveTextRenderer text={p.description} terms={interactiveTerms} onTermClick={onTermClick} />)</option>)}
            </Select>
             <p className="mt-4 text-sm text-slate-300">Current Gold: {localCharacter.gold.handfuls} Handful(s)</p>
          </Card>
        );
      case 7: 
        return (
            <Card title="Step 7: Create Background">
                <p className="mb-3 text-slate-300">Describe your character's history, motivations, and what makes them unique. Consider the questions from your character guide or create your own narrative.</p>
                <textarea
                    value={localCharacter.background || ""}
                    onChange={e => handleInputChange('background', e.target.value)}
                    rows={8}
                    className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:ring-sky-500 focus:border-sky-500 text-slate-100 placeholder-slate-400"
                    placeholder="E.g., Raised in the forgotten temples of..., seeks revenge for..., dreams of discovering..."
                />
            </Card>
        );
      case 8: 
        return (
          <Card title="Step 8: Create Experiences">
            <p className="mb-3 text-slate-300">
                <InteractiveTextRenderer 
                    text="Define two unique experiences for your character. Each provides a +2 modifier when relevant to a roll (SRD p.5)."
                    terms={interactiveTerms}
                    onTermClick={onTermClick}
                />
            </p>
            <Input 
              label="Experience 1 (+2 Modifier)" 
              value={localCharacter.experiences[0]?.text || ""}
              onChange={e => {
                const newExperiences = [...localCharacter.experiences];
                newExperiences[0] = { text: e.target.value, modifier: 2 };
                setLocalCharacter(prev => ({ ...prev, experiences: [newExperiences[0] || {text:'', modifier:2}, newExperiences[1] || {text:'', modifier:2}] }));
              }}
              placeholder="e.g., Master of the Hidden Paths"
              wrapperClassName="mb-4"
            />
            <Input 
              label="Experience 2 (+2 Modifier)" 
              value={localCharacter.experiences[1]?.text || ""}
              onChange={e => {
                const newExperiences = [...localCharacter.experiences];
                newExperiences[1] = { text: e.target.value, modifier: 2 };
                 setLocalCharacter(prev => ({ ...prev, experiences: [newExperiences[0] || {text:'', modifier:2}, newExperiences[1] || {text:'', modifier:2}] }));
              }}
              placeholder="e.g., Unwavering Negotiator"
            />
          </Card>
        );
      case 9: 
        const availableDomains = localCharacter.class?.domains || [];
        const relevantCards = srdData.domainCards.filter(card => card.level === 1 && availableDomains.some(ad => card.domain === ad));
        return (
          <Card title="Step 9: Choose Domain Cards">
            <p className="mb-1 text-slate-300">Select two 1st-level cards from your class's available domains: <span className="font-semibold text-sky-300">{availableDomains.join(' or ')}</span>. (SRD p.6, 7)</p>
            <p className="mb-4 text-xs text-slate-400">
                <InteractiveTextRenderer text="These represent special abilities or spells your character can use." terms={interactiveTerms} onTermClick={onTermClick} />
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[300px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-800">
              {relevantCards.map(card => (
                <div key={card.id} 
                     className={`p-3 rounded-lg border-2 transition-all duration-150 cursor-pointer 
                                ${localCharacter.domainCards.find(dc => dc.id === card.id) 
                                  ? 'bg-sky-700 border-sky-500 shadow-lg ring-2 ring-sky-400' 
                                  : 'bg-slate-600 border-slate-500 hover:bg-sky-800 hover:border-sky-600'}`}
                  onClick={() => handleDomainCardSelect(card.id)}
                  role="checkbox"
                  aria-checked={!!localCharacter.domainCards.find(dc => dc.id === card.id)}
                  tabIndex={0}
                  onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && handleDomainCardSelect(card.id)}
                >
                  <h3 className="text-md font-medium text-slate-100">{card.name} <span className="text-xs text-sky-300">({card.domain} Lvl {card.level})</span></h3>
                  <p className="text-xs text-slate-300 mt-1 whitespace-pre-line">
                     <InteractiveTextRenderer text={card.description} terms={interactiveTerms} onTermClick={onTermClick} />
                  </p>
                  <p className="text-xs text-slate-400 mt-1">Recall Cost: {card.recallCost}</p>
                </div>
              ))}
            </div>
            {localCharacter.domainCards.length > 2 && <p className="mt-2 text-sm text-yellow-400">You can only select up to 2 domain cards.</p>}
          </Card>
        );
      case 10: 
        return (
          <Card title="Step 10: Final Details">
            <Input label="Character Name" value={localCharacter.name} onChange={e => handleInputChange('name', e.target.value)} placeholder="Your character's name" wrapperClassName="mb-4" />
            <Input label="Pronouns" value={localCharacter.pronouns} onChange={e => handleInputChange('pronouns', e.target.value)} placeholder="e.g., she/her, they/them" wrapperClassName="mb-4"/>
            <Input label="Short Description / Catchphrase" value={localCharacter.description} onChange={e => handleInputChange('description', e.target.value)} placeholder="A brief, evocative description" wrapperClassName="mb-4"/>
            <div>
                <label htmlFor="connections" className="block text-sm font-medium text-slate-300 mb-1">Party Connections</label>
                <textarea
                    id="connections"
                    value={localCharacter.connections}
                    onChange={e => handleInputChange('connections', e.target.value)}
                    rows={4}
                    className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:ring-sky-500 focus:border-sky-500 text-slate-100 placeholder-slate-400"
                    placeholder="Describe your character's relationships and bonds with other player characters."
                />
            </div>
          </Card>
        );
      default: return null;
    }
  };

  const progress = (currentStep / TOTAL_STEPS) * 100;

  return (
    <div className="space-y-6 md:max-w-3xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold text-sky-400 text-center mb-1" style={{ fontFamily: "'Orbitron', sans-serif" }}>Create Your Hero</h2>
        <p className="text-center text-slate-400 text-sm mb-4">Step {currentStep} of {TOTAL_STEPS}</p>
        <div className="w-full bg-slate-700 rounded-full h-2.5 mb-2 shadow-inner">
          <div 
            className="bg-sky-500 h-2.5 rounded-full transition-all duration-300 ease-out" 
            style={{ width: `${progress}%` }}
            role="progressbar"
            aria-valuenow={currentStep}
            aria-valuemin={1}
            aria-valuemax={TOTAL_STEPS}
            aria-label={`Character creation progress: step ${currentStep} of ${TOTAL_STEPS}`}
          ></div>
        </div>
      </div>

      {/* Live Stats Panel */}
      <LiveStatsPanel character={localCharacter} />

      <div className="min-h-[350px] sm:min-h-[400px] mt-4"> {/* Adjusted min-height and mt */}
        {renderStepContent()}
      </div>
      
      <div className="flex justify-between items-center pt-6 border-t border-slate-700 mt-4">
        <Button onClick={prevStep} disabled={currentStep === 1} variant="secondary">
          Previous
        </Button>
        <Button 
            onClick={nextStep} 
            disabled={
                (currentStep === 1 && (!localCharacter.class || !localCharacter.subclass)) || // Ensure subclass is also selected
                (currentStep === 2 && (!localCharacter.ancestry || !localCharacter.community)) ||
                (currentStep === 3 && !isStep3Valid()) || 
                (currentStep === 5 && (!localCharacter.activePrimaryWeapon || !localCharacter.activeArmor)) || // Ensure primary weapon and armor are selected
                (currentStep === 9 && localCharacter.domainCards.length !== 2) || // Ensure 2 domain cards
                (currentStep === 10 && (!localCharacter.name.trim() || !localCharacter.experiences[0]?.text.trim() || !localCharacter.experiences[1]?.text.trim()))
            }
        >
          {currentStep === TOTAL_STEPS ? 'Finish & View Sheet' : 'Next'}
        </Button>
      </div>
       {currentStep === 1 && (!localCharacter.class || !localCharacter.subclass) && (
        <p className="text-xs text-yellow-400 text-right mt-1">Please select a Class and Subclass to proceed.</p>
      )}
       {currentStep === 2 && (!localCharacter.ancestry || !localCharacter.community) && (
        <p className="text-xs text-yellow-400 text-right mt-1">Please select an Ancestry and a Community to proceed.</p>
      )}
       {currentStep === 5 && (!localCharacter.activePrimaryWeapon || !localCharacter.activeArmor) && (
        <p className="text-xs text-yellow-400 text-right mt-1">Please select a Primary Weapon and Armor to proceed.</p>
      )}
       {currentStep === 9 && localCharacter.domainCards.length !== 2 && (
        <p className="text-xs text-yellow-400 text-right mt-1">Please select exactly 2 domain cards.</p>
      )}
       {currentStep === 10 && (!localCharacter.name.trim() || !localCharacter.experiences[0]?.text.trim() || !localCharacter.experiences[1]?.text.trim()) && (
        <p className="text-xs text-yellow-400 text-right mt-1">Please complete name and both experiences to finish.</p>
      )}
    </div>
  );
};

export default CharacterCreator;
