
import React from 'react';

interface ErrorDisplayProps {
  message: string | null;
}

const ErrorDisplay: React.FC<ErrorDisplayProps> = ({ message }) => {
  if (!message) return null;
  return (
    <div className="my-4 p-3 bg-red-700 border border-red-900 text-white rounded-md shadow-lg">
      <p className="font-semibold">Error:</p>
      <p>{message}</p>
    </div>
  );
};

export default ErrorDisplay;
