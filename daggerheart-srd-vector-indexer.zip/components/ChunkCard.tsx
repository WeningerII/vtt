
import React, { useState } from 'react';
import { ProcessedChunk, InteractiveTermConfig } from '../types'; // Updated import
import InteractiveTextRenderer from './common/InteractiveTextRenderer';

interface ChunkCardProps {
  chunk: ProcessedChunk;
  isSearchResult?: boolean;
  interactiveTerms: InteractiveTermConfig[]; // Updated prop type
  onTermClick: (term: InteractiveTermConfig) => void; // Updated prop type
}

const ChunkCard: React.FC<ChunkCardProps> = ({ chunk, isSearchResult = false, interactiveTerms = [], onTermClick }) => {
  const [isExpanded, setIsExpanded] = useState(isSearchResult);

  return (
    <div className="mb-6 bg-slate-800 border border-slate-700 rounded-lg shadow-xl transition-all duration-300 ease-in-out overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full p-4 text-left bg-slate-700 hover:bg-slate-600 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500"
        aria-expanded={isExpanded}
        aria-controls={`chunk-content-${chunk.id}`}
      >
        <h3 className="text-lg font-semibold text-sky-400 flex justify-between items-center">
          <span>{chunk.title} (ID: {chunk.id})</span>
          <span className={`transform transition-transform duration-200 ${isExpanded ? 'rotate-180' : 'rotate-0'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
            </svg>
          </span>
        </h3>
      </button>
      
      {isExpanded && (
        <div id={`chunk-content-${chunk.id}`} className="p-4 border-t border-slate-700">
          <div className="mb-4">
            <h4 className="text-md font-semibold text-sky-300 mb-1">Summary:</h4>
            <p className="text-sm text-slate-300 whitespace-pre-line">
              <InteractiveTextRenderer text={chunk.summary} terms={interactiveTerms} onTermClick={onTermClick} />
            </p>
          </div>
          <div className="mb-4">
            <h4 className="text-md font-semibold text-sky-300 mb-1">Keywords:</h4>
            <div className="flex flex-wrap gap-2">
              {chunk.keywords.map((keyword, index) => (
                <span key={index} className="bg-sky-700 text-sky-100 text-xs px-2 py-1 rounded-full">
                  {keyword}
                </span>
              ))}
            </div>
          </div>
           <div className="mt-4 max-h-96 overflow-y-auto p-3 bg-slate-900 rounded scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-slate-800">
            <div className="flex justify-between items-center mb-2">
              <h4 className="text-md font-semibold text-sky-300">Original Content:</h4>
              {chunk.contentTruncated && (
                <span className="text-xs text-amber-400 italic">(Content summarized due to length)</span>
              )}
            </div>
            <div className="text-xs text-slate-400 whitespace-pre-wrap break-words font-sans">
              <InteractiveTextRenderer text={chunk.content} terms={interactiveTerms} onTermClick={onTermClick} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChunkCard;
