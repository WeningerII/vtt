
import React from 'react';
import { ProcessedChunk, InteractiveTermConfig } from '../types'; // Updated import
import ChunkCard from './ChunkCard';
import { Card } from './common/Card';

interface GameMechanicsDetailsProps {
  processedChunks: ProcessedChunk[];
  interactiveTerms: InteractiveTermConfig[]; // Updated prop type
  onTermClick: (term: InteractiveTermConfig) => void; // Updated prop type
}

const MECHANICS_CHUNK_TITLE = "CORE MECHANICS > Making Moves & Taking Action";

const GameMechanicsDetails: React.FC<GameMechanicsDetailsProps> = ({ processedChunks, interactiveTerms, onTermClick }) => {
  const mechanicsChunk = processedChunks.find(
    pChunk => pChunk.title.trim().toUpperCase() === MECHANICS_CHUNK_TITLE.toUpperCase()
  );

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold text-sky-400 text-center mb-8" style={{ fontFamily: "'Orbitron', sans-serif" }}>
        Detailed Game Mechanics
      </h2>
      {mechanicsChunk ? (
        <ChunkCard 
            chunk={mechanicsChunk} 
            isSearchResult={true} 
            interactiveTerms={interactiveTerms}
            onTermClick={onTermClick}
        />
      ) : (
        <Card>
          <p className="text-slate-400 text-center py-8">
            Detailed game mechanics section not found.
            Please ensure the SRD document has been processed via the "SRD Indexer" tab.
            The required chunk is "{MECHANICS_CHUNK_TITLE}".
          </p>
        </Card>
      )}
    </div>
  );
};

export default GameMechanicsDetails;
