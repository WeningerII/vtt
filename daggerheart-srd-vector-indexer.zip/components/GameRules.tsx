
import React, { useState } from 'react';
import { ProcessedChunk, InteractiveTermConfig } from '../types'; // Updated import
import { Card } from './common/Card';
import { Button } from './common/Button';

// Import new rule-specific components
import FlowOfTheGameRules from './rules/FlowOfTheGameRules';
import CoreGameplayLoopRules from './rules/CoreGameplayLoopRules';
import CombatRules from './rules/CombatRules';
import StressRules from './rules/StressRules';
import AttackingRules from './rules/AttackingRules';
import MapsRangeMovementRules from './rules/MapsRangeMovementRules';
import ConditionsRules from './rules/ConditionsRules';
import DowntimeRules from './rules/DowntimeRules';
import DeathRules from './rules/DeathRules';
import TheSpotlightRules from './rules/TheSpotlightRules';
import TurnOrderActionEconomyRules from './rules/TurnOrderActionEconomyRules';
import MakingMovesTakingActionRules from './rules/MakingMovesTakingActionRules';
import AdditionalRules from './rules/AdditionalRules';
import LevelingUpRules from './rules/LevelingUpRules'; 
import MulticlassingRules from './rules/MulticlassingRules'; 

// Props for individual rule components
export interface RuleDisplayComponentProps {
  chunk?: ProcessedChunk | undefined; 
  ruleDisplayName: string;
  interactiveTerms: InteractiveTermConfig[]; // Updated prop type
  onTermClick: (term: InteractiveTermConfig) => void; // Updated prop type
}

interface RuleCategory {
  id: string;
  displayName: string;
  srdChunkTitle?: string; 
  component: React.FC<RuleDisplayComponentProps>;
}

interface GameRulesProps {
  processedChunks: ProcessedChunk[];
  interactiveTerms: InteractiveTermConfig[]; // Updated prop type
  onTermClick: (term: InteractiveTermConfig) => void; // Updated prop type
}

export const RULE_CATEGORIES: readonly RuleCategory[] = [
  { component: FlowOfTheGameRules, id: "flow", srdChunkTitle: "CORE MECHANICS > Flow of the Game", displayName: "Flow of the Game" },
  { component: CoreGameplayLoopRules, id: "gameplayLoop", srdChunkTitle: "CORE MECHANICS > Core Gameplay Loop", displayName: "Core Gameplay Loop" },
  { component: TheSpotlightRules, id: "spotlight", srdChunkTitle: "CORE MECHANICS > The Spotlight", displayName: "The Spotlight" },
  { component: TurnOrderActionEconomyRules, id: "turnOrder", srdChunkTitle: "CORE MECHANICS > Turn Order & Action Economy", displayName: "Turn Order & Action Economy" },
  { component: MakingMovesTakingActionRules, id: "makingMoves", srdChunkTitle: "CORE MECHANICS > Making Moves & Taking Action", displayName: "Making Moves & Taking Action" },
  { component: CombatRules, id: "combat", srdChunkTitle: "CORE MECHANICS > Combat", displayName: "Combat" },
  { component: StressRules, id: "stress", srdChunkTitle: "CORE MECHANICS > Stress", displayName: "Stress" },
  { component: AttackingRules, id: "attacking", srdChunkTitle: "CORE MECHANICS > Attacking", displayName: "Attacking" },
  { component: MapsRangeMovementRules, id: "movement", srdChunkTitle: "CORE MECHANICS > Maps, Range, AND Movement", displayName: "Maps, Range & Movement" },
  { component: ConditionsRules, id: "conditions", srdChunkTitle: "CORE MECHANICS > Conditions", displayName: "Conditions" },
  { component: DowntimeRules, id: "downtime", srdChunkTitle: "CORE MECHANICS > Downtime", displayName: "Downtime" }, 
  { component: DeathRules, id: "death", srdChunkTitle: "CORE MECHANICS > Death", displayName: "Death" }, 
  { component: AdditionalRules, id: "additionalRulesGeneral", srdChunkTitle: "CORE MECHANICS > Additional Rules", displayName: "Misc Rules" }, 
  { component: LevelingUpRules, id: "levelingUp", srdChunkTitle: "CORE MECHANICS > Additional Rules", displayName: "Leveling Up" }, // Uses "Additional Rules" chunk as base
  { component: MulticlassingRules, id: "multiclassing", srdChunkTitle: "CORE MECHANICS > Additional Rules", displayName: "Multiclassing" } // Uses "Additional Rules" chunk as base
] as const;

type RuleCategoryId = typeof RULE_CATEGORIES[number]['id'];

const GameRules: React.FC<GameRulesProps> = ({ processedChunks, interactiveTerms, onTermClick }) => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<RuleCategoryId>(RULE_CATEGORIES[0].id);

  const selectedRuleDefinition = RULE_CATEGORIES.find(cat => cat.id === selectedCategoryId);
  const SelectedComponent = selectedRuleDefinition?.component;

  const relevantChunk = (selectedRuleDefinition && selectedRuleDefinition.srdChunkTitle)
    ? processedChunks.find(pChunk => pChunk.title.trim().toUpperCase() === selectedRuleDefinition.srdChunkTitle!.toUpperCase())
    : undefined;

  return (
    <div className="max-w-5xl mx-auto">
      <h2 className="text-3xl font-bold text-sky-400 text-center mb-6" style={{ fontFamily: "'Orbitron', sans-serif" }}>
        Core Game Rules
      </h2>

      <nav className="mb-8 flex flex-wrap justify-center gap-2 sm:gap-3">
        {RULE_CATEGORIES.map(category => (
          <Button
            key={category.id}
            onClick={() => setSelectedCategoryId(category.id)}
            variant={selectedCategoryId === category.id ? 'primary' : 'secondary'}
            size="sm"
            aria-current={selectedCategoryId === category.id ? 'page' : undefined}
          >
            {category.displayName}
          </Button>
        ))}
      </nav>

      <div className="mt-6">
        {SelectedComponent && selectedRuleDefinition ? (
          <SelectedComponent 
            chunk={relevantChunk} 
            ruleDisplayName={selectedRuleDefinition.displayName} 
            interactiveTerms={interactiveTerms}
            onTermClick={onTermClick}
          />
        ) : (
          <Card>
            <p className="text-slate-400 text-center py-8">
              Please select a rule category to view its details.
            </p>
          </Card>
        )}
      </div>
    </div>
  );
};

export default GameRules;
