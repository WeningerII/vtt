
export interface RawChunk {
  id: string;
  title: string;
  content: string;
}

export interface ProcessedChunk extends RawChunk {
  summary: string;
  keywords: string[];
  contentTruncated?: boolean;
}

export interface SearchResultItem extends ProcessedChunk {
  relevance?: number; 
}

export interface GeminiSummaryKeywords {
  summary: string;
  keywords: string[];
}

export interface GeminiRelevantIndices {
  relevantIndices: number[];
}

export interface GeminiPdfSection {
  title: string;
  content: string;
  summary:string;
  keywords: string[];
  contentTruncated?: boolean;
}


export enum LoadingState {
  IDLE = 'idle', 
  CHUNKING = 'chunking', 
  PROCESSING_TEXT_CHUNKS = 'processing_text_chunks', 
  PROCESSING_PDF_STRUCTURE = 'processing_pdf_structure', 
  PROCESSING_PDF_SECTIONS = 'processing_pdf_sections',   
  SEARCHING = 'searching', 
}

// --- Character Creator Types ---

export interface FeatureEntry {
  name: string;
  source: string; // e.g., "Class: Bard", "Ancestry: Elf"
  description: string;
}

export interface Trait {
  name: string;
  value: number;
}

export interface CombatStat {
  current: number;
  max: number;
}

export interface DamageThresholds {
  major: number;
  severe: number;
}

export interface CharacterExperience {
  text: string;
  modifier: number;
}

export interface Gold {
  handfuls: number;
}

export interface SubclassFeature {
  name: string;
  description: string;
  featureType: 'Foundation' | 'Specialization' | 'Mastery';
}

export interface Subclass {
  name: string;
  spellcastTrait?: string; 
  features: SubclassFeature[];
}

export interface ClassFeature {
    name: string;
    description: string;
}

export interface ClassData {
  id: string;
  name: string;
  startingHP: number;
  startingEvasion: number;
  classItems: string;
  domains: string[];
  classFeature: ClassFeature; // Combined name & description for simplicity from SRD layout
  hopeFeature: ClassFeature; // Combined name & description
  subclasses: Subclass[];
}

export interface AncestryFeature {
  name: string;
  description: string;
}

export interface Ancestry {
  id: string;
  name: string;
  features: AncestryFeature[]; // Expecting two features
}

export interface CommunityFeature {
  name: string;
  description: string;
}

export interface Community {
  id: string;
  name: string;
  feature: CommunityFeature;
}

export interface Weapon {
  id: string;
  name: string;
  tier: number;
  category: 'Primary' | 'Secondary';
  trait: string; 
  range: string;
  damage: string; // e.g., "d8 phy", "d10+3 mag"
  burden: string; // e.g., "One-Handed", "Two-Handed"
  feature: string; // "—" if no feature
}

export interface Armor {
  id: string;
  name: string;
  tier: number;
  baseScore: number;
  baseThresholds: string; // e.g., "5 / 11"
  feature: string; // "—" if no feature
}

export interface DomainCard {
  id: string;
  name: string;
  domain: string;
  level: number;
  type: 'Ability' | 'Spell' | 'Grimoire'; 
  description: string;
  recallCost: number;
}

export interface CharacterData {
  name: string;
  pronouns: string;
  description: string; 
  level: number;
  class: ClassData | null;
  subclass: Subclass | null;
  ancestry: Ancestry | null;
  community: Community | null;
  traits: Trait[];
  hp: CombatStat;
  evasion: number;
  armorScore: number;
  damageThresholds: DamageThresholds;
  stress: CombatStat;
  hope: CombatStat;
  proficiency: number;
  experiences: CharacterExperience[];
  inventory: string[]; 
  gold: Gold;
  activePrimaryWeapon: Weapon | null;
  activeSecondaryWeapon: Weapon | null;
  activeArmor: Armor | null;
  domainCards: DomainCard[]; 
  connections: string; 
  background?: string; 
  features: FeatureEntry[]; 
}

// Base type for items that might be rolled or chosen
export interface BaseItemData {
    id: string;
    name: string;
    description: string;
    srdPage?: number; // For easy reference
    srdRoll?: number; // For items from dX roll tables, -1 if choice
}

export interface PotionChoice extends BaseItemData {} // Specifically for starting potion choices

export interface LootItemData extends BaseItemData {} // For general loot table items

export interface ConsumableItemData extends BaseItemData {} // For consumable items

export interface BeastformData {
  id: string;
  name: string; // e.g., "Agile Scout (Fox, Mouse, Weasel, etc.)"
  tier: number;
  description: string; // Could combine Creature Category, Character Trait, Attack Rolls, Evasion, Advantages and Features here
  features: string[]; // List of specific named features like "Agile", "Fragile"
  evasionBonus: number; // e.g., +2 for Agile Scout
  attackTrait: string; // e.g., "Agility" for Agile Scout. Damage dice part of description or a new field if needed.
}

export interface ConditionData {
  id: string; // e.g., "vulnerable"
  name: string; // e.g., "Vulnerable"
  description: string; // General description of the condition
  effectsSummary: string; // Brief summary of mechanical effects found in the SRD or inferred
  srdPageReference?: string; // e.g., "SRD p. 45" or specific spell/ability page
}

export interface GameTermData {
  id: string; 
  name: string; 
  description: string;
  srdPageReference?: string; 
}

export interface SRDData {
  classes: ClassData[];
  ancestries: Ancestry[];
  communities: Community[];
  weapons: Weapon[];
  armor: Armor[];
  domainCards: DomainCard[];
  lootItems?: LootItemData[];
  consumableItems?: ConsumableItemData[];
  startingPotionChoices?: PotionChoice[]; 
  beastforms?: BeastformData[]; 
  conditions?: ConditionData[];
  gameTerms?: GameTermData[]; // Added GameTerms
}

export type AppView = 
  | 'dashboard' 
  | 'indexer' 
  | 'creator' 
  | 'sheet' 
  | 'rules' 
  | 'mechanics'
  | 'startingCampaign'
  | 'gmTools'
  | 'domainCardsRef'
  | 'equipment'
  | 'tabletop' // Added new view for Virtual Tabletop
  | 'itemDetail'; // Added for future generic item detail views

// --- Interactive Term Types ---
export interface InteractiveTermActionDetails {
  type: 'modal' | 'navigate' | 'filter';
  targetView?: AppView; // For 'navigate' or 'filter'
  targetId?: string; // e.g., classId, itemId, ancestryId, communityId for pre-selection
  filterContext?: Record<string, any>; // For complex filtering (e.g., pre-filter Domain Cards by domain name)
  // Data for the modal, if type is 'modal'. Can be ConditionData, GameTermData, or a simplified structure
  modalData?: { 
    id: string;
    name: string;
    description: string;
    effectsSummary?: string;
    srdPageReference?: string;
  };
}

export interface InteractiveTermConfig {
  id: string; // Unique ID for the term config, e.g., "condition-vulnerable", "class-bard"
  name: string; // The term name to match in text, e.g., "Vulnerable", "Bard"
  action: InteractiveTermActionDetails;
  // Optional: Store original data if needed for specific modal types or other logic
  originalTermData?: ConditionData | GameTermData | ClassData | Ancestry | Community | DomainCard | Weapon | Armor; 
}

// --- Virtual Tabletop Types ---
export interface VTTToken {
  id: string;
  x: number; // grid column index
  y: number; // grid row index
  color: string;
  label?: string; // Optional label
  size: number; // 1 for 1x1, 2 for 2x2 etc.
}

export interface VTTGridConfig {
  rows: number;
  cols: number;
  cellSize: number; // in pixels
}

export interface VTTTurn {
  id: string;
  name: string;
  type: 'player' | 'npc'; // Could expand later
}
