
import {
  MAJOR_SECTIONS,
  INTRODUCTION_SUB_TITLES,
  STARTING_A_CAMPAIGN_SUB_TITLES,
  SUB_SECTIONS_CORE_MATERIALS,
  CLASS_TITLES,
  ANCESTRY_TITLES,
  COMMUNITY_TITLES,
  DOMAIN_DESCRIPTION_TITLES,
  CORE_MECHANICS_SUB_TITLES,
  SUB_SECTIONS_EQUIPMENT,
  RUNNING_AN_ADVENTURE_SUB_TITLES,
  SUB_SECTIONS_APPENDIX,
  DOMAIN_CARD_REFERENCE_TITLES,
} from '../constants/srd-structure';
import { RawChunk } from '../types';

const MIN_CHUNK_LENGTH = 50; // Minimum characters for a chunk to be considered substantial

// Helper function to escape special characters for use in a regular expression
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
}

const cleanText = (text: string): string => {
  let cleaned = text.replace(/Daggerheart SRD \d+/g, ''); // Remove SRD page footers/headers
  cleaned = cleaned.replace(/\r\n/g, '\n'); // Normalize line endings
  cleaned = cleaned.replace(/\n\s*\n/g, '\n\n'); // Normalize multiple blank lines
  return cleaned.trim();
};

const createChunk = (
  title: string,
  content: string,
  chunksArray: RawChunk[],
  idCounterRef: React.MutableRefObject<number>
) => {
  const trimmedContent = content.trim();
  if (trimmedContent.length > MIN_CHUNK_LENGTH) {
    chunksArray.push({ id: `chunk-${idCounterRef.current++}`, title, content: trimmedContent });
  }
};

const findAndChunkSectionsRecursive = (
  textToSearch: string,
  sectionTitles: string[],
  parentPath: string,
  chunksArray: RawChunk[],
  idCounterRef: React.MutableRefObject<number>,
  depth: number
) => {
  let currentSearchStartIndex = 0;

  for (let i = 0; i < sectionTitles.length; i++) {
    const currentTitle = sectionTitles[i];
    const currentFullPath = parentPath ? `${parentPath} > ${currentTitle}` : currentTitle;
    const nextTitle = (i + 1 < sectionTitles.length) ? sectionTitles[i + 1] : null;
    
    const titlePattern = currentTitle
      .split(' ')
      .map(part => escapeRegExp(part))
      .join('[\\s\\n]+');

    // Regex to find the title line. It captures:
    // Group 1: The core title pattern (e.g., "Making Moves & Taking Action").
    // Group 2: Any trailing characters on the same line before the newline (e.g., " . . . page_number").
    // Group 3: The terminating newline or end-of-string.
    const currentTitleLineRegex = new RegExp(
      `(?:^|\\n)(${titlePattern})([^\\n]*?)(\\n|$)`, 
      "i"
    );

    let titleMatch: RegExpMatchArray | null = null;
    let searchSegment = textToSearch.substring(currentSearchStartIndex);
    titleMatch = searchSegment.match(currentTitleLineRegex);

    if (titleMatch && titleMatch.index !== undefined) {
        // titleMatch[0] is the entire matched line, e.g., "\nMaking Moves & Taking Action . . . 40\n"
        // titleMatch[1] is the part matched by titlePattern, e.g., "Making Moves & Taking Action"
        
        const fullMatchStartInSegment = titleMatch.index;
        const fullMatchLength = titleMatch[0].length; // Length of the entire matched line including newline
        
        // Content starts immediately after the full matched line.
        let contentStartIndex = currentSearchStartIndex + fullMatchStartInSegment + fullMatchLength;
        
        let contentEndIndex = textToSearch.length;

        if (nextTitle) {
            const nextTitlePattern = nextTitle.split(' ').map(part => escapeRegExp(part)).join('[\\s\\n]+');
            // Use a similar regex for finding the start of the next title line.
            // We only care about the index of this match.
            const nextTitleLineStartRegex = new RegExp(
              `(?:^|\\n)(?:${nextTitlePattern})[^\\n]*?(?:\\n|$)`,
              "i" // Only need "i" flag if searching globally, but for a single find, it's fine.
            );
            
            // Search for the next title starting from *after* the current title's line.
            // ContentStartIndex is already after the current title line.
            let searchForNextTitleSegment = textToSearch.substring(contentStartIndex);
            let nextTitleMatchResult = searchForNextTitleSegment.match(nextTitleLineStartRegex);

            if (nextTitleMatchResult && nextTitleMatchResult.index !== undefined) {
                // nextTitleMatchResult.index is relative to searchForNextTitleSegment.
                // This index marks the beginning of the next title's line.
                contentEndIndex = contentStartIndex + nextTitleMatchResult.index;
            }
        }
        
        if (contentStartIndex > contentEndIndex) {
            contentStartIndex = contentEndIndex; // Avoid negative length slicing
        }

        const currentBlockContent = textToSearch.substring(contentStartIndex, contentEndIndex);
        // The next search should start from where this block's content ended.
        currentSearchStartIndex = contentEndIndex; 

        let subChunked = false;
        if (currentTitle.toUpperCase() === "INTRODUCTION" && depth === 0) {
          findAndChunkSectionsRecursive(currentBlockContent, INTRODUCTION_SUB_TITLES, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "STARTING A CAMPAIGN" && depth === 0) {
          findAndChunkSectionsRecursive(currentBlockContent, STARTING_A_CAMPAIGN_SUB_TITLES, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "CORE MATERIALS" && depth === 0) {
          findAndChunkSectionsRecursive(currentBlockContent, SUB_SECTIONS_CORE_MATERIALS, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "CLASSES" && currentFullPath.toUpperCase().includes("CORE MATERIALS > CLASSES")) {
          findAndChunkSectionsRecursive(currentBlockContent, CLASS_TITLES, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "ANCESTRIES" && currentFullPath.toUpperCase().includes("CORE MATERIALS > ANCESTRIES")) {
          findAndChunkSectionsRecursive(currentBlockContent, ANCESTRY_TITLES, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "COMMUNITIES" && currentFullPath.toUpperCase().includes("CORE MATERIALS > COMMUNITIES")) {
          findAndChunkSectionsRecursive(currentBlockContent, COMMUNITY_TITLES, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "DOMAINS" && currentFullPath.toUpperCase().includes("CORE MATERIALS > DOMAINS")) {
          findAndChunkSectionsRecursive(currentBlockContent, DOMAIN_DESCRIPTION_TITLES, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "CORE MECHANICS" && depth === 0) {
          findAndChunkSectionsRecursive(currentBlockContent, CORE_MECHANICS_SUB_TITLES, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "EQUIPMENT" && depth === 0) {
          findAndChunkSectionsRecursive(currentBlockContent, SUB_SECTIONS_EQUIPMENT, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "RUNNING AN ADVENTURE" && depth === 0) {
          findAndChunkSectionsRecursive(currentBlockContent, RUNNING_AN_ADVENTURE_SUB_TITLES, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "APPENDIX" && depth === 0) {
          findAndChunkSectionsRecursive(currentBlockContent, SUB_SECTIONS_APPENDIX, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        } else if (currentTitle.toUpperCase() === "DOMAIN CARD REFERENCE" && currentFullPath.toUpperCase().includes("APPENDIX > DOMAIN CARD REFERENCE")) {
          findAndChunkSectionsRecursive(currentBlockContent, DOMAIN_CARD_REFERENCE_TITLES, currentFullPath, chunksArray, idCounterRef, depth + 1);
          subChunked = true;
        }

        if (!subChunked && currentBlockContent.trim()) {
          createChunk(currentFullPath, currentBlockContent, chunksArray, idCounterRef);
        }
    } else {
      // Title not found
      // console.warn(`Title "${currentTitle}" (path: "${currentFullPath}") not found using robust regex. Search started at index ${currentSearchStartIndex}. Segment head: ${searchSegment.substring(0,100)}`);
      // If a major section title isn't found, it might skew subsequent searches if currentSearchStartIndex isn't updated.
      // However, if it's just a sub-title not found, the loop continues, and currentSearchStartIndex would be from the last *found* title.
      // This behavior is generally acceptable as it tries to find subsequent titles in the remaining text.
      continue; 
    }
  }
};

export const chunkSRDDocument = (
  srdText: string,
  idCounterRef: React.MutableRefObject<number>
): RawChunk[] => {
  if (!srdText) return [];
  
  idCounterRef.current = 0; 
  const cleanedText = cleanText(srdText);
  const chunks: RawChunk[] = [];
  
  findAndChunkSectionsRecursive(cleanedText, MAJOR_SECTIONS, "", chunks, idCounterRef, 0);

  return chunks.filter(c => c.content.length > 0);
};
