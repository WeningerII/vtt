
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GeminiSummaryKeywords, ProcessedChunk, GeminiPdfSection } from '../types';
import { GEMINI_MODEL_TEXT } from '../constants';

// GEMINI_API_KEY is defined via Vite and also aliased as process.env.API_KEY.
// Prefer GEMINI_API_KEY directly to avoid confusion.
const API_KEY = process.env.GEMINI_API_KEY || process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable (expected as GEMINI_API_KEY or API_KEY) is not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const parseJsonFromText = <T,>(textInput: string | undefined | null): T | null => {
  if (textInput === null || typeof textInput === 'undefined') {
    console.error("Input to parseJsonFromText was null or undefined.");
    return null;
  }
  const text = textInput as string;
  const trimmedText = text.trim();

  try {
    if (trimmedText.startsWith('{') || trimmedText.startsWith('[')) {
      return JSON.parse(trimmedText) as T;
    }
    
    const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
    const match = trimmedText.match(fenceRegex);
    if (match && match[1]) {
      return JSON.parse(match[1].trim()) as T;
    }

    console.warn("Text is a string but not a recognized JSON object/array and is not wrapped in JSON markdown fences. Input (first 300 chars):", text.substring(0, 300));
    return null;

  } catch (e: any) {
    console.error("Failed to parse JSON string:", e.message || e, "\nOriginal text for parsing (after initial trim, first 300 chars):", trimmedText.substring(0,300));
    return null;
  }
};

const fileToGenerativePart = async (file: File) => {
  const base64EncodedData = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
  return {
    inlineData: {
      data: base64EncodedData,
      mimeType: file.type,
    },
  };
};

async function makeApiCallWithRetry<T>(
  apiCall: () => Promise<T>,
  maxRetries: number = 3,
  initialBackoff: number = 1000, // milliseconds
  onRetryAttempt?: (attempt: number, error: any) => void
): Promise<T> {
  let attempt = 0;
  while (true) {
    try {
      return await apiCall();
    } catch (error: any) {
      attempt++;
      const message = String(error.message || '').toLowerCase();
      const isAuthError = message.includes("api key not valid") || 
                          message.includes("permission denied") || 
                          message.includes("authentication failed") ||
                          (error.status === 401) || (error.status === 403);
      const isBadRequest = message.includes("invalid request") || 
                           message.includes("bad request") || 
                           message.includes("not found") ||
                           (error.status === 400) || (error.status === 404);
      // Rate limit (429) or server errors (5xx) are typically retryable
      const isRateLimitOrServerError = (error.status === 429) || (error.status && error.status >= 500);
      
      // Determine if this specific error is retryable
      let shouldRetry = isRateLimitOrServerError || (!isAuthError && !isBadRequest);
      // If the error message suggests a network issue, it's definitely retryable.
      if (message.includes("network error") || message.includes("failed to fetch") || message.includes("timeout")) {
          shouldRetry = true;
      }


      if (!shouldRetry || attempt > maxRetries) {
        console.error(`API call failed. Attempt ${attempt}/${maxRetries}. Non-retryable or max retries exceeded. Error:`, error);
        throw error;
      }
      
      if (onRetryAttempt) {
        onRetryAttempt(attempt, error);
      }

      const waitTime = initialBackoff * (2 ** (attempt - 1)); // Exponential backoff
      console.warn(`API call attempt ${attempt} failed. Retrying in ${waitTime}ms... Error:`, error.message);
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
  }
}

export const processPdfAndExtractStructuredData = async (
  pdfFile: File,
  updateProgress?: (message: string) => void
): Promise<ProcessedChunk[] | null> => {
  if (!API_KEY) {
    console.error("API Key not configured for processPdfAndExtractStructuredData.");
    if (updateProgress) updateProgress("Error: API Key not configured.");
    return null;
  }

  const allProcessedChunks: ProcessedChunk[] = [];
  let idCounter = 0; 

  try {
    if (updateProgress) updateProgress("Preparing PDF data...");
    const pdfPart = await fileToGenerativePart(pdfFile);

    if (updateProgress) updateProgress("Identifying document structure...");
    
    const structurePrompt = `You are an AI assistant specialized in analyzing PDF documents, particularly System Reference Documents (SRDs). Your task is to identify the main sections or chapters from the provided PDF.
    - Analyze the document structure, paying attention to headings, subheadings, and any table of contents.
    - Extract the titles of these major sections.
    - Return these titles as a JSON array of strings. For example: ["Introduction", "Character Creation", "Core Mechanics", "Equipment"].
    - Ensure the output is ONLY the JSON array, correctly formatted. Strive for a comprehensive list of top-level sections that cover the entire document. Do not include page numbers or very minor sub-sub-headings in this initial list. Focus on the primary organizational units.
    - If the document is very short or has no discernible major sections, return an empty array [].`;

    const structureResponse: GenerateContentResponse = await makeApiCallWithRetry(
        () => ai.models.generateContent({
            model: GEMINI_MODEL_TEXT,
            contents: { parts: [pdfPart, { text: structurePrompt }] },
            config: {
                responseMimeType: "application/json",
                temperature: 0.1,
                maxOutputTokens: 2048
            }
        }),
        3, 1000,
        (attempt, err) => {
            if (updateProgress) updateProgress(`Identifying document structure (retry ${attempt}/3)...`);
        }
    );

    const structureResponseText = (structureResponse as any)?.text;
    if (!structureResponse || !structureResponseText) { 
      let reason = "Unknown reason.";
      if (!structureResponse) reason = "structureResponse object itself is falsy.";
      else if (structureResponseText === null) reason = "structureResponse.text is null.";
      else if (typeof structureResponseText === 'undefined') reason = "structureResponse.text is undefined.";
      else if (structureResponseText === "") reason = "structureResponse.text is an empty string.";
      else reason = `structureResponse.text is falsy but not null/undefined/empty: '${structureResponseText}' (type: ${typeof structureResponseText}).`;
      
      console.error("Gemini API did not return a usable (non-empty) string for document structure text. Reason:", reason, "Full response object (if available):", structureResponse);
      if (updateProgress) updateProgress("Error: AI service failed to provide document structure text. Response was empty, null, or malformed. Attempting fallback.");
    }

    const sectionTitles = parseJsonFromText<string[]>(structureResponseText);

    if (!sectionTitles || !Array.isArray(sectionTitles)) {
      console.error("Failed to extract section titles from PDF or response was not an array.", "Response text from structure prompt:", structureResponseText);
      if (updateProgress && sectionTitles === null && structureResponseText && structureResponseText.trim() !== "" && !structureResponseText.trim().startsWith("[") && !structureResponseText.trim().startsWith("{")) {
         updateProgress("Warning: Document structure response from AI was not valid JSON. Attempting single section fallback.");
      } else if (updateProgress) {
        updateProgress("Error: Could not identify document structure. The PDF might be unparsable or the response was malformed. Attempting fallback.");
      }
    }
    
    if (!sectionTitles || sectionTitles.length === 0) { 
      if (updateProgress) updateProgress("No major sections identified or structure parsing failed. Attempting to process as a single large section.");
      const singleSectionPrompt = `You are an AI assistant specialized in parsing and structuring complex documents, particularly System Reference Documents (SRDs) for tabletop roleplaying games. The user has uploaded a PDF of an SRD. Your task is to:
      1. Treat the entire document as a single section.
      2. For this single section, extract:
          a. "title": Use the document's filename or a generic title like "Full Document".
          b. "content": The text content of the document. If this content is very long (e.g., over ~1500 words or ~7000 characters), provide a detailed, multi-paragraph summary of its content instead of the full text, and set a flag '\"contentTruncated\": true' in the JSON object for this section. Otherwise, provide the full text content and omit the 'contentTruncated' flag or set it to false.
          c. "summary": A concise summary (2-4 sentences) of the document's purpose and key information.
          d. "keywords": An array of 5-7 relevant keywords for the document.
      3. Return this information as a JSON array containing a SINGLE object with the keys "title", "content", "summary", "keywords", and optionally "contentTruncated".
      Example of a desired JSON object:
      [{"title": "Document Title", "content": "Text or summary of the document...", "summary": "This document outlines...", "keywords": ["keyword1", "keyword2"], "contentTruncated": false}]
      Ensure the output is ONLY the JSON array, correctly formatted. ALL JSON strings MUST be properly escaped and terminated.`;
      
      const singleSectionResponse = await makeApiCallWithRetry(
        () => ai.models.generateContent({
            model: GEMINI_MODEL_TEXT,
            contents: { parts: [pdfPart, { text: singleSectionPrompt }] },
            config: {
                responseMimeType: "application/json",
                temperature: 0.1,
                maxOutputTokens: 8192 
            }
        }),
        3, 1000,
        (attempt, err) => {
            if (updateProgress) updateProgress(`Processing as single section (retry ${attempt}/3)...`);
        }
      );
      
      const singleSectionResponseText = (singleSectionResponse as any)?.text;
      if (!singleSectionResponse || !singleSectionResponseText) {
        console.error("Gemini API did not return a usable string for single section fallback. Full response:", singleSectionResponse);
        if (updateProgress) updateProgress("Error: AI service failed to provide text for single section fallback.");
        return null;
      }

      const parsedResult = parseJsonFromText<GeminiPdfSection[]>(singleSectionResponseText);
      if (parsedResult && Array.isArray(parsedResult) && parsedResult.length > 0) {
        if (updateProgress) updateProgress("Processed PDF as a single section.");
        return parsedResult.map((section, index) => ({
          id: `pdf-section-fallback-${index}-${Date.now()}`,
          title: section.title || `Full Document Section ${index + 1}`,
          content: section.content || "No content extracted.",
          summary: section.summary || "No summary generated.",
          keywords: section.keywords || [],
          contentTruncated: section.contentTruncated || false,
        }));
      } else {
        if (updateProgress) updateProgress("Error: Failed to process PDF as a single section after structure identification failed.");
        console.error("Fallback to single section processing also failed or returned no data.", "Response text:", singleSectionResponseText);
        return null;
      }
    }

    if (updateProgress) updateProgress(`Found ${sectionTitles.length} sections. Processing each...`);

    for (let i = 0; i < sectionTitles.length; i++) {
      const sectionTitle = sectionTitles[i];
      const progressString = `Processing section ${i + 1}/${sectionTitles.length}: "${sectionTitle}"`;
      if (updateProgress) updateProgress(progressString);

      const sectionPrompt = `You are an AI assistant specialized in parsing and structuring documents.
      The user has provided a PDF document and identified a specific section titled "${sectionTitle}".
      Your task is to extract information FOR THIS SECTION ONLY from the PDF.
      1.  **Locate**: Find the content corresponding to the section titled "${sectionTitle}" in the PDF.
      2.  **Extract**:
          *   **"title"**: This MUST be exactly "${sectionTitle}".
          *   **"content"**: The text content of this section.
              CRITICALLY IMPORTANT: If the full text content for *this specific section* is very long (e.g., if its string representation would exceed approximately 6000 characters), YOU MUST provide a detailed, multi-paragraph summary of *this section's content* instead of the full text. The summary should capture the essence and key information of the section. In this case of summarization, YOU MUST include the field \`"contentTruncated": true\` in your JSON response.
              If the section primarily consists of a list of many small, distinct items (like spells, abilities, or glossary entries from a game's System Reference Document), and including all of them would make the content field exceed 6000 characters, summarize the *nature* of these items and state that the section contains a detailed list, rather than listing them all. For example: "This section contains a comprehensive list of Arcana domain spells, detailing each spell's level, recall cost, and effects." Then set \`"contentTruncated": true\`.
              Otherwise (if the content is short enough), include the full text and set \`"contentTruncated": false\` or omit this field.
          *   **"summary"**: A concise summary (2-4 sentences) of *this section's* overall purpose and key information. This summary should be generated even if the content field contains the full text.
          *   **"keywords"**: An array of 5-7 relevant keywords specifically for *this section*.
      3.  **Format**: Return this information as a SINGLE JSON OBJECT.
          Example: \`{"title": "${sectionTitle}", "content": "Full text or summary of this section...", "summary": "A concise summary of this section.", "keywords": ["specific", "keywords", "for", "this", "section"], "contentTruncated": false}\`
      IMPORTANT:
      - Output ONLY the single JSON object for the section "${sectionTitle}".
      - Ensure all string values in the JSON are properly escaped (e.g., newlines as \\n, quotes as \\").
      - Do NOT include content from other sections.
      - The total length of the generated JSON response, including all fields, must be managed to avoid exceeding API output limits. Prioritize summarization of the 'content' field for very long sections.
      - If the section "${sectionTitle}" cannot be found or is empty, return a JSON object with an empty content string and an appropriate summary/keywords indicating this.
      `;

      try {
        const sectionResponse: GenerateContentResponse = await makeApiCallWithRetry(
            () => ai.models.generateContent({
                model: GEMINI_MODEL_TEXT,
                contents: { parts: [pdfPart, { text: sectionPrompt }] }, 
                config: {
                    responseMimeType: "application/json",
                    temperature: 0.1,
                    maxOutputTokens: 8192 
                }
            }),
            3, 1000,
            (attempt, err) => {
                if (updateProgress) updateProgress(`${progressString} (retry ${attempt}/3)...`);
            }
        );
        
        const sectionResponseText = (sectionResponse as any)?.text;
        if (!sectionResponse || !sectionResponseText) {
            console.warn(`Gemini API did not return a usable string for section "${sectionTitle}". Skipping. Full response:`, sectionResponse);
            if (updateProgress) updateProgress(`Warning: AI service returned no text for section "${sectionTitle}". Skipping.`);
            allProcessedChunks.push({
              id: `pdf-error-no-text-${idCounter++}-${Date.now()}`,
              title: `${sectionTitle} (No Text From API)`,
              content: `Failed to get text content from Gemini for this section.`,
              summary: "Error during processing: no text content from API.",
              keywords: ["error", "pdf_section_no_text_api"],
              contentTruncated: true,
            });
            continue; 
        }

        const sectionData = parseJsonFromText<GeminiPdfSection>(sectionResponseText);

        if (sectionData && typeof sectionData === 'object' && sectionData.title) {
          allProcessedChunks.push({
            id: `pdf-section-${idCounter++}-${Date.now()}`,
            title: sectionData.title || sectionTitle, 
            content: sectionData.content || "No content extracted for this section.",
            summary: sectionData.summary || "No summary generated for this section.",
            keywords: sectionData.keywords || [],
            contentTruncated: sectionData.contentTruncated || false,
          });
        } else {
          console.warn(`Failed to process section "${sectionTitle}" or received malformed data. Skipping. Response text:`, sectionResponseText);
          if (updateProgress) updateProgress(`Warning: Could not fully process section "${sectionTitle}". Skipping.`);
          allProcessedChunks.push({
              id: `pdf-error-${idCounter++}-${Date.now()}`,
              title: `${sectionTitle} (Processing Error)`,
              content: `Failed to extract structured data for this section. Raw response (partial): ${typeof sectionResponseText === 'string' ? sectionResponseText.substring(0, 300) : '[No text in response]'}...`,
              summary: "Error during processing of this specific section.",
              keywords: ["error", "pdf_section_error"],
              contentTruncated: true,
          });
        }
      } catch (sectionError: any) {
        console.error(`Error processing section "${sectionTitle}":`, sectionError.message || sectionError);
        if (updateProgress) updateProgress(`Error processing section "${sectionTitle}". Skipping due to: ${sectionError.message.substring(0,50)}...`);
        allProcessedChunks.push({
            id: `pdf-exception-${idCounter++}-${Date.now()}`,
            title: `${sectionTitle} (Processing Exception)`,
            content: `An exception occurred while processing this section: ${sectionError.message}`,
            summary: "Exception during processing of this specific section.",
            keywords: ["error", "pdf_section_exception"],
            contentTruncated: true,
        });
      }
    }
    if (updateProgress) updateProgress("PDF processing complete. Index built.");
    return allProcessedChunks;

  } catch (error: any) {
    console.error("Error in processPdfAndExtractStructuredData (outer try-catch):", error.message || error);
    if (updateProgress) updateProgress(`Critical Error: ${error.message || 'Unknown error during PDF processing.'}`);
    if (error.message && error.message.includes("API key not valid")) {
        if (updateProgress) updateProgress("Error: API key not valid. Please check your configuration.");
    } else if (error.message && error.message.includes("quota")) {
        if (updateProgress) updateProgress("Error: API quota exceeded. Please try again later.");
    } else if (updateProgress) {
        updateProgress("PDF processing failed after retries. Check console for details.");
    }
    return null;
  }
};


export const generateSummaryAndKeywords = async (textChunk: string): Promise<GeminiSummaryKeywords | null> => {
  if (!API_KEY) {
    console.error("API Key not configured for generateSummaryAndKeywords.");
    return { summary: "API Key not configured.", keywords: ["error", "configuration"] };
  }
  try {
    const prompt = `Provide a concise summary and 5-7 relevant keywords for the following text. The text is a section from a System Reference Document for a tabletop roleplaying game called Daggerheart. Focus on the core rules, mechanics, and game terms mentioned.

Text:
---
${textChunk}
---

Format the output as JSON with two keys: "summary" (a string) and "keywords" (an array of strings). Example: {"summary": "This section explains character creation steps.", "keywords": ["character creation", "steps", "attributes", "classes"]}`;

    const response: GenerateContentResponse = await makeApiCallWithRetry(
      () => ai.models.generateContent({
          model: GEMINI_MODEL_TEXT,
          contents: prompt,
          config: {
              responseMimeType: "application/json",
              temperature: 0.3,
              maxOutputTokens: 1024 
          }
      })
    );
    
    const responseText = (response as any)?.text;
    if (!response || !responseText) {
        console.error("Gemini API did not return a usable string for summary/keywords. Full response:", response);
        return { summary: "Could not generate summary due to API error (no text response).", keywords: ["error", "api_no_text"] };
    }
    const parsedResult = parseJsonFromText<GeminiSummaryKeywords>(responseText);
    
    if (parsedResult && typeof parsedResult.summary === 'string' && Array.isArray(parsedResult.keywords)) {
        return parsedResult;
    } else {
        if (parsedResult !== null) {
             console.error("Invalid JSON structure received from Gemini for summary/keywords. Expected { summary: string, keywords: string[] }.", "Received text:", responseText, "Parsed object:", parsedResult);
        }
        return { summary: "Could not generate summary due to invalid format or API error.", keywords: ["error", "format_error"] };
    }

  } catch (error: any) {
    console.error("Error generating summary and keywords after retries:", error.message || error);
    return { summary: "Failed to generate summary/keywords after multiple attempts.", keywords: ["error", "api_failure_retries"] };
  }
};

export const findRelevantChunkIndices = async (
  query: string,
  chunkInfos: Array<{ id: string, summary: string; keywords: string[] }>
): Promise<number[]> => {
  if (!API_KEY) {
    console.error("API Key not configured for findRelevantChunkIndices.");
    return [];
  }
  if (chunkInfos.length === 0) return [];

  try {
    const formattedSummaries = chunkInfos
      .map((info, index) => `Index ${index}: (ID: ${info.id}) Summary: ${info.summary} (Keywords: ${info.keywords.join(', ')})`)
      .join('\n\n');

    const prompt = `You are assisting a user in searching a System Reference Document (SRD) for the Daggerheart roleplaying game. I will provide you with the user's query and a list of summaries (with their original indices and IDs) for different sections of the SRD. Identify which sections are most relevant to the user's query.

User Query: "${query}"

Section Summaries:
---
${formattedSummaries}
---

Based on the query and the section summaries, list the indices of the top 3-5 most relevant sections. Respond ONLY with a JSON array of numbers representing these indices, like [index1, index2, index3]. If no sections are relevant, return an empty array []. Do not include any other text, reasoning, or markdown formatting around the JSON array.`;
    
    const response: GenerateContentResponse = await makeApiCallWithRetry(
      () => ai.models.generateContent({
          model: GEMINI_MODEL_TEXT,
          contents: prompt,
          config: {
              responseMimeType: "application/json",
              temperature: 0.2,
              maxOutputTokens: 512 
          }
      })
    );

    const responseText = (response as any)?.text;
    if (!response || !responseText) {
        console.error("Gemini API did not return a usable string for relevant indices. Full response:", response);
        return [];
    }
    const rawParsedData: any = parseJsonFromText<any>(responseText);
    let relevantIndices: number[] | null = null;

    if (rawParsedData !== null) {
      if (Array.isArray(rawParsedData) && rawParsedData.every(item => typeof item === 'number')) {
        relevantIndices = rawParsedData as number[];
      } else if (typeof rawParsedData === 'object' && 'relevantIndices' in rawParsedData && Array.isArray(rawParsedData.relevantIndices) && rawParsedData.relevantIndices.every(item => typeof item === 'number')) {
        relevantIndices = rawParsedData.relevantIndices;
      } else {
        console.error("Parsed JSON for relevant indices was not in the expected array or {relevantIndices: array} format.", "Received text:", responseText, "Parsed data:", rawParsedData);
      }
    } 
    return relevantIndices || [];

  } catch (error: any) {
    console.error("Error finding relevant chunks after retries:", error.message || error);
    return [];
  }
};
