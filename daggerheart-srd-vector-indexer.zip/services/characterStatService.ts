
import { CharacterData, ClassData, Ancestry, Armor, Trait, FeatureEntry, DamageThresholds, Weapon, Community, Subclass } from '../types';
import { DEFAULT_CHARACTER_DATA } from '../constants';

// Function to gather all features from class, subclass, ancestry, community
export const getCharacterFeatures = (character: CharacterData | null): FeatureEntry[] => {
  const features: FeatureEntry[] = [];
  if (!character) return features;

  if (character.class) {
    features.push({ 
      name: character.class.classFeature.name, 
      source: `Class: ${character.class.name}`, 
      description: character.class.classFeature.description 
    });
    features.push({ 
      name: character.class.hopeFeature.name, 
      source: `Class: ${character.class.name} (Hope)`, 
      description: character.class.hopeFeature.description 
    });
  }
  if (character.subclass) {
    // Only include Foundation features for now, as Specialization/Mastery are gained via advancement.
    character.subclass.features.filter(sf => sf.featureType === 'Foundation').forEach(sf => {
      features.push({ name: sf.name, source: `Subclass: ${character.subclass!.name} (${sf.featureType})`, description: sf.description });
    });
  }
  if (character.ancestry) {
    character.ancestry.features.forEach(af => {
      features.push({ name: af.name, source: `Ancestry: ${character.ancestry!.name}`, description: af.description });
    });
  }
  if (character.community) {
    features.push({ name: character.community.feature.name, source: `Community: ${character.community!.name}`, description: character.community.feature.description });
  }
  // TODO: Consider adding features from active Domain Cards or Equipment if they grant passive stat changes.
  return features;
};


export const calculateProficiency = (level: number): number => {
  if (level >= 8) return 4; // Tier 4 achievement
  if (level >= 5) return 3; // Tier 3 achievement
  if (level >= 2) return 2; // Tier 2 achievement
  return 1; // Base proficiency at Level 1
};

export const calculateMaxHP = (
  charClass: ClassData | null,
  ancestry: Ancestry | null,
  allFeatures: FeatureEntry[], // Pass all collected features
  level: number // Level might be needed for some features
): number => {
  let maxHP = charClass?.startingHP || DEFAULT_CHARACTER_DATA.hp.max;

  allFeatures.forEach(feature => {
    if (feature.source.startsWith("Ancestry:") && feature.name === "Endurance" && feature.description.includes("additional Hit Point slot")) {
      maxHP += 1; 
    }
    if (feature.source.startsWith("Subclass:") && feature.name === "Battlemage" && feature.description.includes("additional Hit Point slot")) {
        maxHP += 1; // Wizard School of War Foundation
    }
    // Add other features modifying maxHP here
  });
  return maxHP;
};

export const calculateEvasion = (
  charClass: ClassData | null,
  activeArmor: Armor | null,
  allFeatures: FeatureEntry[],
  _traits: Trait[], // Traits might be used later if specific rules refer to them for evasion
  proficiency: number // For features like Wizard's Conjure Shield
): number => {
  let evasion = charClass?.startingEvasion || DEFAULT_CHARACTER_DATA.evasion;

  if (activeArmor) {
    const armorFeatureText = activeArmor.feature?.toLowerCase() || "";
    if (armorFeatureText.includes("flexible")) evasion += 1;
    if (armorFeatureText.includes("heavy: −1 to evasion") && !armorFeatureText.includes("very heavy")) evasion -=1;
    if (armorFeatureText.includes("very heavy: −2 to evasion")) evasion -= 2;
  }

  allFeatures.forEach(feature => {
    if (feature.source.startsWith("Ancestry:") && feature.name === "Nimble" && feature.description.includes("permanent +1 bonus to your Evasion")) {
      evasion += 1; // Simiah Ancestry
    }
    // Wizard School of War - Conjure Shield: "While you have at least 2 Hope, you add your Proficiency to your Evasion."
    // This is conditional (Hope >= 2) and might be better handled as a temporary/conditional modifier.
    // For base stat calculation, we'll assume the condition is met if the feature is present or ignore it if too complex for now.
    // Let's assume for now if the feature is present, the proficiency bonus is applied to base evasion.
    // A more advanced system would handle temporary/conditional buffs separately.
    if (feature.name === "Conjure Shield" && feature.source.startsWith("Subclass:")) {
        // This implementation detail (requiring 2 Hope) is tricky for a static calculator.
        // For now, if the feature is listed, we'll assume the character *can* benefit.
        // A more robust system might have activeBuffs as a parameter.
        // Let's add proficiency directly here if the feature is present.
        // evasion += proficiency; // Simplified: assumes condition met.
        // Better: This should probably be a displayed conditional bonus, not base stat.
        // For this iteration, let's not include conditional proficiency here to keep base stats clean.
    }
  });
  return evasion;
};

export const calculateArmorScore = (
  activeArmor: Armor | null,
  _allFeatures: FeatureEntry[] // Features might modify armor score directly in the future
): number => {
  // The baseScore from Armor object should ideally already incorporate its inherent features like "Protective: +X"
  // If features on armor are separate text strings that need parsing, this function becomes more complex.
  // For now, assume armor.baseScore is the primary contributor.
  let armorScore = activeArmor?.baseScore || 0;
  
  // Example of a feature directly granting Armor Score:
  // _allFeatures.forEach(feature => {
  //   if (feature.name === "Guardian Stance" && feature.description.includes("+1 Armor Score")) {
  //     armorScore += 1;
  //   }
  // });
  return armorScore;
};


export const calculateDamageThresholds = (
  activeArmor: Armor | null,
  level: number,
  allFeatures: FeatureEntry[],
  traits: Trait[]
): DamageThresholds => {
  let major: number;
  let severe: number;

  const proficiency = calculateProficiency(level);
  let hasBareBonesFeature = allFeatures.some(f => f.name === "Bare Bones" && f.source.startsWith("Domain:"));
  const strengthTraitValue = traits.find(t => t.name === "Strength")?.value || 0;


  if (hasBareBonesFeature && !activeArmor) {
    // Bare Bones (Valor Domain Card) specific logic when NO armor is equipped
    // "When you choose not to equip armor, you have a base Armor Score of 3 + your Strength and use the following as your base damage thresholds:"
    // Tier 1 (Lvl 1): 9/19
    // Tier 2 (Lvl 2-4): 11/24
    // Tier 3 (Lvl 5-7): 13/31
    // Tier 4 (Lvl 8-10): 15/38
    // Note: The Armor Score part of Bare Bones (3 + Strength) is handled in calculateArmorScore if we pass traits there.
    // For now, this function just handles thresholds.
    if (level === 1) { major = 9; severe = 19; }
    else if (level >= 2 && level <= 4) { major = 11; severe = 24; }
    else if (level >= 5 && level <= 7) { major = 13; severe = 31; }
    else { major = 15; severe = 38; } // Level 8-10
  } else if (activeArmor) {
    const [majorStr, severeStr] = activeArmor.baseThresholds.split(' / ');
    major = parseInt(majorStr) + level;
    severe = parseInt(severeStr) + level;
  } else {
    // Default if no armor AND no Bare Bones feature active
    // SRD p.43 (Armor section details): "without armor, base Armor Score of 0 and damage thresholds of your level / your level × 2"
    major = level;
    severe = level * 2;
  }
  
  allFeatures.forEach(feature => {
    if (feature.source.startsWith("Ancestry:") && feature.name === "Shell" && feature.description.includes("bonus to your damage thresholds equal to your Proficiency")) {
      major += proficiency;
      severe += proficiency;
    }
    if (feature.source.startsWith("Subclass:") && feature.name === "Unwavering" && feature.description.includes("permanent +1 bonus to your damage thresholds")) {
      major += 1; severe += 1; // Stalwart Guardian Foundation
    }
    if (feature.source.startsWith("Subclass:") && feature.name === "Unrelenting" && feature.description.includes("permanent +2 bonus to your damage thresholds")) {
      major += 2; severe += 2; // Stalwart Guardian Specialization
    }
     if (feature.source.startsWith("Subclass:") && feature.name === "Undaunted" && feature.description.includes("permanent +3 bonus to your damage thresholds")) {
      major += 3; severe += 3; // Stalwart Guardian Mastery
    }
    // Example: Fortified Armor (Blade Domain Card)
    if (feature.name === "FORTIFIED ARMOR" && feature.description.includes("+2 bonus to your damage thresholds") && activeArmor) {
        major += 2;
        severe += 2;
    }
  });

  return { major, severe };
};

export const formatDamageRoll = (weapon: Weapon | null, proficiency: number): string | null => {
  if (!weapon) return null;
  
  let baseDamage = weapon.damage; // e.g., "d8 phy", "d10+3 mag"
  let dicePart = baseDamage;
  let flatBonus = 0;
  let damageType = "";

  // Extract damage type (phy or mag)
  const typeMatch = baseDamage.match(/\b(phy|mag)\b$/i);
  if (typeMatch) {
      damageType = ` ${typeMatch[1].toLowerCase()}`;
      dicePart = baseDamage.substring(0, typeMatch.index).trim(); // "d8", "d10+3"
  }
  
  // Extract flat bonus
  const bonusMatch = dicePart.match(/[+-]\s*(\d+)$/); // Matches "+3" or "-2" from "d10+3" or "d8-2"
  if (bonusMatch) {
      flatBonus = parseInt(bonusMatch[0].replace(/\s/g, '')); // "+3" -> 3 or "-2" -> -2
      dicePart = dicePart.substring(0, bonusMatch.index).trim(); // "d10" or "d8"
  }
  
  // dicePart should now be just the die type, e.g., "d8", "d10"
  const proficiencyDiceString = proficiency > 1 ? `${proficiency}${dicePart}` : dicePart;

  let resultString = proficiencyDiceString;
  if (flatBonus !== 0) {
      resultString += flatBonus > 0 ? ` + ${flatBonus}` : ` - ${Math.abs(flatBonus)}`;
  }
  resultString += damageType;
  
  return resultString;
};

// This is the function that CharacterCreator will call in its useEffect
export interface FullCalculatedStats extends DamageThresholds {
  maxHP: number;
  evasion: number;
  armorScore: number;
  proficiency: number;
  features: FeatureEntry[];
  // stressMax, hopeMax could be added if they become calculable
}

export const calculateAllCharacterStats = (character: CharacterData | null): FullCalculatedStats => {
  if (!character) { // Return defaults or structure for an empty character
    const defaultProf = calculateProficiency(DEFAULT_CHARACTER_DATA.level);
    return {
      maxHP: DEFAULT_CHARACTER_DATA.hp.max,
      evasion: DEFAULT_CHARACTER_DATA.evasion,
      armorScore: DEFAULT_CHARACTER_DATA.armorScore,
      major: DEFAULT_CHARACTER_DATA.level, // As per SRD for no armor
      severe: DEFAULT_CHARACTER_DATA.level * 2,
      proficiency: defaultProf,
      features: [],
    };
  }
  
  const currentFeatures = getCharacterFeatures(character);
  const currentProficiency = calculateProficiency(character.level);
  
  const maxHP = calculateMaxHP(character.class, character.ancestry, currentFeatures, character.level);
  // Pass proficiency to evasion for features like Conjure Shield, though it's conditional
  const evasion = calculateEvasion(character.class, character.activeArmor, currentFeatures, character.traits, currentProficiency); 
  
  let armorScore = calculateArmorScore(character.activeArmor, currentFeatures);
  // Special handling for Bare Bones Armor Score if no armor is equipped
  const hasBareBonesFeature = currentFeatures.some(f => f.name === "Bare Bones" && f.source.startsWith("Domain:"));
  if (hasBareBonesFeature && !character.activeArmor) {
      const strengthValue = character.traits.find(t => t.name === "Strength")?.value || 0;
      armorScore = 3 + strengthValue;
  }


  const damageThresholds = calculateDamageThresholds(character.activeArmor, character.level, currentFeatures, character.traits);

  return {
    maxHP,
    evasion,
    armorScore,
    major: damageThresholds.major,
    severe: damageThresholds.severe,
    proficiency: currentProficiency,
    features: currentFeatures,
  };
};